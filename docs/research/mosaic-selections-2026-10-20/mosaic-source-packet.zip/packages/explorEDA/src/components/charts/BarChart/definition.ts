import { applyFilter } from "@/hooks/applyFilter";
import { IdType } from "@/providers/DataLayerProvider";
import { BaseChartSettings, ChartDefinition, datum } from "@/types/ChartTypes";
import { Filter } from "@/types/FilterTypes";
import { DEFAULT_CHART_SETTINGS } from "@/utils/defaultSettings";
import { ChartColumnBig } from "lucide-react";
import { BarChart } from "./BarChart";
import { BarChartSettingsPanel } from "./BarChartSettingsPanel";

export interface BarChartSettings extends BaseChartSettings {
  type: "bar";
  binCount?: number;
  forceString?: boolean;
  aggregateId?: string;
  seriesField?: string;
  seriesLayout?: "grouped" | "stacked" | "percent";
  /** Category bars in data order (the default) or sorted by their labels. */
  categoryOrder?: "data" | "label";
  filters: Filter[];
}

export const barChartDefinition: ChartDefinition<BarChartSettings> = {
  type: "bar",
  name: "Bar Chart",
  description: "Display data as vertical bars",
  icon: ChartColumnBig,

  component: BarChart,
  settingsPanel: BarChartSettingsPanel,

  createDefaultSettings: (layout, field) => ({
    ...DEFAULT_CHART_SETTINGS,
    id: crypto.randomUUID(),
    field: field ?? "",
    binCount: 20,
    type: "bar",
    title: "Bar Chart",
    layout,
    filters: [],
  }),

  validateSettings: (settings) => {
    return !!settings.field;
  },

  getFilterFunction: (
    settings: BarChartSettings,
    fieldGetter: (name: string) => Record<IdType, datum>
  ) => {
    if (settings.seriesField) {
      const active = settings.filters.map((filter) => ({
        filter,
        data: fieldGetter(filter.field),
      }));
      return (id: IdType) =>
        active.every(({ filter, data }) => applyFilter(data[id], filter));
    }
    if (settings.aggregateId) {
      // A grouped bar selects groups with a value filter on its group field
      // and keeps an optional measure range from the Selection tab.
      const range = [...settings.filters]
        .reverse()
        .find((f) => f.type === "range" || f.type === "date-range");
      const active = [
        ...settings.filters.filter((f) => f.type === "value"),
        ...(range ? [range] : []),
      ].map((filter) => ({ filter, data: fieldGetter(filter.field) }));
      return (d: IdType) =>
        active.every(({ filter, data }) => applyFilter(data[d], filter));
    }
    const filter = settings.filters.find(
      (f): f is Filter => f.field === settings.field
    );
    const dataHash = fieldGetter(filter?.field ?? settings.field);

    return (d: IdType) => {
      const value = dataHash[d];

      if (filter) {
        if (!applyFilter(value, filter)) {
          return false;
        }
      }

      return true;
    };
  },
};
