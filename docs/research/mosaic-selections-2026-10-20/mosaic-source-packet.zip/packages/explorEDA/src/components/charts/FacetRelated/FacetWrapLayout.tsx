import { ChartSettings, datum } from "@/types/ChartTypes";
import { Maximize2 } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { ChartRenderer } from "../ChartRenderer";
import { traceOnAltEnter } from "./facetTrace";
import { FacetPager, type FacetPickerProps } from "./FacetPager";
import { FacetData } from "./FacetContainer";
import {
  PAGER_HEIGHT,
  planFacetWrapLayout,
  type FacetLayoutPlan,
} from "./facetLayout";
import { useFacetBarSlot } from "./facetBarSlot";

const FACET_CARD_WIDTH_CHROME = 18;
const FACET_CARD_HEIGHT_CHROME = 38;

interface FacetWrapLayoutProps {
  width: number;
  height: number;
  columns: number;
  facetData: FacetData[];
  settings: ChartSettings;
  onToggleFacet: (field: string, value: datum) => void;
  isFacetFiltered: (field: string, value: datum) => boolean;
  onFocusFacet: (id: string) => void;
  onTraceFacet?: (
    role: "panel",
    facets: FacetData[],
    layout: FacetLayoutPlan
  ) => void;
  formatFacetValue: (field: string, value: datum) => string;
  picker: FacetPickerProps;
}

export function FacetWrapLayout({
  width,
  height,
  columns,
  facetData,
  settings,
  onToggleFacet,
  isFacetFiltered,
  onFocusFacet,
  onTraceFacet,
  formatFacetValue,
  picker,
}: FacetWrapLayoutProps) {
  const [page, setPage] = useState(0);
  const pagerHeight = useFacetBarSlot() ? 0 : PAGER_HEIGHT;
  const layout = planFacetWrapLayout(
    width,
    height,
    facetData.length,
    columns,
    page,
    pagerHeight
  );
  const { columnCount, pageSize, pageCount, facetWidth, facetHeight } = layout;
  useEffect(() => setPage(layout.page), [layout.page]);

  const visible = facetData.slice(page * pageSize, (page + 1) * pageSize);
  const rowVariable = settings.facet.rowVariable;
  const first = page * pageSize + 1;
  const last = Math.min((page + 1) * pageSize, facetData.length);
  const pageLabel =
    first === last
      ? `Facet ${first} of ${facetData.length}`
      : `Facets ${first}–${last} of ${facetData.length}`;

  return (
    <div className="flex h-full min-h-0 flex-col">
      <FacetPager
        label={pageLabel}
        page={page}
        pageCount={pageCount}
        onPageChange={setPage}
        picker={picker}
      />
      <div
        className="grid min-h-0 flex-1 gap-2 overflow-hidden"
        style={{
          gridTemplateColumns: `repeat(${columnCount}, minmax(0, 1fr))`,
        }}
      >
        {visible.map((facet) => (
          <div
            key={facet.id}
            className="relative min-h-0 min-w-0 overflow-hidden rounded-md border border-border/50 p-2"
          >
            <div className="mb-1 flex h-4 min-w-0 items-center gap-0.5 text-xs font-medium">
              <button
                type="button"
                className="min-w-0 truncate text-left underline-offset-2 hover:underline"
                aria-pressed={isFacetFiltered(rowVariable, facet.rowRawValue)}
                onKeyDown={traceOnAltEnter(
                  onTraceFacet && (() => onTraceFacet("panel", [facet], layout))
                )}
                onClick={(event) => {
                  if (event.altKey && onTraceFacet)
                    onTraceFacet("panel", [facet], layout);
                  else onToggleFacet(rowVariable, facet.rowRawValue);
                }}
              >
                {formatFacetValue(rowVariable, facet.rowRawValue)}
              </button>
              <Button
                variant="ghost"
                size="icon"
                className="size-5 shrink-0 text-muted-foreground hover:text-foreground"
                tooltip="Focus facet"
                data-export="omit"
                aria-label={`Focus ${formatFacetValue(rowVariable, facet.rowRawValue)} facet`}
                onKeyDown={traceOnAltEnter(
                  onTraceFacet && (() => onTraceFacet("panel", [facet], layout))
                )}
                onClick={(event) => {
                  if (event.altKey && onTraceFacet)
                    onTraceFacet("panel", [facet], layout);
                  else onFocusFacet(facet.id);
                }}
              >
                <Maximize2 className="size-3" />
              </Button>
            </div>
            <ChartRenderer
              settings={settings}
              width={Math.max(1, facetWidth - FACET_CARD_WIDTH_CHROME)}
              height={Math.max(1, facetHeight - FACET_CARD_HEIGHT_CHROME)}
              facetIds={facet.ids}
              facetKey={facet.id}
            />
          </div>
        ))}
      </div>
    </div>
  );
}
