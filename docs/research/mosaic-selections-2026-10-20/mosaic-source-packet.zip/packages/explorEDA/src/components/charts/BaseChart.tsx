import { useAxisTypography } from "./chartTypography";
import { ReactNode, useId, useMemo, useRef, useState } from "react";
import { ScaleBand, ScaleLinear, scaleLinear } from "d3-scale";
import { formatTick } from "./Axis/Axis";
import {
  findAxisGuide,
  planAxes,
  type AxisHiddenEnds,
  type ChartAxesPlan,
} from "./Axis/axisPlan";
import { PlannedAxes, PlannedGrid } from "./Axis/AxisLayer";
import { useBrush } from "@/hooks/useBrush";
import { cn } from "@/lib/utils";
import { ChartSettings } from "@/types/ChartTypes";
import { useFilterExtent } from "@/hooks/useFilterExtent";
import { useDataLayer } from "@/providers/DataLayerProvider";
import {
  getChartAxisFields,
  getChartAxisLabel,
  getChartTitle,
} from "./chartAccessibility";
import { CLICK_SLOP, isEmptyPlotTarget } from "./emptyPlotClick";

type BrushMode = "horizontal" | "2d" | "none";

interface BaseChartProps {
  width: number;
  height: number;
  xScale: ScaleLinear<number, number> | ScaleBand<string>;
  yScale: ScaleLinear<number, number> | ScaleBand<string>;
  /** A chart that traces its guides passes its own plan so drawing and tracing agree. */
  axes?: ChartAxesPlan;
  brushingMode?: BrushMode;
  onBrushChange?: (extent: [[number, number], [number, number]] | null) => void;
  children: ReactNode;
  overlay?: ReactNode;
  /** Saved annotations, drawn over the marks; given the plot clip path. */
  annotations?: (clipPath: string) => ReactNode;
  className?: string;
  settings: ChartSettings;
  axisFields?: { x?: string; y?: string };
  xTickFormatter?: (value: string | number) => string;
  yTickFormatter?: (value: string | number) => string;
  /** Receives the planned id of an Alt-clicked axis guide. */
  onInspectGuide?: (id: string) => void;
  /** Receives the planned id under the pointer, or null, and the Alt state. */
  onHoverTarget?: (id: string | null, altKey: boolean) => void;
  onInspectPlot?: (point: [number, number], anchor: DOMRect) => boolean;
  /**
   * Receives a plain click in the plot, in plot coordinates. Returning true
   * means the chart set its own selection, so the brush keeps it.
   */
  onSelectPlot?: (point: [number, number]) => boolean;
  /**
   * A plain click on empty plot space, away from every mark. The chart clears
   * its filters, as its clear-filter action does. Called only while it filters.
   */
  onClearPlot?: () => void;
  activeGuideId?: string | null;
  /** Bottom margin kept below the X axis title, such as for a status line. */
  footer?: number;
  /** Marks past each end of a bounded axis, which that axis marks. */
  hidden?: { x?: AxisHiddenEnds; y?: AxisHiddenEnds };
}

function planIdFromTarget(target: EventTarget | null) {
  if (!(target instanceof Element)) return undefined;
  return (
    target
      .closest<SVGElement>("[data-plan-id]")
      ?.getAttribute("data-plan-id") ?? undefined
  );
}

export function BaseChart({
  width,
  height,
  xScale,
  yScale,
  axes: plannedAxes,
  brushingMode = "none",
  onBrushChange,
  children,
  overlay,
  annotations,
  className,
  settings,
  axisFields: axisFieldsOverride,
  xTickFormatter,
  yTickFormatter,
  onInspectGuide,
  onHoverTarget,
  onInspectPlot,
  onSelectPlot,
  onClearPlot,
  activeGuideId,
  footer = 0,
  hidden,
}: BaseChartProps) {
  const margin = plannedAxes?.margin ?? settings.margin;
  const typography = useAxisTypography();

  const innerWidth = width - margin.left - margin.right;
  const innerHeight = height - margin.top - margin.bottom;
  const svgRef = useRef<SVGSVGElement>(null);
  const [altPointer, setAltPointer] = useState(false);
  const [altHover, setAltHover] = useState(false);
  const chartId = useId();
  const getFieldLabel = useDataLayer((state) => state.getFieldLabel);
  const formatFieldValue = useDataLayer((state) => state.formatFieldValue);
  const fieldSettings = useDataLayer((state) => state.fieldSettings);
  const axisFields = axisFieldsOverride ?? getChartAxisFields(settings);
  const formatAxisValue = (
    field: string | undefined,
    override?: (value: string | number) => string
  ) =>
    override ??
    (field && formatFieldValue
      ? (value: string | number) => formatFieldValue(field, value)
      : formatTick);
  const xLabel = [
    getChartAxisLabel(axisFields.x, settings.xAxisLabel, getFieldLabel),
    settings.xAxis.scaleType === "symlog" && "symlog",
    "base" in xScale && "log",
  ]
    .filter(Boolean)
    .join(" · ");
  const yLabel = [
    getChartAxisLabel(axisFields.y, settings.yAxisLabel, getFieldLabel),
    settings.yAxis.scaleType === "symlog" && "symlog",
    "base" in yScale && "log",
  ]
    .filter(Boolean)
    .join(" · ");
  // Charts without their own plan still draw from a plan, so axes follow one rule.
  const axes = useMemo(
    () =>
      plannedAxes ??
      planAxes({
        plotWidth: innerWidth,
        plotHeight: innerHeight,
        margin,
        footer,
        x: {
          typography,
          scale: xScale,
          scaleType: settings.xAxis.scaleType,
          field: axisFields.x,
          density: settings.xGridLines,
          tickFontSize: settings.xAxis.tickFontSize,
          labelFontSize: settings.xAxis.labelFontSize,
          grid: settings.xAxis?.grid,
          format: formatAxisValue(axisFields.x, xTickFormatter),
          label: xLabel,
          labelSource: settings.xAxisLabel ? "chart-setting" : "field-label",
          hidden: hidden?.x,
        },
        y: {
          typography,
          scale: yScale,
          scaleType: settings.yAxis.scaleType,
          field: axisFields.y,
          density: settings.yGridLines,
          tickFontSize: settings.yAxis.tickFontSize,
          labelFontSize: settings.yAxis.labelFontSize,
          grid: settings.yAxis?.grid,
          format: formatAxisValue(axisFields.y, yTickFormatter),
          label: yLabel,
          labelSource: settings.yAxisLabel ? "chart-setting" : "field-label",
          hidden: hidden?.y,
        },
      }),
    // Formatters read field settings, so they rerun when those change.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [
      plannedAxes,
      typography,
      innerWidth,
      innerHeight,
      margin,
      xScale,
      yScale,
      settings.xAxis,
      settings.yAxis,
      settings.xGridLines,
      settings.yGridLines,
      settings.xAxisLabel,
      settings.yAxisLabel,
      axisFields.x,
      axisFields.y,
      xLabel,
      yLabel,
      xTickFormatter,
      yTickFormatter,
      fieldSettings,
      footer,
      hidden,
    ]
  );
  const descriptionId = `${chartId}-description`;
  const inspectedByBrush = useRef(false);
  const chartTitle = getChartTitle(settings, getFieldLabel);
  const chartDescription = [
    `Interactive ${settings.type} chart.`,
    settings.xAxisLabel && `Horizontal axis: ${settings.xAxisLabel}.`,
    settings.yAxisLabel && `Vertical axis: ${settings.yAxisLabel}.`,
  ]
    .filter(Boolean)
    .join(" ");
  const xIsLinear = "invert" in xScale;
  const yIsLinear = "invert" in yScale;
  const extent = useFilterExtent({
    settings: xIsLinear && yIsLinear ? settings : { ...settings, filters: [] },
    xScale: xIsLinear
      ? xScale
      : scaleLinear().domain([0, 1]).range([0, innerWidth]),
    yScale: yIsLinear
      ? yScale
      : scaleLinear().domain([0, 1]).range([0, innerHeight]),
    innerHeight,
  });

  const guideAt = (target: EventTarget | null) => {
    const id = planIdFromTarget(target);
    return id && findAxisGuide(axes, id) ? id : undefined;
  };

  const inspectTarget = (event: {
    altKey: boolean;
    target: EventTarget | null;
  }) => {
    if (!event.altKey || !onInspectGuide) return false;
    const id = guideAt(event.target);
    if (!id) return false;
    onInspectGuide(id);
    return true;
  };

  const inspectPlot = (event: {
    altKey: boolean;
    clientX: number;
    clientY: number;
    currentTarget: SVGSVGElement;
  }) => {
    if (!event.altKey || !onInspectPlot) return false;
    const rect = event.currentTarget.getBoundingClientRect();
    const point: [number, number] = [
      event.clientX - rect.left - margin.left,
      event.clientY - rect.top - margin.top,
    ];
    if (
      point[0] < 0 ||
      point[0] > innerWidth ||
      point[1] < 0 ||
      point[1] > innerHeight
    ) {
      return false;
    }
    return onInspectPlot(
      point,
      new DOMRect(event.clientX, event.clientY, 0, 0)
    );
  };

  const clearPlot =
    onClearPlot && settings.filters.length > 0 ? onClearPlot : undefined;
  // Where a press began, so a click that ends a drag is not a dead click.
  // A press the brush took settles its dead click on pointer up instead.
  const pressAt = useRef<{ x: number; y: number; brush: boolean } | null>(null);
  const plotPoint = (event: { clientX: number; clientY: number }) => {
    const rect = svgRef.current!.getBoundingClientRect();
    const x = event.clientX - rect.left - margin.left;
    const y = event.clientY - rect.top - margin.top;
    return x >= 0 && x <= innerWidth && y >= 0 && y <= innerHeight;
  };

  const brush = useBrush({
    svgRef,
    marginLeft: margin.left,
    marginTop: margin.top,
    innerWidth,
    innerHeight,
    mode: brushingMode as "horizontal" | "2d" | "none",
    onBrushChange,
    onPlotClick: (point, event) => {
      const handled = inspectTarget(event);
      inspectedByBrush.current = handled;
      if (event.altKey || handled) return true;
      return onSelectPlot?.(point) ?? false;
    },
    defaultExtent: extent,
    // A histogram's selection spans the plot's height, so a click inside it
    // that misses every bar is still a click on empty space.
    onDeadClick: onClearPlot ? () => clearPlot?.() : undefined,
  });

  if (width < 1 || height < 1) {
    return null;
  }

  const interactive = Boolean(onInspectGuide);

  return (
    <svg
      ref={svgRef}
      width={width}
      height={height}
      role="group"
      aria-label={chartTitle}
      aria-describedby={descriptionId}
      className={cn("select-none", className)}
      style={{
        cursor: altHover ? "pointer" : brush.getCursor(),
        touchAction: brushingMode === "none" ? "auto" : "none",
      }}
      tabIndex={brushingMode === "none" ? undefined : 0}
      onKeyDown={(event) => {
        if (event.key === "Escape") {
          event.stopPropagation();
          brush.clear();
        }
      }}
      onPointerDownCapture={(event) => {
        pressAt.current =
          event.button === 0
            ? { x: event.clientX, y: event.clientY, brush: false }
            : null;
        onHoverTarget?.(null, false);
        setAltHover(false);
        if (interactive && guideAt(event.target)) {
          // Guide clicks inspect or select the guide. They never start a brush.
          if (!event.altKey) event.preventDefault();
          else setAltPointer(true);
          return;
        }
        // Alt-click is inspection. Do not start a brush gesture that can clear or replace filters.
        if (interactive && event.altKey) {
          setAltPointer(true);
          return;
        }
        if (pressAt.current) pressAt.current.brush = brushingMode !== "none";
        brush.handlePointerDown(event);
      }}
      onPointerMoveCapture={(event) => {
        brush.handlePointerMove(event);
        const id = planIdFromTarget(event.target);
        onHoverTarget?.(id ?? null, event.altKey);
        setAltHover(Boolean(event.altKey && interactive && id));
      }}
      onPointerUpCapture={brush.handlePointerUp}
      onPointerCancel={() => {
        setAltPointer(false);
        setAltHover(false);
        onHoverTarget?.(null, false);
        brush.cancel();
      }}
      onLostPointerCapture={() => {
        setAltPointer(false);
        setAltHover(false);
        onHoverTarget?.(null, false);
        brush.cancel();
      }}
      onPointerLeave={() => {
        setAltHover(false);
        onHoverTarget?.(null, false);
      }}
      onClick={(event) => {
        const press = pressAt.current;
        pressAt.current = null;
        // The axis marker opens its own details; it never clears or selects.
        if ((event.target as Element).closest("[data-axis-hidden]")) return;
        // A callout label is dragged, never clicked through to the plot.
        if ((event.target as Element).closest("[data-annotation-handle]"))
          return;
        if (inspectedByBrush.current) inspectedByBrush.current = false;
        else if (!inspectTarget(event) && !inspectPlot(event)) {
          if (
            !press?.brush &&
            !event.altKey &&
            clearPlot &&
            press &&
            Math.hypot(event.clientX - press.x, event.clientY - press.y) <
              CLICK_SLOP &&
            plotPoint(event) &&
            isEmptyPlotTarget(event.target)
          )
            clearPlot();
        }
        setAltPointer(false);
      }}
      onKeyDownCapture={(event) => {
        if (event.altKey && event.key === "Enter" && inspectTarget(event)) {
          event.preventDefault();
          event.stopPropagation();
        }
      }}
      data-alt-hover={altHover ? "true" : undefined}
    >
      <desc id={descriptionId}>{chartDescription}</desc>
      <defs>
        <clipPath id={`${chartId}-plot`}>
          <rect
            x={0}
            y={0}
            width={Math.max(0, innerWidth)}
            height={Math.max(0, innerHeight)}
          />
        </clipPath>
      </defs>
      <g transform={`translate(${margin.left},${margin.top})`}>
        <PlannedGrid
          plan={axes}
          interactive={interactive}
          activeId={activeGuideId}
        />
        {/* Main content */}
        <g clipPath={`url(#${chartId}-plot)`}>{children}</g>

        {/* Brush overlay */}
        <g
          clipPath={`url(#${chartId}-plot)`}
          style={{ pointerEvents: altPointer ? "none" : undefined }}
        >
          {brush.renderBrush}
        </g>
        {annotations?.(`url(#${chartId}-plot)`)}

        <PlannedAxes
          plan={axes}
          interactive={interactive}
          activeId={activeGuideId}
        />
        {overlay}
      </g>
    </svg>
  );
}
