# 100 research candidates for explorEDA

This collection contains **exactly 100 distinct research candidates**, each grounded in the supplied React and TypeScript repository baseline. They are **candidates for investigation, not approved implementation**. Their purpose is to help a personal developer choose a useful, independent question for a recurring research task that runs every six hours. No task was operated or changed, and no application changes were implemented.

The authoritative collection is `exploreda-100-research-ideas.zip`. It contains this overview, 100 individually usable briefs, the machine-readable index, the source ledger, and the validation manifest. A later Codex run owns reconciliation against its local checkout, product validation, commits, and any docs-only review PR.

## Baseline and deliverables

| Item | Result |
| --- | --- |
| Repository | [byronwall/explorEDA](https://github.com/byronwall/explorEDA) |
| Authorized baseline | [`9b16d78e3ed0742ed4d5858c1939fec9e758b510`](https://github.com/byronwall/explorEDA/commit/9b16d78e3ed0742ed4d5858c1939fec9e758b510) |
| Source route | Attached selected-source ZIP, supplemented by six read-only GitHub files from the exact same commit |
| Baseline integrity | All 1,099 manifest-listed files matched their SHA-256 hashes; no mismatches |
| Research documents | 100, with stable IDs R001–R100 and unique priorities 1–100 |
| Prose | 32,964 words; 299–361 per idea; exactly 400 substantive paragraphs |
| Taxonomy | 18 evidence-derived categories |
| Kinds | 41 robustness, 34 follow-up, 15 new-direction, 10 simplification |
| Payload | 104 files: 100 briefs plus README, index, sources, and manifest |

The source packet describes itself as **selected source; not runnable**. Hash verification establishes integrity, not execution or an exhaustive content review. The reading ledger distinguishes 171 full-file reads from 116 targeted reads across 287 unique source and documentation files. It includes all 34 intent briefs, plus full or targeted inspection of all 86 ranked intent artifacts. No newer default-branch changes were substituted for the authorized baseline.

- [ideas.json](ideas.json) is the complete index. It is sorted by stable ID; use `priority` to select by rank.
- [sources.md](sources.md) records repository coverage, same-commit supplemental files, 18 primary external sources, intent reconciliation, and unverified claims.
- [manifest.json](manifest.json) records per-idea word and paragraph counts, the exact generated file list, hashes, and executed artifact checks.
- The full catalogue below links every individual brief. Each can be pasted into a later research prompt with its references intact.

## How to interpret the ranking

Priority is a judgment about **the value of the next research decision**, not a severity score, a promise of a defect, or an implementation sequence. Early candidates combine an important analytical or recovery consequence, a concrete existing code seam, a small falsifiable experiment, and a useful outcome even if the current design is retained. Breadth matters: numerical validity, interaction, persistence, narrative, package consumption, and credible examples all deserve attention.

The first fifteen emphasize bounded investigations that can start without a prerequisite feature. The remaining ranks retain ambitious directions, selective extensions, and simplification studies. A lower rank may reflect uncertain demand or an expensive implementation boundary; it does not mean the topic is unimportant. R021, for example, remains explicitly conditional and low confidence. R092 preserves the earlier decision to keep row JSON for the measured database workload and asks what wider workload would justify reopening it.

`confidence` describes confidence that the question is worth investigating from the inspected evidence. It is not confidence that a proposed change will win. `research_kind` describes the main reason to investigate: a new analytical direction, a precise follow-up to recorded intent, a robustness concern, or a simplification choice. Every record remains `candidate`. Empty `dependencies` arrays are deliberate: all 100 first studies can be scoped independently. Shared fixtures and related topics can reduce effort, but are not hard prerequisites or an implementation roadmap.

## First 15 candidates and why they rank early

| Priority | Candidate | Rationale for the next research run |
| --- | --- | --- |
| 1 | [R026 — Reconcile missing, blank, invalid, and converted-value counts](ideas/R026-missing-state-accounting.md) | A small state-accounting matrix can clarify what counts as missing, invalid, or converted across several existing consumers. It protects interpretation before new preparation features multiply the states. |
| 2 | [R043 — Reconcile entity-aware aggregation across preparation paths](ideas/R043-entity-grain-parity.md) | Equivalent entity populations pass through two existing aggregation paths. A compact conflict/missing-key fixture can distinguish an intentional grain difference from an accidental disagreement without creating another reducer. |
| 3 | [R077 — Selection identity when source rows are replaced](ideas/R077-selection-identity-when-source-rows-are-replaced.md) | Selections are valuable only while they identify the intended records. Existing logical-key and positional behavior provides a bounded source-replacement study with an explicit retain-or-invalidate outcome. |
| 4 | [R001 — Regression reliability after changing units and coordinate offsets](ideas/R001-regression-conditioning.md) | Unit changes and large coordinate offsets can expose numerical weaknesses even when a plot looks plausible. Independent reference outputs make this a focused, falsifiable scientific-reliability investigation. |
| 5 | [R051 — Make filter ownership and self-exclusion understandable](ideas/R051-filter-ownership.md) | Several correct population rules can still produce a misleading experience if their ownership is unclear. A small comprehension exercise can justify better wording or confirm that current scope explanations suffice. |
| 6 | [R086 — Recoverable autosave after mixed file outcomes](ideas/R086-recoverable-autosave-after-mixed-file-outcomes.md) | The local app already saves automatically. Controlled mixed write outcomes can establish whether status and recovery remain truthful, potentially yielding a small fix or confirmation that broader save coordination is unnecessary. |
| 7 | [R031 — Explain ambiguous date conversions before applying them](ideas/R031-date-ambiguity-preview.md) | Date conversion already has a preview. Testing ambiguity explanations builds on that seam and can prevent a wrong interpretation before it affects every date-based analysis. |
| 8 | [R011 — Retention maturity grounded in an observation cutoff](ideas/R011-retention-observation-cutoff.md) | A cohort that has not had time to mature should not be interpreted like an observed failure. The existing retention states make an explicit observation-cutoff study small and analytically consequential. |
| 9 | [R073 — Challenge example conclusions with deliberate counterexamples](ideas/R073-example-claim-challenges.md) | Credible examples shape the user’s understanding of the product. Counterexamples can test whether a headline is justified by its scope, beyond merely reproducing arithmetic from an example. |
| 10 | [R064 — Explain frozen notebook results and dependent definitions](ideas/R064-notebook-frozen-results.md) | Notebooks already preserve usable results while text is invalid. A focused reader study can determine whether frozen definitions and dependent results are understood without redesigning notebook execution. |
| 11 | [R078 — Independent workspace ownership for dialogs and exports](ideas/R078-independent-workspace-ownership-for-dialogs-and-exports.md) | Independent React instances share some module-level mechanisms. A two-workspace ownership fixture can test dialogs and export targeting cheaply, with no need for a new application architecture. |
| 12 | [R059 — Keep focus and Escape predictable across nested editors](ideas/R059-nested-focus-ownership.md) | Nested editors are common paths through the product. Explicit focus-return and Escape sequences can reveal consequential interaction failures with a small reproducible task set. |
| 13 | [R088 — Bind cached database snapshots to their source definition](ideas/R088-bind-cached-database-snapshots-to-their-source-definition.md) | A cached database snapshot remains useful only when its producing source definition is understood. Comparing a small fingerprint with current metadata can settle a provenance boundary without building a server query platform. |
| 14 | [R056 — Compare contributor sets when two views disagree](ideas/R056-contributor-set-comparison.md) | When two views disagree, exact contributor comparison may explain the result more directly than another chart. A limited inspection prototype can test whether the workflow helps real diagnosis. |
| 15 | [R100 — Published-package behavior in small real consumer projects](ideas/R100-published-package-behavior-in-small-real-consumer-projects.md) | A few installed-package probes can catch export, type, style, or worker-asset problems that source imports cannot reveal. The study can explicitly reject an expensive compatibility matrix. |

## Taxonomy

The categories follow real implementation and decision boundaries. They were not filled to a quota. A source file may support more than one question, but the alternatives, observable outcome, and rejection decision must differ.

| Category | Ideas | Research boundary |
| --- | ---: | --- |
| Scientific analysis | 9 | Numerical stability, diagnostic assumptions, multivariate comparisons, and the value of existing analytical methods. |
| Distribution semantics | 3 | Histogram boundaries, weighted distributions, and quantile conventions tied to an analytical question. |
| Domain analysis | 7 | Retention, funnel journeys, concurrency, explicit links, flow folding, regional rates, and state reconciliation. |
| Composed graphics | 6 | Stable encodings, repaired intervals, repeated-unit populations, label limits, and shared-reducer fidelity. |
| Data quality and missingness | 4 | Distinguishable value states, missingness patterns, explicit expectations, and bounded quality assertions. |
| Types, quantities, and dates | 9 | Inference, locale, temporal meaning, rolling windows, units, and decimal precision. |
| Data preparation and relationships | 7 | Category mappings, entity keys, relationship grain, joins, reshaping, and ordered preparation. |
| Calculations and expressions | 5 | Error propagation, names, renaming, truthiness, and a minimal useful text-function surface. |
| Selection and analytical scope | 5 | Filter ownership, empty results, tuple unions, lasso membership, and overview-to-detail inheritance. |
| Inspection and provenance | 3 | Absent marks, contributor comparison, and consequences of future applied edits. |
| Accessibility and interaction | 8 | Keyboard, touch, focus, nonvisual summaries, color independence, field choice, narrow reading, and discoverability. |
| Notebooks and narrative | 5 | Frozen-result meaning, scoped notebook linking, shared-definition navigation, bound values, and claim scope. |
| Documentation and examples | 4 | Task routing, contextual explanations, falsifiable example claims, and sustainable example coverage. |
| Embedding and package contracts | 5 | Host echoes, row identity, independent instances, selective integration, and installed-package fidelity. |
| Import, export, and persistence | 6 | Saved-state diagnostics, unattended images, reader fidelity, CSV meaning, image export, and browser checkpoints. |
| Local and database workflows | 6 | Save recovery, external edits, source-bound snapshots, resource limits, cancellation, and local prerequisites. |
| Measured performance | 6 | File preparation, wider transport workloads, worker scheduling, task budgets, retained memory, and point picking. |
| Testing and reproducibility | 2 | Valid workflow invariants and smaller cases that preserve a reproduced analytical failure. |

## Existing work and overlap boundaries

The baseline contains considerably more delivered functionality than some inventory and initiative labels imply. Current implementations and tests take precedence over stale prose. The briefs credit those capabilities before asking what remains uncertain.

| Existing capability or decision | How the collection uses it |
| --- | --- |
| Funnel, Retention, and Timeline are implemented. | [R011](ideas/R011-retention-observation-cutoff.md), [R012](ideas/R012-funnel-ambiguous-order.md), and [R013](ideas/R013-timeline-concurrency.md) investigate observation maturity, repeated journeys, and interval accounting; they do not request the first versions of those views. |
| Regression fits, covariance summaries, correlation matrices, densities, ECDF, and composition operations already exist. | [R001](ideas/R001-regression-conditioning.md)–[R024](ideas/R024-shared-reducer-adapters.md) examine assumptions, populations, numerical behavior, and wrapper semantics. Method availability alone is not treated as evidence of a new gap. |
| Composition has an existing stable-scale plan and already handles crossed band bounds and broken runs. | [R019](ideas/R019-composition-scale-envelopes.md) studies subset aggregates that can exceed unfiltered aggregate bounds; [R020](ideas/R020-supplied-band-meaning.md) studies whether repaired intervals communicate their meaning. |
| Conversion previews, identifier safeguards, lookups, expansions, entity-aware aggregation, lazy conditions, and dependency guards are delivered. | [R026](ideas/R026-missing-state-accounting.md)–[R050](ideas/R050-bounded-quality-assertions.md) focus on accounting, precision, grain, explicit preparation, and the coverage of existing contracts. |
| Chart-local, shared, workspace, and row filters already have distinct roles; current single-cell selection is valid. | [R051](ideas/R051-filter-ownership.md) studies comprehension. [R053](ideas/R053-exact-tuple-selections.md) studies exact tuple unions. [R054](ideas/R054-lasso-membership.md) studies lasso membership and ranks ahead of tuple work in line with the current intent. |
| Tracing, row lookup, accessibility descriptions, source-row/shared-aggregate previews, and direct-edit gestures exist. | [R055](ideas/R055-row-visibility-explanations.md)–[R061](ideas/R061-noncolor-meaning.md) refine diagnosis or task access. [R060](ideas/R060-analytical-text-alternatives.md) explicitly credits the existing grouped preview; [R070](ideas/R070-gesture-discoverability.md) teaches current gestures. |
| Notebooks, shared definitions, last-valid recovery, parameters, applied bindings, and DailyFinding values are delivered. | [R064](ideas/R064-notebook-frozen-results.md)–[R069](ideas/R069-detail-filter-inheritance.md) ask about interpretation, scoped linking, navigation, and generalized binding rather than treating notebooks or computed findings as absent. |
| The in-app agent remains a future service. | [R075](ideas/R075-applied-edit-explanations.md) investigates post-application explanations using current settings/history. It preserves the intent of direct application with ordinary Undo and adds no approval gate. |
| Live PNG export, multiple readers, saved-analysis validation, browser history, and local folder writes are delivered. | [R079](ideas/R079-actionable-diagnostics-for-rejected-saved-analyses.md)–[R087](ideas/R087-external-file-edits-without-losing-the-analyst-s-draft.md) and [R099](ideas/R099-checkpoint-representation-for-fast-and-recoverable-browser-history.md) address diagnostics, fidelity, unattended context, recovery, and measured checkpoint costs. |
| Five database adapters and retained last-good snapshots are delivered. | [R088](ideas/R088-bind-cached-database-snapshots-to-their-source-definition.md)–[R091](ideas/R091-local-database-readiness-with-optional-native-dependencies.md) investigate source provenance, resource estimates, cancellation timing, and local prerequisites. They do not request a new generic database platform. |
| Earlier database work kept JSON after a 100,000-row, 12-column measurement. | [R092](ideas/R092-when-wider-snapshots-change-the-row-json-transport-decision.md) changes width, string shape, and replacement overlap, and includes row-consumer costs. Retaining JSON is an explicit successful outcome. |
| Workers already ignore obsolete results and preserve prior completed output; targeted performance guards exist. | [R093](ideas/R093-discard-stale-worker-computation-as-well-as-stale-results.md) measures obsolete computation still in flight. [R094](ideas/R094-performance-budgets-for-complete-analytical-interactions.md) examines complete user tasks instead of re-reporting already-fixed host-echo or column-lookup costs. |
| Ordinary scatter and the matrix already use canvas; bubbles also use SVG. | [R096](ideas/R096-exact-point-picking-when-scatter-clouds-become-dense.md) investigates exact point picking and index rebuild costs, preserving current nearest-point and overlapping-bubble semantics. |
| Renderer-independent replay and headless images are recorded seeds. | [R081](ideas/R081-headless-chart-images-through-a-minimal-existing-renderer.md) is a conditional image-host study. [R098](ideas/R098-small-reproducible-cases-that-preserve-analytical-failures.md) asks a different question: how to minimize a reproduced semantic failure without changing its cause. |
| The edge-list seed already proposes table accounting before geometry. | [R014](ideas/R014-explicit-edge-selection.md) holds geometry fixed and studies incident versus induced edge populations, duplicate records, and self-loop totals. |
| Customer hosting is paused; named baselines remain low priority; reusable outputs/metrics are unprioritized seeds. | The collection adds no multi-tenant system, version-coexistence scheme, graph platform, or framework migration. React remains React. |

Some questions intentionally share an example while answering different decisions. R024 compares native-chart/composition wrappers around shared reducers; R043 compares entity-grain contracts across preparation paths; R056 supports an analyst comparing contributor sets. R073 tests whether an authored example claim is justified; R097 tests mathematically valid workflow invariants; R098 minimizes an already reproduced failure. Reader fidelity in R082 is distinct from arithmetic precision in R037, CSV’s analytical contract in R084, and displayed image fidelity in R085. Cancellation in R083, R090, and R093 addresses different execution owners and cannot be resolved by one generic cancel button.

Cross-review read all 100 complete briefs and all index records. A second global pass examined close boundaries, and a lexical similarity screen selected 40 pairs for review; similarity was a triage tool, not proof of distinctness. The final intent pass reconciled every question against the 86 ranked intent artifacts. Necessary corrections included the edge-list study, Sankey Other acceptance criteria, credit for the grouped preview, scatter’s existing canvas rendering, browser-history scope, and precise reference symbols. No unresolved required correction remained at packaging.

## Selecting a topic for a future six-hour research task

The six-hour cadence is a scheduling context, not a promise that an implementation can be completed in six hours. Select one decision that can make useful progress in a bounded research run. Do not change or operate the recurring task simply because this collection describes it.

1. **Reconcile the current checkout.** Record its commit. Read the selected brief, cited implementations and tests, related intent, and any supplied prior research log. If the question is already answered or shipped, record that result and select another candidate. The supplied baseline remains historical evidence, not authority over later source.
2. **Choose by rank, readiness, and breadth.** Prefer an early candidate whose required fixture or user task is available. Rotate among analytical, data, interaction, and workflow concerns. A paper contract or reference calculation can be productive when a runnable environment or participants are unavailable.
3. **Restate one decision.** Preserve the brief’s uncertainty, alternatives, and rejection signal. Name the population, identity, units, or state transition involved. Avoid growing the topic into a platform or an adjacent idea simply because it shares a file.
4. **Set the first proof before exploring solutions.** Specify a small fixture, a current-behavior control, an independent expectation, and a practical acceptance threshold. Record missing evidence. If a user study is needed, distinguish a proposed protocol from findings obtained from actual participants.
5. **Use the complete environment when execution is needed.** The attached packet cannot run product checks. In a reconciled checkout, follow repository instructions and use pnpm for proposed commands. Do not treat another project’s documentation or a historical benchmark as fresh explorEDA test evidence.
6. **Return a decision, not just options.** Recommend implement later, clarify/document, retain current behavior, defer pending a named trigger, or reject. Include evidence, contrary results, maintenance/API cost, remaining uncertainty, and the smallest next action. A defensible no-change decision fully satisfies a research candidate.
7. **Hand off cleanly.** Keep stable IDs in the report. Suggest a candidate-status update for a later authorized reconciliation. Codex owns local validation, commits, and the docs-only PR workflow. Implementation, external publication, and automation mutation require their own task scope.

### Reusable research-run prompt

> Investigate candidate R___ from this collection against the current explorEDA checkout. Treat the supplied brief as a question, not an accepted design. Verify the current commit and related shipped work first. Compare its stated alternatives, preserve its distinct research boundary, and carry out the smallest feasible first proof. Report observed facts, inference, proposed work, and executed checks separately. Return a clear keep/change/defer/reject decision with acceptance evidence, contrary evidence, maintenance cost, and a bounded next step. Use pnpm for proposed repository commands. Do not implement changes or modify recurring tasks unless that separate work is explicitly authorized. If the required environment, data, or participants are unavailable, provide the exact unresolved question and a reviewable experiment protocol rather than inventing results.

## Access, uncertainty, and verification limits

The packet excludes assets, datasets, dependencies, generated outputs, historical raw research, and local secrets. Some initiative documents link historical reference material that is not included. No claim is made that those unavailable research archives were read. Novelty was checked against available source, tests, intent artifacts, and the complete proposed collection; exhaustive novelty against omitted history cannot be established. A future run should check any additionally supplied research log before spending effort.

Repository files were read as evidence; product tests were not run. No pnpm install, build, typecheck, browser interaction study, accessibility audit, database execution, numerical benchmark, heap profile, or proposed experiment was executed. Historical timing notes are explicitly historical. Source-level hypotheses about mixed save outcomes, multi-instance ownership, worker queues, and cancellation are not confirmed defects.

The six supplemental GitHub files are build/entry configuration, the lean-bundle check, and the local app’s save/reload implementation and tests. They were fetched at the same commit and checked against their Git blob hashes. Their citations are marked external to the ZIP in the index and source ledger. No app code, existing repository document, Git state, PR, or automation was changed.

Artifact verification checked exact IDs and priorities; complete required index fields and enum values; synchronized document metadata; every index path; word and substantive-paragraph counts; duplicate titles/questions/paragraphs; all cited repository paths and 605 literal symbol/test references; related intents; dependency resolution; external-source registration and access dates; internal Markdown links; unchanged baseline hashes; manifest consistency; and ZIP inventory, CRC, and byte-for-byte payload agreement. These checks validate the deliverable, not the product. The manifest is the authoritative check record.

## Complete catalogue

The catalogue is in priority order. IDs remain stable if a later authorized review changes the rank. The complete question, experiment, evidence, and rejection signal are in each linked brief and in the JSON index.

| Priority | ID and title | Category | Kind |
| --- | --- | --- | --- |
| 1 | [R026 — Reconcile missing, blank, invalid, and converted-value counts](ideas/R026-missing-state-accounting.md) | Data quality and missingness | robustness |
| 2 | [R043 — Reconcile entity-aware aggregation across preparation paths](ideas/R043-entity-grain-parity.md) | Data preparation and relationships | robustness |
| 3 | [R077 — Selection identity when source rows are replaced](ideas/R077-selection-identity-when-source-rows-are-replaced.md) | Embedding and package contracts | robustness |
| 4 | [R001 — Regression reliability after changing units and coordinate offsets](ideas/R001-regression-conditioning.md) | Scientific analysis | robustness |
| 5 | [R051 — Make filter ownership and self-exclusion understandable](ideas/R051-filter-ownership.md) | Selection and analytical scope | robustness |
| 6 | [R086 — Recoverable autosave after mixed file outcomes](ideas/R086-recoverable-autosave-after-mixed-file-outcomes.md) | Local and database workflows | robustness |
| 7 | [R031 — Explain ambiguous date conversions before applying them](ideas/R031-date-ambiguity-preview.md) | Types, quantities, and dates | follow-up |
| 8 | [R011 — Retention maturity grounded in an observation cutoff](ideas/R011-retention-observation-cutoff.md) | Domain analysis | robustness |
| 9 | [R073 — Challenge example conclusions with deliberate counterexamples](ideas/R073-example-claim-challenges.md) | Documentation and examples | robustness |
| 10 | [R064 — Explain frozen notebook results and dependent definitions](ideas/R064-notebook-frozen-results.md) | Notebooks and narrative | robustness |
| 11 | [R078 — Independent workspace ownership for dialogs and exports](ideas/R078-independent-workspace-ownership-for-dialogs-and-exports.md) | Embedding and package contracts | robustness |
| 12 | [R059 — Keep focus and Escape predictable across nested editors](ideas/R059-nested-focus-ownership.md) | Accessibility and interaction | robustness |
| 13 | [R088 — Bind cached database snapshots to their source definition](ideas/R088-bind-cached-database-snapshots-to-their-source-definition.md) | Local and database workflows | robustness |
| 14 | [R056 — Compare contributor sets when two views disagree](ideas/R056-contributor-set-comparison.md) | Inspection and provenance | new-direction |
| 15 | [R100 — Published-package behavior in small real consumer projects](ideas/R100-published-package-behavior-in-small-real-consumer-projects.md) | Embedding and package contracts | robustness |
| 16 | [R024 — Keep chart and composition wrappers faithful to shared reducers](ideas/R024-shared-reducer-adapters.md) | Composed graphics | simplification |
| 17 | [R076 — Canonical settings across host echo and restore](ideas/R076-canonical-settings-across-host-echo-and-restore.md) | Embedding and package contracts | robustness |
| 18 | [R054 — Define lasso selection by reproducible membership](ideas/R054-lasso-membership.md) | Selection and analytical scope | follow-up |
| 19 | [R082 — Cross-format fidelity through the full analysis lifecycle](ideas/R082-cross-format-fidelity-through-the-full-analysis-lifecycle.md) | Import, export, and persistence | robustness |
| 20 | [R097 — Small analytical invariants across complete user workflows](ideas/R097-small-analytical-invariants-across-complete-user-workflows.md) | Testing and reproducibility | robustness |
| 21 | [R094 — Performance budgets for complete analytical interactions](ideas/R094-performance-budgets-for-complete-analytical-interactions.md) | Measured performance | robustness |
| 22 | [R055 — Explain why a source row has no visible mark](ideas/R055-row-visibility-explanations.md) | Inspection and provenance | robustness |
| 23 | [R057 — Choose a keyboard model for dense scatter exploration](ideas/R057-dense-scatter-keyboard.md) | Accessibility and interaction | follow-up |
| 24 | [R040 — Expose relationship expansion before it changes analytical grain](ideas/R040-expansion-cardinality-preflight.md) | Data preparation and relationships | robustness |
| 25 | [R044 — Preserve the cause of failed calculations through dependency chains](ideas/R044-calculation-error-propagation.md) | Calculations and expressions | robustness |
| 26 | [R029 — Make type inference changes understandable across datasets](ideas/R029-inference-stability.md) | Types, quantities, and dates | robustness |
| 27 | [R079 — Actionable diagnostics for rejected saved analyses](ideas/R079-actionable-diagnostics-for-rejected-saved-analyses.md) | Import, export, and persistence | robustness |
| 28 | [R090 — Database cancellation before and between result batches](ideas/R090-database-cancellation-before-and-between-result-batches.md) | Local and database workflows | robustness |
| 29 | [R018 — Quantile and outlier conventions that agree with the question](ideas/R018-quantile-conventions.md) | Distribution semantics | robustness |
| 30 | [R012 — Funnel conclusions under tied timestamps and repeated entry](ideas/R012-funnel-ambiguous-order.md) | Domain analysis | robustness |
| 31 | [R061 — Preserve meaning when color is unavailable or ambiguous](ideas/R061-noncolor-meaning.md) | Accessibility and interaction | robustness |
| 32 | [R033 — Stress the date parser at precision and offset boundaries](ideas/R033-date-boundary-validity.md) | Types, quantities, and dates | robustness |
| 33 | [R019 — Stable composition scales when filtered aggregates grow](ideas/R019-composition-scale-envelopes.md) | Composed graphics | follow-up |
| 34 | [R006 — Comparable populations across correlation matrix cells](ideas/R006-matrix-populations.md) | Scientific analysis | robustness |
| 35 | [R087 — External file edits without losing the analyst’s draft](ideas/R087-external-file-edits-without-losing-the-analyst-s-draft.md) | Local and database workflows | robustness |
| 36 | [R089 — Calibrate snapshot byte limits against actual resource cost](ideas/R089-calibrate-snapshot-byte-limits-against-actual-resource-cost.md) | Local and database workflows | robustness |
| 37 | [R093 — Discard stale worker computation as well as stale results](ideas/R093-discard-stale-worker-computation-as-well-as-stale-results.md) | Measured performance | follow-up |
| 38 | [R060 — Make chart summaries answer an analytical question](ideas/R060-analytical-text-alternatives.md) | Accessibility and interaction | follow-up |
| 39 | [R017 — Waterfall reconciliation when a state is absent or unusable](ideas/R017-waterfall-state-reconciliation.md) | Domain analysis | robustness |
| 40 | [R047 — Make conditional truthiness predictable for mixed scalar values](ideas/R047-conditional-truthiness.md) | Calculations and expressions | robustness |
| 41 | [R099 — Checkpoint representation for fast and recoverable browser history](ideas/R099-checkpoint-representation-for-fast-and-recoverable-browser-history.md) | Import, export, and persistence | follow-up |
| 42 | [R085 — Image export fidelity under fonts and mixed rendering](ideas/R085-image-export-fidelity-under-fonts-and-mixed-rendering.md) | Import, export, and persistence | robustness |
| 43 | [R035 — Define rolling results from exact contributors](ideas/R035-rolling-contributor-semantics.md) | Types, quantities, and dates | follow-up |
| 44 | [R053 — Select exact category combinations without cross-product surprises](ideas/R053-exact-tuple-selections.md) | Selection and analytical scope | follow-up |
| 45 | [R022 — Prove the distinction between composition windows and populations](ideas/R022-composition-population-windows.md) | Composed graphics | robustness |
| 46 | [R020 — Make repaired and contradictory interval bands inspectable](ideas/R020-supplied-band-meaning.md) | Composed graphics | robustness |
| 47 | [R083 — Cancellation that stops expensive file preparation](ideas/R083-cancellation-that-stops-expensive-file-preparation.md) | Measured performance | robustness |
| 48 | [R028 — Define explicit expectations for absent observations](ideas/R028-expected-record-reconciliation.md) | Data quality and missingness | follow-up |
| 49 | [R027 — Choose an actionable representation for joint missingness](ideas/R027-joint-missingness-triage.md) | Data quality and missingness | follow-up |
| 50 | [R052 — Find the smallest useful recovery from an empty selection](ideas/R052-empty-selection-recovery.md) | Selection and analytical scope | new-direction |
| 51 | [R008 — Histogram boundaries that match an engineering decision](ideas/R008-engineering-bin-boundaries.md) | Distribution semantics | follow-up |
| 52 | [R046 — Compare safe calculated-field renames with the current guard](ideas/R046-calculation-rename-contract.md) | Calculations and expressions | follow-up |
| 53 | [R039 — Choose explicit repair policies for duplicate entity keys](ideas/R039-duplicate-key-repair.md) | Data preparation and relationships | follow-up |
| 54 | [R067 — Bind one narrative value to an existing analytical result](ideas/R067-single-narrative-binding.md) | Notebooks and narrative | follow-up |
| 55 | [R069 — Choose explicit inheritance for overview-to-detail navigation](ideas/R069-detail-filter-inheritance.md) | Selection and analytical scope | follow-up |
| 56 | [R045 — Clarify or simplify scalar aggregate function names](ideas/R045-scalar-function-names.md) | Calculations and expressions | simplification |
| 57 | [R074 — Reduce example maintenance while preserving useful coverage](ideas/R074-example-catalogue-simplification.md) | Documentation and examples | simplification |
| 58 | [R070 — Teach existing chart gestures at the moment they matter](ideas/R070-gesture-discoverability.md) | Accessibility and interaction | simplification |
| 59 | [R096 — Exact point picking when scatter clouds become dense](ideas/R096-exact-point-picking-when-scatter-clouds-become-dense.md) | Measured performance | follow-up |
| 60 | [R095 — Bound retained memory during repeated dataset changes](ideas/R095-bound-retained-memory-during-repeated-dataset-changes.md) | Measured performance | robustness |
| 61 | [R007 — Density sensitivity before interpreting apparent clusters](ideas/R007-density-sensitivity.md) | Scientific analysis | robustness |
| 62 | [R002 — Residual diagnostics that preserve the fitted population](ideas/R002-residual-diagnostics.md) | Scientific analysis | follow-up |
| 63 | [R003 — Expose fit sensitivity before adding more regression methods](ideas/R003-fit-sensitivity.md) | Scientific analysis | simplification |
| 64 | [R004 — A descriptive covariance ellipse with an explicit reference population](ideas/R004-covariance-ellipse.md) | Scientific analysis | follow-up |
| 65 | [R005 — Rank correlation as a bounded pair-discovery option](ideas/R005-rank-correlation.md) | Scientific analysis | follow-up |
| 66 | [R016 — Regional comparisons with trustworthy denominators](ideas/R016-regional-rate-denominators.md) | Domain analysis | follow-up |
| 67 | [R084 — An explicit analytical contract for exported CSV](ideas/R084-an-explicit-analytical-contract-for-exported-csv.md) | Import, export, and persistence | follow-up |
| 68 | [R091 — Local database readiness with optional native dependencies](ideas/R091-local-database-readiness-with-optional-native-dependencies.md) | Local and database workflows | follow-up |
| 69 | [R032 — Separate civil dates, instants, and numeric epoch conventions](ideas/R032-temporal-meaning-contract.md) | Types, quantities, and dates | follow-up |
| 70 | [R034 — Choose reproducible semantics for stepping calendar windows](ideas/R034-calendar-window-stepping.md) | Types, quantities, and dates | follow-up |
| 71 | [R041 — Design explicit join-key preparation without implicit coercion](ideas/R041-join-key-preparation.md) | Data preparation and relationships | new-direction |
| 72 | [R030 — Evaluate explicit locale-aware numeric preparation](ideas/R030-locale-numeric-conversion.md) | Types, quantities, and dates | new-direction |
| 73 | [R038 — Compare reversible category mappings with automatic clustering](ideas/R038-category-normalization.md) | Data preparation and relationships | new-direction |
| 74 | [R025 — Decide the product role of 3D scatter through analytical tasks](ideas/R025-three-dimensional-value.md) | Scientific analysis | simplification |
| 75 | [R042 — Find a minimal reusable wide-to-long reshaping contract](ideas/R042-wide-long-reshape.md) | Data preparation and relationships | new-direction |
| 76 | [R049 — Specify deterministic lag and difference preparation](ideas/R049-ordered-difference-transforms.md) | Data preparation and relationships | new-direction |
| 77 | [R048 — Choose the smallest useful text-preparation function set](ideas/R048-text-preparation-functions.md) | Calculations and expressions | new-direction |
| 78 | [R050 — Reuse existing calculations for bounded data-quality assertions](ideas/R050-bounded-quality-assertions.md) | Data quality and missingness | simplification |
| 79 | [R062 — Simplify field choice without hiding the evidence](ideas/R062-field-choice-simplification.md) | Accessibility and interaction | simplification |
| 80 | [R072 — Explain settings in the context where their meaning changes](ideas/R072-contextual-setting-help.md) | Documentation and examples | robustness |
| 81 | [R071 — Route documentation by the analytical task and its prerequisites](ideas/R071-task-based-doc-routing.md) | Documentation and examples | follow-up |
| 82 | [R065 — Link notebook charts only within an explicit analytical scope](ideas/R065-notebook-linked-scopes.md) | Notebooks and narrative | follow-up |
| 83 | [R066 — Navigate notebook explanations through their shared definitions](ideas/R066-notebook-definition-navigation.md) | Notebooks and narrative | new-direction |
| 84 | [R068 — Keep authored conclusions attached to their evidence scope](ideas/R068-narrative-claim-scope.md) | Notebooks and narrative | new-direction |
| 85 | [R058 — Make tracing practical on touch and pen input](ideas/R058-touch-trace-access.md) | Accessibility and interaction | robustness |
| 86 | [R063 — Define useful analytical reading at narrow widths](ideas/R063-narrow-analysis-reading.md) | Accessibility and interaction | follow-up |
| 87 | [R080 — A credible selective-chart integration contract](ideas/R080-a-credible-selective-chart-integration-contract.md) | Embedding and package contracts | simplification |
| 88 | [R081 — Headless chart images through a minimal existing renderer](ideas/R081-headless-chart-images-through-a-minimal-existing-renderer.md) | Import, export, and persistence | follow-up |
| 89 | [R092 — When wider snapshots change the row-JSON transport decision](ideas/R092-when-wider-snapshots-change-the-row-json-transport-decision.md) | Measured performance | follow-up |
| 90 | [R037 — Choose a precision contract for financial and exact-decimal work](ideas/R037-decimal-precision-contract.md) | Types, quantities, and dates | new-direction |
| 91 | [R036 — Test whether lightweight unit semantics prevent bad calculations](ideas/R036-quantity-unit-semantics.md) | Types, quantities, and dates | new-direction |
| 92 | [R009 — Weighted empirical distributions without replicated source rows](ideas/R009-weighted-ecdf.md) | Distribution semantics | new-direction |
| 93 | [R010 — Reveal pooled-versus-group reversals without causal claims](ideas/R010-pooled-group-reversals.md) | Scientific analysis | new-direction |
| 94 | [R013 — Concurrency summaries with explicit interval semantics](ideas/R013-timeline-concurrency.md) | Domain analysis | follow-up |
| 95 | [R015 — Keep consequential flows visible when Sankey folds categories](ideas/R015-sankey-important-flows.md) | Domain analysis | robustness |
| 96 | [R023 — A bounded policy when composition end labels cannot fit](ideas/R023-composition-label-budget.md) | Composed graphics | simplification |
| 97 | [R098 — Small reproducible cases that preserve analytical failures](ideas/R098-small-reproducible-cases-that-preserve-analytical-failures.md) | Testing and reproducibility | new-direction |
| 98 | [R075 — Explain the analytical consequences of a large applied edit](ideas/R075-applied-edit-explanations.md) | Inspection and provenance | follow-up |
| 99 | [R014 — Select explicit edges without changing their accounting grain](ideas/R014-explicit-edge-selection.md) | Domain analysis | follow-up |
| 100 | [R021 — A gradient along a path that represents source values](ideas/R021-path-gradient-semantics.md) | Composed graphics | follow-up |
