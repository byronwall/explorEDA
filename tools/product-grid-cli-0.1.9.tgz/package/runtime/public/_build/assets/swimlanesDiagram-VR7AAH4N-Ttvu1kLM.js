import{c as r,s as e}from"./flowDiagram-HODETNUW-xbHCLDW0.js";import{_ as o}from"./mermaid.core-ZKYU8Nwt.js";import"./chunk-5VM5RSS4-Drcq3JIa.js";import"./chunk-XXDRQBXY-Ce6Td-r2.js";import"./chunk-POPQ4Y6H-No270m5L.js";import"./chunk-F27PBJKO-DjUOTId0.js";import"./channel-e8soZ3TG.js";import"./checkbox-CSTeV8KU.js";import"./download-ByKd5EU7.js";import"./toast-BCCH1-f7.js";import"./_projectId_-Cv3H0GG9.js";import"./simple-dialog-DcSb1R_B.js";import"./vstack-BO0ql49N.js";import"./seo-BJXGIT8y.js";var m=o(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),a=m,k=r({defaultLayout:"swimlane",styles:a});export{k as diagram};
