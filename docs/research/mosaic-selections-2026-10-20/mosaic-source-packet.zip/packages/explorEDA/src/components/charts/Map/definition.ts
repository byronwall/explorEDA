import { Map as MapIcon } from "lucide-react";
import { applyFilter } from "@/hooks/applyFilter";
import type { BaseChartSettings, ChartDefinition } from "@/types/ChartTypes";
import { DEFAULT_CHART_SETTINGS } from "@/utils/defaultSettings";
import { MapChart } from "./MapChart";
import { MapSettingsPanel } from "./MapSettingsPanel";

export interface MapView {
  /** Geographic degrees, longitude first. Zoom is relative to the world view. */
  center: [number, number];
  zoom: number;
}
export interface MapSettings extends BaseChartSettings {
  type: "map";
  mode: "point" | "region";
  geometryAssetId?: string;
  regionField?: string;
  featureKey?: string;
  aggregation?: "count" | "sum" | "average";
  measureField?: string;
  showRegionLabels?: boolean;
  outlineWidth?: number;
  latitudeField: string;
  longitudeField: string;
  labelField?: string;
  sizeField?: string;
  pointRadius: number;
  pointOpacity: number;
  projection: "equal-earth" | "equirectangular";
  /** Draw the points; off leaves selections and filters unchanged. */
  showMarks?: boolean;
  /** Group crowded points into counted circles. Off unless true. */
  clusterPoints?: boolean;
  /** Write each point's label beside it. */
  showLabels?: boolean;
  /** Boundaries drawn beneath points for reference, by geometry ID. */
  referenceAssetId?: string;
  /** Auto shows streets when zoomed in and a street engine is registered. */
  basemap?: "auto" | "outline" | "none";
  view?: MapView;
}
export const mapDefinition: ChartDefinition<MapSettings> = {
  type: "map",
  name: "Map",
  description: "Locate records or compare measures across regions",
  icon: MapIcon,
  component: MapChart,
  settingsPanel: MapSettingsPanel,
  createDefaultSettings: (layout) => ({
    ...DEFAULT_CHART_SETTINGS,
    id: crypto.randomUUID(),
    type: "map",
    mode: "point",
    title: "",
    field: "",
    latitudeField: "",
    longitudeField: "",
    pointRadius: 6,
    pointOpacity: 0.8,
    projection: "equal-earth",
    layout,
    filters: [],
  }),
  validateSettings: (settings) =>
    settings.mode === "region"
      ? Boolean(
          settings.geometryAssetId &&
            settings.regionField &&
            settings.featureKey &&
            (settings.aggregation === "count" || settings.measureField)
        )
      : Boolean(settings.latitudeField && settings.longitudeField),
  getFilterFunction: (settings, getColumn) => {
    const filters = settings.filters.map((filter) => ({
      filter,
      values: getColumn(filter.field),
    }));
    return (id) =>
      filters.every(({ filter, values }) => applyFilter(values[id], filter));
  },
};
