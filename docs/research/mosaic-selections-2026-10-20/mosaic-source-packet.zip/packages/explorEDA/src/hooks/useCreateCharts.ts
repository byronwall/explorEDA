import { getChartDefinition } from "@/charts/registry";
import {
  useDataLayer,
  useDataLayerSnapshot,
} from "@/providers/DataLayerProvider";
import { ChartLayout, ChartType } from "@/types/ChartTypes";

export function useCreateCharts() {
  const profiles = useDataLayer((s) => s.fieldProfiles);
  // Read when a chart is built; a subscription would re-render every caller.
  const getState = useDataLayerSnapshot();
  const addChart = useDataLayer((s) => s.addChart);

  /** Default settings for a new chart, without adding it to the grid. */
  const buildChart = (
    type: ChartType,
    field: string,
    initialLayout?: ChartLayout
  ) => {
    const layout = initialLayout ?? {
      x: 0,
      y: Math.max(
        0,
        ...getState().charts.map((chart) => chart.layout.y + chart.layout.h)
      ),
      w: type === "metric-card" ? 4 : type === "composition" ? 12 : 6,
      h: type === "metric-card" ? 3 : type === "composition" ? 7 : 4,
    };

    const definition = getChartDefinition(type);
    if (!definition) {
      throw new Error(`Chart type ${type} not registered`);
    }

    const numeric = profiles
      .filter((profile) => profile.dataType === "numeric")
      .map((profile) => profile.name);
    const categories = profiles
      .filter((profile) => profile.dataType !== "numeric")
      .map((profile) => profile.name);
    const selectedField =
      field ||
      (type === "row" ||
      type === "heatmap" ||
      type === "waterfall" ||
      type === "donut"
        ? categories[0]
        : numeric[0]) ||
      profiles[0]?.name ||
      "";
    const settings = definition.createDefaultSettings(layout, selectedField);
    if (settings.type === "scatter" || settings.type === "3d-scatter") {
      settings.xField = numeric[0] || "__ID";
      settings.yField = field || numeric[1] || numeric[0] || "__ID";
      settings.xAxisLabel = "";
      settings.yAxisLabel = "";
      if (settings.type === "3d-scatter")
        settings.zField = numeric[2] || numeric[0] || "__ID";
    }
    if (settings.type === "line") {
      settings.xField = "__ID";
      settings.seriesField = selectedField ? [selectedField] : [];
      settings.xAxisLabel = "";
      settings.yAxisLabel = "";
    }
    if (settings.type === "data-table")
      settings.columns = profiles
        .slice(0, 8)
        .map((profile) => ({ id: profile.name, field: profile.name }));
    if (settings.type === "pivot") {
      settings.rowFields = categories.slice(0, 1);
      settings.columnField = categories[1] || "";
      settings.valueFields = selectedField
        ? [{ field: selectedField, aggregation: "count" }]
        : [];
    }
    if (settings.type === "color-legend")
      settings.fields = categories.slice(0, 1);
    if (settings.type === "bar" || settings.type === "row") {
      settings.xAxisLabel = settings.type === "row" ? "Records" : "";
      settings.yAxisLabel = settings.type === "bar" ? "Records" : "";
    }
    if (settings.type === "boxplot") settings.yAxisLabel = "";
    if (settings.type === "sankey") {
      // Few-valued categories make readable stages.
      const stages = profiles
        .filter(
          (profile) =>
            profile.dataType !== "numeric" && profile.uniqueCount <= 12
        )
        .map((profile) => profile.name);
      const start = stages.includes(selectedField) ? [selectedField] : [];
      settings.stages = [...new Set([...start, ...stages])].slice(0, 3);
    }
    if (settings.type === "funnel") {
      // An event log: a few-valued event field, a date, and a many-valued ID.
      const fewValued = (name: string) => {
        const profile = profiles.find((item) => item.name === name);
        return (
          profile?.dataType === "categorical" &&
          profile.uniqueCount >= 2 &&
          profile.uniqueCount <= 30
        );
      };
      const event = fewValued(field)
        ? field
        : (profiles.find((profile) => fewValued(profile.name))?.name ?? "");
      const time =
        profiles.find((profile) => profile.dataType === "datetime")?.name ?? "";
      const entity =
        profiles
          .filter(
            (profile) =>
              profile.dataType === "categorical" &&
              profile.name !== event &&
              profile.name !== time
          )
          .sort((a, b) => b.uniqueCount - a.uniqueCount)[0]?.name ?? "";
      settings.field = event;
      settings.timeField = time;
      settings.entityField = entity;
      settings.steps = (
        profiles.find((profile) => profile.name === event)?.categories
          ?.topValues ?? []
      )
        .slice(0, 4)
        .map((item) => item.value);
    }
    if (settings.type === "timeline") {
      // Two dates make an interval; a few-valued category makes the lanes.
      const dates = profiles
        .filter((profile) => profile.dataType === "datetime")
        .map((profile) => profile.name);
      settings.startField = dates[0] ?? "";
      settings.endField = dates[1] ?? "";
      settings.field =
        profiles.find(
          (profile) =>
            profile.dataType === "categorical" &&
            profile.uniqueCount >= 2 &&
            profile.uniqueCount <= 40
        )?.name ?? "";
    }
    if (settings.type === "retention") {
      // An event log: a date and a many-valued ID; every event counts.
      settings.timeField =
        profiles.find((profile) => profile.dataType === "datetime")?.name ?? "";
      settings.entityField =
        profiles
          .filter(
            (profile) =>
              profile.dataType === "categorical" &&
              profile.name !== settings.timeField
          )
          .sort((a, b) => b.uniqueCount - a.uniqueCount)[0]?.name ?? "";
      settings.field = "";
    }
    if (settings.type === "hierarchy") {
      // Nest few-valued categories, the selected one outermost.
      const levels = profiles
        .filter(
          (profile) =>
            profile.dataType !== "numeric" && profile.uniqueCount <= 12
        )
        .map((profile) => profile.name);
      const start = levels.includes(selectedField) ? [selectedField] : [];
      settings.levels = [...new Set([...start, ...levels])].slice(0, 2);
    }
    if (settings.type === "scatter-matrix") {
      // Numbers first, then a few low-cardinality categories.
      const groups = profiles
        .filter(
          (profile) =>
            profile.dataType !== "numeric" &&
            profile.uniqueCount > 1 &&
            profile.uniqueCount <= 12
        )
        .map((profile) => profile.name);
      const start = selectedField ? [selectedField] : [];
      settings.fields = [
        ...new Set([...start, ...numeric.slice(0, 4), ...groups.slice(0, 1)]),
      ].slice(0, 5);
    }
    if (settings.type === "parallel-coordinates") {
      const start = numeric.includes(selectedField) ? [selectedField] : [];
      settings.axes = [...new Set([...start, ...numeric])]
        .slice(0, 5)
        .map((name) => ({ field: name, inverted: false }));
    }
    if (settings.type === "calendar" && !field)
      settings.field =
        profiles.find((profile) => profile.dataType === "datetime")?.name ??
        settings.field;
    if (settings.type === "heatmap")
      settings.columnField =
        categories.find((name) => name !== settings.field) ?? "";
    if (settings.type === "ecdf" && !numeric.includes(settings.field))
      settings.field = numeric[0] ?? settings.field;
    settings.title = "";
    return settings;
  };

  const createChart = (
    type: ChartType,
    field: string,
    initialLayout?: ChartLayout
  ) => {
    addChart(buildChart(type, field, initialLayout));
  };

  return { buildChart, createChart };
}
