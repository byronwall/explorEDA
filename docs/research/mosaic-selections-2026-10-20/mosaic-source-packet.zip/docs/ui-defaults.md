# UI defaults

The workspace helps users inspect data while keeping the current scope clear. Controls must support that task without covering it.

## Density

Spend space on data, not chrome. Every surface shares one compact scale:

- Controls are 32 px tall by default and 28 px inside settings, popovers, and side panels. Small buttons are 28 px.
- A setting is one row: its label in a 100 px column beside its control (`eda-setting-grid`). Do not stack a label above a control in settings.
- Options of one choice sit in one segmented row. Shorten their visible labels and explain each in its tooltip.
- Group related settings under a small heading divided by a rule (`eda-setting-section`), not inside nested bordered boxes.
- Put a panel's actions in its first line. Do not open a panel or popover with a paragraph that explains it; put the explanation in the tooltip of the control it explains.
- Lay out tabs in one row that scrolls sideways when it must; never wrap them.
- Let editors fill the space their panel gives them. A table sizes each column to its name, distribution, and values, leaves spare width empty at the right instead of spreading the columns apart, and scrolls only when its columns need more room.
- Line up a chart's title, plot, and content with the panel's left padding. Hidden header controls take no room.
- Below 960 px the grid shows a view-only flow of the saved layout: two charts to a row from 640 px, and one below that. Charts wider than half the grid take the whole row.

## Borders and focus

Use these tokens:

| Purpose                                   | Token                        |
| ----------------------------------------- | ---------------------------- |
| Neutral panel, table, divider, or popover | `--border` / `border-border` |
| Input boundary                            | `--input` / `border-input`   |
| Keyboard focus                            | `--ring`                     |
| Invalid input or error                    | `--destructive`              |
| Conversion warning                        | `--warning`                  |

Keep default borders soft in both themes. Do not use literal colors or Tailwind palette colors for borders.
The base rule must also cover portals and survive a host application's Tailwind reset.
Run `pnpm check:ui` to reject native title attributes, SVG `<title>` elements, and raw border colors.

## Tooltips and field details

- Give each icon button an accessible action name.
- Use `ActionTooltip` or `Button tooltip` for important icon actions. The shared delay is 140 ms.
- Open tooltips on pointer hover only. Focus return must not open them. Keep accessible names and keyboard focus indicators.
- Omit hover text that only repeats visible text.
- Explain toggles, abbreviated options, and settings that differ subtly with a real tooltip that says what each choice does and why it differs. Never use a `title` attribute.
- Identify a statistic by field and meaning. Never show an unexplained duplicate number.
- Use `FieldMetadata` for type, range or sample, distinct values, and null counts.
- Keep field metadata based on the correct data scope. A filtered summary must describe filtered rows.
- Keep field controls on one line. Put the type icon before the name and move details into the tooltip.
- Keep table header names on one line. Show actions beside the name without moving it. Keep active filters visible.
- Align a column's header with its cells: numbers right, everything else left. A number column shows its hover actions on the left.
- Show each column's type with the type icon before its name.
- The Rows view draws each field's distribution under its column name, from the rows that pass the chart filters. A click or drag on it filters that column. A data table chart offers the same as a setting.
- A column header has one tooltip, shown above the header so it never covers other headers or rows, and hidden when there is no room above. Hovering the name shows the field summary; hovering a distribution mark adds that mark's value, rows, and share.
- Mark the text a table search matched in every cell that matched.
- A number or date column filter shows the field's distribution above its bounds. A click or drag on it sets the range, and a number field adds a range slider under it. A thumb at the end of the track leaves that side open.
- One filter popover serves a table's columns. Opening another column's filter moves it; it never shows two at once. Popovers close without an exit animation.
- Show a missing table cell as a small, centered monospace `null`, never a dash or a blank.
- Let every filter reach missing values: a Missing count filters to its rows, and column filters offer Only missing values.
- Keep row actions horizontal. Show them on hover and keyboard focus, and keep them available on touch screens.

## Popovers and dialogs

Use compact, nonmodal popovers for local work: field details, filters, chart data, and one chart's settings.
Anchor them to the control or relevant panel. Bound their width and height to the viewport.
Use short tabs when one editor has several distinct tasks. Keep primary actions reachable while content scrolls.
Use a labeled search field and bounded lists for many fields or categories.

Chart settings must keep the chart visible. Prefer space beside the panel, then space above or below it.
When no outside space remains, use a compact corner editor with scrollable controls.
Apply valid chart settings immediately so users can compare the result. Keep a reset action for the current edit session.
Do not add a persistent sidebar for temporary inspection.
Edit a visible chart feature where it is drawn. Double-click, Enter, or F2 on a title opens a field in its place, and its context menu offers the same edit and a reset to the inherited name. The chart shows each keystroke, Escape restores the old text, and the whole edit is one undo step. An editor never starts a chart drag, brush, or shortcut.
A chart's axes span all of its rows before any filtering. Only an edit on that chart changes them. Brushing or filtering on other charts changes which rows a chart shows, never its axes or other settings, so positions stay comparable from one selection to the next. An aggregate a filter pushes past that range, such as a higher average, grows the axis to fit until the filter clears; the axis never shrinks below every row's range.
A numeric axis has a range: an exact minimum and maximum in the Axes settings, each blank to follow the data. A range only changes the view. Marks outside it are clipped, never filtered, and the row count stays the same. A draft that is not a number, or a minimum at or above the maximum, is marked and never applied.
When a range hides marks, a small marker sits inside the plot at that end of the axis, pointing toward them. Hover or focus opens how many are hidden, and a Reset that clears only that end. A press on the marker never brushes or clears the chart's filters.
Scatter axes, the value axis of a line chart, and a box plot's axis can use a true log scale; filled areas and bars cannot, since their heights must stay proportional. Rows at or below zero have no place on it, so they are not drawn; a warning marker at the low end counts them and says why. A box plot still computes its statistics from every value and draws any part at or below zero at the floor. Log never switches to symlog on its own, and a log axis takes only bounds above zero.
Double-click a numeric axis, or pick Set range from its context menu, to edit its range in a small popover beside it. Double-click an axis title, or press Enter on it, to edit the title in place. A soft wash on the axis band shows where these act. Command-click on an axis still inspects its field, and Alt-click still traces. On charts with role labels, such as scatter plots, the axis context menu also offers Change X field… or Change Y field…, which opens the same field picker as the Color label.
Drag along a numeric axis to pan its range, or drag one of its end grips to stretch that end, as if pulling a ruler by that tick. The chart follows the pointer, Escape puts the range back, and the drag is one undo step. The header readout names these gestures while the pointer is on the axis. A drag on an axis never brushes or filters.
The plot area holds the chart only. Usage hints, such as "Click a cell to select", join the status line only while the pointer or focus is on the chart. Optional actions on the plot, such as Fit view, appear the same way. Never show an "Inspect" button on a chart or card. Alt-click or Alt-Enter on a mark opens its trace.
A click on a mark always filters: a bar, box, or category toggles its value, and a histogram bin sets the range to its bounds.
A plain click on empty plot space, away from every mark, clears that chart's filters, as its clear-filter action does. This covers the space above and between bars and a marginal band outside its bins. A drag or brush is never a dead click, and Alt-click stays inspection.
Every part of a chart uses the encoding and treatment of its main marks. Marginals, legends, and overlays stack or color by the same field with the same palette, and dim unselected rows the same way.
Keep a chart's actions in its header: View data, Export image, Duplicate, details, settings, and Delete, each an icon with a tooltip. Clear filters stays visible there while the chart filters. Chart settings hold settings only.
Hidden header actions take no room, so the chart name keeps the full header until the pointer or focus reaches it.
An exported chart image shows the chart as it looks at rest: hover-revealed actions, readouts, and usage hints draw nothing. Mark any new editor-only control `data-export="omit"`: handles, grips, focus buttons, and hints. It keeps its layout and is left out of the picture. Never hide by element type: legend chips are buttons too.
Every right-click menu on a chart ends with Copy image and Download image (`ChartImageMenuSection`). A right-click no other menu answers opens a menu with just those two.
The field list is the one workspace tool that stays open. It floats over the right edge from the top of the viewport, never resizes the chart grid, and becomes a bottom sheet on narrow screens. Controls it covers move beside it. Fields in the toolbar and the F key open it, and Shift+F opens every field's distribution in a full view.

Workspace settings (calculations, theme, colors, and grid) share one panel that floats over the right edge in the field list's place. Each toolbar button opens its tab and closes the panel when pressed again. Every tab stays mounted, so unsaved edits survive a switch. The panel has a narrow and a wide width, and becomes a full sheet on narrow screens. Escape closes it and returns focus to its toolbar button.
The right edge shows one panel at a time. Rows, workspace settings, and host panels replace each other. They cover the field list, which returns when they close.
A host panel, such as the demo's History, gets an icon button beside Fields and Rows, an optional letter shortcut, and the settings panel's narrow and wide sizes. Its wide size shows more detail, not just more room.
While the workspace is read-only, such as during a history preview, the charts and editing tools take no input. The filter scope stays visible and host panels stay usable.

Use a modal only when focus must be protected, such as chart details or a destructive confirmation.
Chart details fill the viewport with the chart on the left and its controls on the right, with Settings open first and Chart data in a second tab. Below 900 px the chart sits above the controls. The grid shows no second copy of the chart, and settings stay live with the same reset action.
Chart details must close with Escape or the close action, lock background scrolling, and restore focus.
Chart spec is read-only. Read its chart inventory, saved layout, and referenced definitions from current workspace state. Keep edits in Chart details.
Escape closes an active nested editor before it closes chart details. A hover tooltip must not swallow it.
Keep a confirmation small and centered: a short question, one sentence that names what is affected, Cancel, and a confirm button that names the action.

## Scope and layout

- Keep the workspace controls in one sticky toolbar line. Host content, such as view tabs, leads on the left (`toolbarStart`). Add chart, then inspection tools (Fields, Rows), then configuration (Calculations, colors, grid, workspace actions) sit on the right, as icon buttons with tooltips, followed by host actions such as undo and export (`toolbarEnd`). Beside an open panel, Add chart shows only its icon. When the line runs out of room, host content keeps the first line and the tools move to a second.
- Keep the row count and active filter scope in a status bar at the bottom of the workspace. It sticks to the bottom of the viewport while the charts scroll, so the scope stays visible. Show the filter chips that fit, then a "+N more" popover that lists every filter, beside the row count and clear action.
- Rows is a drawer over the right of the viewport at full height, not a separate view. It has two sizes, switched from its header. Expanded leaves a strip of charts visible on the left, and a click there dismisses it. Narrow sits beside the charts, which stay in use, so a click on them does not dismiss it. R and Escape dismiss either size. It takes the full width on narrow screens and must not resize the chart grid.
- The expanded Rows drawer covers the toolbar and status bar, so its header carries the row count and active filters. Beside the narrow drawer the status bar keeps its own, and the controls it would cover move beside it. Table tools and the close action stay in the drawer header while rows scroll.
- Give every side inspector a narrow and a wide size: the field list and its full view, workspace settings, and Rows.
- Label local Rows filters and table searches separately from chart filters.
- Add a workspace filter from the status bar's Filter button: a field search, then the field's filter control, in a nonmodal popover beside the button or chip. A field has one workspace filter, so picking a filtered field edits it. Its chip reads "Workspace · Region: West" with the owner muted.
- Keep a clear-filter control visible on every chart with an active filter.
- Chart settings have a Filters tab with a manual control for every filter the chart sets: the fields its marks select, then any other filtered field. Each control matches the field's type and shows its distribution. A selection on the chart and the control stay in step.
- Show the values under the pointer in the chart panel header, beside the title, in one line. A crosshair or highlight marks the point. Do not float a readout over the plot. Under a headline theme the readout covers the end of the subtitle line while the pointer is on the plot, so a reading never moves the header.
- The chart details view enlarges the chart title with the chart.
- A chart has one header, which the workspace theme styles. Compact keeps the title on one line beside the controls. A headline theme, such as Newsprint, wraps the title to two lines above the plot, then clamps it and shows a clip marker whose tooltip suggests a larger chart or a shorter title. The subtitle line under it holds the filter control and table search. Hidden actions float over the title's top-right corner; where they stay shown (touch screens and chart details), they sit in the band above the headline.
- A chart's source note sits under the plot on one line. The header and note take their height from the plot, never from the tile.
- Chart colors follow the workspace theme too. A categorical scale on the Theme palette takes the theme's colors, and each category keeps its slot, so a theme switch never changes which category has which color position. Palette colors lighten in dark mode. Hand-picked colors and fixed palettes stay as chosen and are listed as overrides. Move categories in the scale editor to choose which takes which color.
- Chart type follows the workspace theme unless a chart overrides it on purpose. Size and weight controls offer a Theme choice that clears the override. The Theme tab lists every override by chart, with a reset for each property and for the whole chart. A reset changes type only, never fields, filters, scales, or layout.
- Label filter bounds with their meaning and state where the filter applies.
- Pair a filter's bounds side by side in one row, such as At least and At most, under its distribution.
- Start new source imports with summary and data tables. Let users choose their first chart.
- Preserve the order and layout in saved analyses.
- “View chart data” opens a temporary preview. It must not add a chart or move existing charts.
- Charts rise to fill empty rows above them, so the grid never leaves gaps at the top. A resize changes only the edge the user drags; the chart keeps its place among its neighbors.
- A new chart starts in the rows the user can see, never scrolling the page. Free space in view comes first, then the first chart edge in view.
- Placing a new chart on an occupied spot proposes moving the charts in its way down. Show them at their proposed positions before the user accepts. Apply the new chart and the moves together on accept. Back and Cancel leave every chart where it was.
- Preview limits must be visible, such as “first 100 shown.”
- Use a compact Columns trigger. Show selected columns inside a searchable popover, not a shelf of pills.
- Pick sets of fields with the shared `FieldPicker`. It shows the field list's rows (type, name, distinct, missing, and distribution) with a checkbox, and drops readings in narrow containers.
- Drag a column by its name: sideways to reorder it, or away from the header to hide it. A line marks the drop position and a chip names the column. The column menu offers the same moves for keyboard and touch.
- Right-click a table header or cell for its menu. A header offers filter, sort, move, hide, and copy name. A cell offers copy, filters built from its value, sort, and hide. Shift+right-click keeps the browser menu.

## Verification

The demo dev server runs the library from source, so browser checks need no build; see [Verifying changes](../AGENTS.md#verifying-changes).
Vite can reload the page when test files change. During concurrent source edits, check a frozen build with `EXPLOREDA_DIST=1` instead.

Check changed flows at 1280 px, 783 px, and 390 px widths. Use real pointer and keyboard input.
Check long field names, null values, active filters, many categories, and empty results.
Check that popovers remain within the viewport and leave primary actions reachable.
Confirm that header actions do not cover names and field details add useful information.
Check light and dark borders, quick tooltips, focus return, and background scroll locking.
Run `pnpm check` before delivery. Tests protect data scope, temporary previews, and dismissal behavior.
