import type { ChartTrace } from "./traceTypes";

/**
 * The runtime row IDs behind a traced mark, for traces that stand for rows.
 * Guides, titles, and legends have none.
 */
export function traceRowIds(trace: ChartTrace): number[] | undefined {
  switch (trace.kind) {
    case "metric-card":
      return trace.plan.contributors.map((item) => item.sourceId);
    case "timeline-interval":
      return [trace.interval.id];
    case "retention-cell":
      return trace.cell.rows;
    case "funnel-step":
      return trace.step.contributors.map((item) => item.sourceId);
    case "donut-slice":
      return trace.slice.row.contributors.map((item) => item.sourceId);
    case "waterfall-bar":
      return [
        ...(trace.bar.states ?? []),
        ...(trace.bar.rows ? [trace.bar.rows] : []),
      ].flatMap((state) => state.contributors.map((item) => item.sourceId));
    case "bar":
      return trace.mark.row.contributors.map((item) => item.sourceId);
    case "time-bucket":
      return trace.point?.contributors.map((item) => item.sourceId);
    case "point":
      return [trace.sourceId];
    case "composition":
      return trace.rowIds;
    default:
      return undefined;
  }
}
