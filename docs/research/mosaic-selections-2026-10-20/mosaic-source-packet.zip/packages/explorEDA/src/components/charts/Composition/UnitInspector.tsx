import { FieldSelector } from "@/components/FieldSelector";
import { NumericInputEnter } from "@/components/NumericInputEnter";
import { Button } from "@/components/ui/button";
import { ActionTooltip } from "@/components/ui/tooltip";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useDataLayer } from "@/providers/DataLayerProvider";
import { describeMark } from "./markSummary";
import { FilterListEditor } from "@/components/settings/FiltersSettingsTab";
import {
  AreaChart,
  BarChartHorizontal,
  CandlestickChart,
  ChartColumnStacked,
  Donut as DonutIcon,
  GanttChart,
  Grid3x3,
  Layers,
  LayoutGrid,
  Mountain,
  Plus,
  ScatterChart,
  Spline,
  Trash2,
  Waves,
  type LucideIcon,
} from "lucide-react";
import { Fragment, useEffect, useId, useRef, useState } from "react";
import {
  createInset,
  MUTED_MARK,
  newMarkId,
  type BandMark,
  type DensityMark,
  type WaffleMark,
  type BarMark,
  type DonutMark,
  type WaterfallMark,
  type SpanMark,
  type HorizonMark,
  type FrameWindow,
  type InsetFrame,
  type InstanceOverride,
  type CompositionCalculation,
  type CompositionDefinition,
  type CompositionScale,
  type FieldChoice,
  type MarkDefinition,
  type MarkType,
  type PathMark,
  type PointMark,
  type RepeatRule,
  type StackMark,
  type StripMark,
  type SummaryMark,
  type SummaryParts,
  type ValueSign,
  type UnitElement,
  isXyMark,
} from "./compositionTypes";
import { convertMark, updateElement } from "./compositionEdits";
import {
  ColorSetting,
  NumberSetting,
  PairSetting,
  Segmented,
} from "./inspectorControls";

const ARRANGEMENTS = [
  {
    value: "rows" as const,
    label: "Rows",
    tooltip: "Stack the repeats in one column, labeled on the left",
  },
  {
    value: "columns" as const,
    label: "Columns",
    tooltip: "Place the repeats side by side, labeled above",
  },
  {
    value: "grid" as const,
    label: "Grid",
    tooltip: "Wrap the repeats into a grid with a set number of columns",
  },
  {
    value: "tiles" as const,
    label: "Tiles",
    tooltip:
      "Place each repeat at the cell a field names as row,column, such as a state's place on a tile map",
  },
];

const ORDERS = [
  {
    value: "count" as const,
    label: "Most rows",
    tooltip: "Put the subsets with the most rows first",
  },
  {
    value: "label" as const,
    label: "A–Z",
    tooltip: "Order the subsets by name, with numbers in numeric order",
  },
  {
    value: "value" as const,
    label: "By value",
    tooltip:
      "Order the subsets by a per-repeat calculation, such as each one's change or total. Reads every row, so filters do not reorder.",
  },
];

const DIRECTIONS = [
  {
    value: "asc" as const,
    label: "Low first",
    tooltip: "Smallest value at the top or left",
  },
  {
    value: "desc" as const,
    label: "High first",
    tooltip: "Largest value at the top or left",
  },
];

const RANK_OPTIONS = [
  { value: "value" as const, label: "Value", tooltip: "The y field's value" },
  {
    value: "desc" as const,
    label: "Rank ↓",
    tooltip:
      "Each row's rank among the rows at the same x, largest value first; rank 1 sits at the top, as a bump chart",
  },
  {
    value: "asc" as const,
    label: "Rank ↑",
    tooltip:
      "Each row's rank among the rows at the same x, smallest value first; rank 1 sits at the top",
  },
];
const PATH_LABEL_OPTIONS = [
  {
    value: "none" as const,
    label: "Nowhere",
    tooltip: "No labels on the path",
  },
  {
    value: "start" as const,
    label: "Start",
    tooltip: "Name each path beside its first point",
  },
  {
    value: "end" as const,
    label: "End",
    tooltip: "Name each path beside its last point, in place of a legend",
  },
  {
    value: "both" as const,
    label: "Both",
    tooltip: "Name each path at both ends, as a slope chart reads",
  },
];
const LABEL_VALUE_OPTIONS = [
  { value: false, label: "Name", tooltip: "The series or repeat name alone" },
  {
    value: true,
    label: "Value and name",
    tooltip: "The y value at that end before the name",
  },
];
const SPREAD_OPTIONS = [
  {
    value: "line" as const,
    label: "On the line",
    tooltip: "Every dot sits on the middle line; dots with the same x overlap",
  },
  {
    value: "swarm" as const,
    label: "Swarm",
    tooltip:
      "Dots move off the line just far enough to clear their neighbors, as a beeswarm, so crowded values show their count",
  },
];
const SHOW_OPTIONS = [
  { value: "all" as const, label: "All", tooltip: "Draw every row" },
  {
    value: "first" as const,
    label: "First",
    tooltip: "Draw only the first row in order",
  },
  {
    value: "last" as const,
    label: "Last",
    tooltip: "Draw only the last row in order",
  },
  {
    value: "min" as const,
    label: "Low",
    tooltip: "Draw only the row with the lowest y",
  },
  {
    value: "max" as const,
    label: "High",
    tooltip: "Draw only the row with the highest y",
  },
];

const SHOWN = [
  { value: true, label: "Show", tooltip: "Draw it" },
  { value: false, label: "Hide", tooltip: "Leave it out of the graphic" },
] as const;

const SHAPES = [
  {
    value: "rect" as const,
    label: "Square",
    tooltip: "Draw a rectangle per bin",
  },
  {
    value: "circle" as const,
    label: "Circle",
    tooltip: "Draw a circle per bin",
  },
];

/** A mark type's name beside an icon of what it draws. */
function TypeLabel({ icon: Icon, text }: { icon: LucideIcon; text: string }) {
  return (
    <span className="inline-flex items-center gap-1">
      <Icon className="h-3.5 w-3.5" aria-hidden="true" />
      {text}
    </span>
  );
}

const MARK_TYPES = [
  {
    value: "strip" as const,
    label: <TypeLabel icon={LayoutGrid} text="Strip" />,
    tooltip:
      "One glyph per bin along a position scale, colored or sized by an aggregate",
  },
  {
    value: "point" as const,
    label: <TypeLabel icon={ScatterChart} text="Points" />,
    tooltip: "One circle per row at numeric x and y",
  },
  {
    value: "path" as const,
    label: <TypeLabel icon={Spline} text="Path" />,
    tooltip:
      "One line through the rows in the order of a field, such as year, at numeric x and y",
  },
  {
    value: "span" as const,
    label: <TypeLabel icon={GanttChart} text="Span" />,
    tooltip:
      "One bar per row from a start field to an end field along x, filling the frame's height: a timeline when the unit repeats as rows.",
  },
  {
    value: "band" as const,
    label: <TypeLabel icon={AreaChart} text="Band" />,
    tooltip:
      "A filled area between two fields along x, such as a forecast's 10th to 90th percentile. Layer several, widest first.",
  },
  {
    value: "stack" as const,
    label: <TypeLabel icon={Layers} text="Stack" />,
    tooltip:
      "One column per repeat, its categories stacked from the bottom as shares of the repeat's total. Filtering the rows recomputes the total.",
  },
  {
    value: "bar" as const,
    label: <TypeLabel icon={BarChartHorizontal} text="Bar" />,
    tooltip:
      "One bar per repeat, or per category, whose length is a count, sum, or average of the repeat's rows. One category can mirror leftward, as a population pyramid.",
  },
  {
    value: "waterfall" as const,
    label: <TypeLabel icon={ChartColumnStacked} text="Waterfall" />,
    tooltip:
      "A bridge from one total to another in each repeat, one signed step per category, or a running total over ordered steps. Values share one axis across repeats.",
  },
  {
    value: "donut" as const,
    label: <TypeLabel icon={DonutIcon} text="Donut" />,
    tooltip:
      "Each category's share of the repeat's rows as a ring, largest first, with the smaller categories pooled into Other. Colors match across repeats.",
  },
  {
    value: "waffle" as const,
    label: <TypeLabel icon={Grid3x3} text="Waffle" />,
    tooltip:
      "A grid of cells per repeat, one per row or per a set number of rows, grouped and colored by a category. Filtering the rows redraws the cells.",
  },
  {
    value: "horizon" as const,
    label: <TypeLabel icon={Waves} text="Horizon" />,
    tooltip:
      "A measure across x read from a baseline and cut into bands that stack over one another, so a short row holds a wide range; drops mirror upward in a second color.",
  },
  {
    value: "density" as const,
    label: <TypeLabel icon={Mountain} text="Density" />,
    tooltip:
      "The distribution of a numeric field in each repeat as a smoothed curve filled to the baseline. Overlap rows with a negative gap for a ridgeline.",
  },
  {
    value: "summary" as const,
    label: <TypeLabel icon={CandlestickChart} text="Summary" />,
    tooltip:
      "Splits each repeat's rows into groups, such as years, and computes a measure's quartiles in each. Draws the middle half as a band, the medians as dots, and a line joining them; each part can be turned off. A value scale can color the medians by their change from the first group to the last.",
  },
];

const ENCODINGS = [
  {
    value: "color" as const,
    label: "Color",
    tooltip: "Fill each glyph from the value scale's color ramp",
  },
  {
    value: "size" as const,
    label: "Size",
    tooltip: "Grow each glyph with its value; the largest fills its bin",
  },
  {
    value: "height" as const,
    label: "Height",
    tooltip:
      "Raise each glyph with its value, like a bar or dot plot inside the frame",
  },
];

export function UnitProperties({
  unit,
  definition,
  repeatCount,
  calculations,
  onChange,
  onChangeDefinition,
  onEditScale,
  revealedMark,
}: {
  unit: UnitElement;
  definition: CompositionDefinition;
  calculations: CompositionCalculation[];
  /** Repeats drawn now, so the template note can name them. */
  repeatCount: number;
  onChange: (patch: Partial<UnitElement>) => void;
  /** For edits that also add scales, such as changing a mark's type. */
  onChangeDefinition: (definition: CompositionDefinition) => void;
  onEditScale: (scaleId: string) => void;
  /** A mark a quick action asked to show; the token repeats a request. */
  revealedMark?: { id: string; token: number };
}) {
  const profiles = useDataLayer((state) => state.fieldProfiles);
  const repeatFields = profiles
    .filter(
      (profile) => profile.dataType !== "numeric" || profile.uniqueCount <= 60
    )
    .filter((profile) => profile.uniqueCount <= 200)
    .map((profile) => profile.name);
  const repeat = (patch: Partial<RepeatRule>) =>
    onChange({ repeat: { ...unit.repeat, ...patch } });
  const nameId = useId();

  return (
    <>
      <section
        className="eda-setting-section"
        aria-label={`${unit.name} repeat rule`}
      >
        <h5>{unit.name}</h5>
        <p className="eda-composition-scope" role="note">
          Template · edits apply to{" "}
          {repeatCount === 1 ? "the one unit" : `all ${repeatCount} repeats`}
        </p>
        <div className="eda-setting-grid">
          <Label htmlFor={nameId}>Layer name</Label>
          <Input
            id={nameId}
            value={unit.name}
            onChange={(event) => onChange({ name: event.target.value })}
          />
          <Label>Repeat by</Label>
          <FieldSelector
            label=""
            placeholder="One unit for all rows"
            value={unit.repeat.field ?? ""}
            allowClear
            fields={repeatFields}
            onChange={(field) => repeat({ field: field || undefined })}
          />
          {unit.repeat.field && (
            <>
              <span className="eda-setting-label">Arrange</span>
              <Segmented
                label="Repeat arrangement"
                value={unit.repeat.arrangement}
                options={ARRANGEMENTS}
                onChange={(arrangement) => repeat({ arrangement })}
              />
              {unit.repeat.arrangement === "grid" && (
                <NumberSetting
                  label="Columns"
                  min={1}
                  max={24}
                  value={unit.repeat.columns}
                  onChange={(columns) => repeat({ columns })}
                />
              )}
              {unit.repeat.arrangement === "tiles" && (
                <>
                  <Label>Cell field</Label>
                  <FieldSelector
                    label=""
                    placeholder="A row,column field"
                    value={unit.repeat.tileField ?? ""}
                    allowClear
                    onChange={(tileField) =>
                      repeat({ tileField: tileField || undefined })
                    }
                  />
                </>
              )}
              <span className="eda-setting-label">Order</span>
              <Segmented
                label="Repeat order"
                value={unit.repeat.order}
                options={ORDERS}
                onChange={(order) =>
                  repeat({
                    order,
                    orderCalcId:
                      order === "value"
                        ? (unit.repeat.orderCalcId ??
                          calculations.find(
                            (calc) => calc.population === "repeat"
                          )?.id)
                        : unit.repeat.orderCalcId,
                  })
                }
              />
              {unit.repeat.order === "value" && (
                <>
                  <Label htmlFor={`${nameId}-order-calc`}>Value</Label>
                  <select
                    id={`${nameId}-order-calc`}
                    className="eda-composition-select"
                    value={unit.repeat.orderCalcId ?? ""}
                    onChange={(event) =>
                      repeat({ orderCalcId: event.target.value || undefined })
                    }
                  >
                    {!calculations.length && (
                      <option value="">
                        Add a per-repeat calculation first
                      </option>
                    )}
                    {calculations.map((calc) => (
                      <option key={calc.id} value={calc.id}>
                        {calc.name}
                      </option>
                    ))}
                  </select>
                  <span className="eda-setting-label">Direction</span>
                  <Segmented
                    label="Repeat direction"
                    value={unit.repeat.direction ?? "asc"}
                    options={DIRECTIONS}
                    onChange={(direction) => repeat({ direction })}
                  />
                </>
              )}
              {(unit.repeat.arrangement === "rows" ||
                unit.repeat.arrangement === "columns") && (
                <>
                  <Label htmlFor={`${nameId}-weight-calc`}>Size by</Label>
                  <select
                    id={`${nameId}-weight-calc`}
                    className="eda-composition-select"
                    value={unit.repeat.weightCalcId ?? ""}
                    onChange={(event) =>
                      repeat({ weightCalcId: event.target.value || undefined })
                    }
                  >
                    <option value="">Same size</option>
                    {calculations.map((calc) => (
                      <option key={calc.id} value={calc.id}>
                        {unit.repeat.arrangement === "rows"
                          ? "Height"
                          : "Width"}{" "}
                        by {calc.name}
                      </option>
                    ))}
                  </select>
                </>
              )}
              <NumberSetting
                label="Most units"
                min={1}
                max={200}
                value={unit.repeat.limit}
                onChange={(limit) => repeat({ limit })}
              />
              <Label htmlFor={`${nameId}-skip`}>Leave out</Label>
              <Input
                id={`${nameId}-skip`}
                placeholder="Values not to repeat, comma-separated"
                value={unit.repeat.skip ?? ""}
                onChange={(event) =>
                  repeat({ skip: event.target.value || undefined })
                }
              />
              <NumberSetting
                label="Gap"
                min={-400}
                max={200}
                value={unit.repeat.gap}
                onChange={(gap) => repeat({ gap })}
              />
            </>
          )}
          <PairSetting
            label="Frame"
            names={["W", "H"]}
            min={4}
            values={[unit.frame.width, unit.frame.height]}
            onChange={([width, height]) =>
              onChange({ frame: { width, height } })
            }
          />
          <span className="eda-setting-label">Labels</span>
          <Segmented
            label="Repeat labels"
            value={unit.label.show}
            options={SHOWN}
            onChange={(show) => onChange({ label: { ...unit.label, show } })}
          />
          {unit.label.show && (
            <>
              <Label htmlFor={`${nameId}-label-value`}>Label value</Label>
              <select
                id={`${nameId}-label-value`}
                className="eda-composition-select"
                value={unit.label.valueCalcId ?? ""}
                onChange={(event) =>
                  onChange({
                    label: {
                      ...unit.label,
                      valueCalcId: event.target.value || undefined,
                    },
                  })
                }
              >
                <option value="">None</option>
                {calculations.map((calc) => (
                  <option key={calc.id} value={calc.id}>
                    {calc.name}
                  </option>
                ))}
              </select>
            </>
          )}
          {unit.label.show &&
            unit.label.valueCalcId &&
            unit.repeat.arrangement === "rows" && (
              <LabelValueFields
                unit={unit}
                onChange={(label) => onChange({ label })}
              />
            )}
          {unit.label.show && (
            <NumberSetting
              label="Name every"
              min={1}
              max={100}
              value={unit.label.every ?? 1}
              onChange={(every) =>
                onChange({
                  label: {
                    ...unit.label,
                    every: every > 1 ? every : undefined,
                  },
                })
              }
            />
          )}
          {unit.label.show && unit.repeat.arrangement === "rows" && (
            <NumberSetting
              label="Label width"
              min={0}
              max={600}
              value={unit.label.width}
              onChange={(width) =>
                onChange({ label: { ...unit.label, width } })
              }
            />
          )}
          <span className="eda-setting-label">Axis</span>
          <Segmented
            label="Position labels"
            value={unit.axis}
            options={SHOWN}
            onChange={(axis) => onChange({ axis })}
          />
          {unit.axis && (
            <>
              <Label htmlFor={`${nameId}-x-title`}>X title</Label>
              <Input
                id={`${nameId}-x-title`}
                placeholder="What x measures, such as Age"
                value={unit.axisTitles?.x ?? ""}
                onChange={(event) =>
                  onChange({
                    axisTitles: axisTitles(unit, { x: event.target.value }),
                  })
                }
              />
              <Label htmlFor={`${nameId}-y-title`}>Y title</Label>
              <Input
                id={`${nameId}-y-title`}
                placeholder="What y measures"
                value={unit.axisTitles?.y ?? ""}
                onChange={(event) =>
                  onChange({
                    axisTitles: axisTitles(unit, { y: event.target.value }),
                  })
                }
              />
            </>
          )}
          <PairSetting
            label="Position"
            names={["X", "Y"]}
            values={[unit.x, unit.y]}
            onChange={([x, y]) => onChange({ x, y })}
          />
        </div>
      </section>
      <FrameSection unit={unit} onChange={onChange} />
      <MarksSection
        unit={unit}
        definition={definition}
        fields={profiles}
        onChange={(marks) => onChange({ marks })}
        onChangeDefinition={onChangeDefinition}
        onEditScale={onEditScale}
        revealedMark={revealedMark}
      />
    </>
  );
}

const NO_SIGNS = {
  positive: { prefix: "+", suffix: "", color: "#1f2328" },
  negative: { prefix: "−", suffix: "", color: "#1f2328" },
};

/**
 * Where a row's calculated value shows and how its sign reads: beside the
 * name or in a tinted column after the frame, with each sign's own text
 * and color, such as +14R in red and +6D in blue.
 */
function LabelValueFields({
  unit,
  onChange,
}: {
  unit: UnitElement;
  onChange: (label: UnitElement["label"]) => void;
}) {
  const id = useId();
  const label = unit.label;
  const column = label.valueColumn;
  const signs = label.valueSigns;
  const setSign = (
    side: "positive" | "negative",
    patch: Partial<ValueSign>
  ) => {
    const current = signs ?? NO_SIGNS;
    onChange({
      ...label,
      valueSigns: { ...current, [side]: { ...current[side], ...patch } },
    });
  };
  return (
    <>
      <span className="eda-setting-label">Value at</span>
      <Segmented
        label="Label value place"
        value={column ? "column" : "name"}
        options={[
          {
            value: "name" as const,
            label: "Name",
            tooltip: "Right-aligned in the label column, beside each name",
          },
          {
            value: "column" as const,
            label: "Column",
            tooltip: "In its own tinted column after the frame, under a header",
          },
        ]}
        onChange={(place) =>
          onChange({
            ...label,
            valueColumn:
              place === "column"
                ? { width: 64, header: "", fill: "#f1efe9" }
                : undefined,
          })
        }
      />
      {column && (
        <>
          <Label htmlFor={`${id}-header`}>Header</Label>
          <Input
            id={`${id}-header`}
            placeholder="Such as Diff"
            value={column.header ?? ""}
            onChange={(event) =>
              onChange({
                ...label,
                valueColumn: {
                  ...column,
                  header: event.target.value || undefined,
                },
              })
            }
          />
          <ColorSetting
            label="Tint"
            value={column.fill ?? "#ffffff"}
            onChange={(fill) =>
              onChange({ ...label, valueColumn: { ...column, fill } })
            }
          />
        </>
      )}
      <span className="eda-setting-label">Signs</span>
      <Segmented
        label="Signed value text"
        value={Boolean(signs)}
        options={[
          {
            value: false as const,
            label: "Plain",
            tooltip: "Show the value as calculated",
          },
          {
            value: true as const,
            label: "By sign",
            tooltip:
              "Write the size of the value with each sign's own text and color, such as +14R and +6D",
          },
        ]}
        onChange={(bySign) =>
          onChange({ ...label, valueSigns: bySign ? NO_SIGNS : undefined })
        }
      />
      {signs &&
        (["positive", "negative"] as const).map((side) => (
          <Fragment key={side}>
            <Label htmlFor={`${id}-${side}`}>
              {side === "positive" ? "Above zero" : "Below zero"}
            </Label>
            <div className="eda-composition-sign">
              <Input
                id={`${id}-${side}`}
                aria-label={`${side === "positive" ? "Above zero" : "Below zero"} prefix`}
                className="w-12"
                value={signs[side].prefix}
                onChange={(event) =>
                  setSign(side, { prefix: event.target.value })
                }
              />
              <span className="text-muted-foreground">14</span>
              <Input
                aria-label={`${side === "positive" ? "Above zero" : "Below zero"} suffix`}
                className="w-12"
                value={signs[side].suffix}
                onChange={(event) =>
                  setSign(side, { suffix: event.target.value })
                }
              />
              <input
                type="color"
                aria-label={`${side === "positive" ? "Above zero" : "Below zero"} color`}
                value={signs[side].color}
                onChange={(event) =>
                  setSign(side, { color: event.target.value })
                }
              />
            </div>
          </Fragment>
        ))}
    </>
  );
}

/** Axis titles with one side changed; an empty set clears the setting. */
function axisTitles(
  unit: UnitElement,
  patch: { x?: string; y?: string }
): UnitElement["axisTitles"] {
  const next = { ...unit.axisTitles, ...patch };
  const x = next.x || undefined;
  const y = next.y || undefined;
  return x || y ? { x, y } : undefined;
}

function WindowFields({
  label,
  window,
  onChange,
}: {
  label: string;
  window: FrameWindow | undefined;
  onChange: (window: FrameWindow | undefined) => void;
}) {
  const id = useId();
  return (
    <>
      <Label>{label}</Label>
      <FieldSelector
        label=""
        placeholder="Every row"
        value={window?.field ?? ""}
        allowClear
        onChange={(field) => onChange(field ? { ...window, field } : undefined)}
      />
      {window && (
        <>
          <Label htmlFor={`${id}-min`}>From</Label>
          <Input
            id={`${id}-min`}
            placeholder="Open"
            value={window.min ?? ""}
            onChange={(event) =>
              onChange({ ...window, min: event.target.value || undefined })
            }
          />
          <Label htmlFor={`${id}-max`}>To</Label>
          <Input
            id={`${id}-max`}
            placeholder="Open"
            value={window.max ?? ""}
            onChange={(event) =>
              onChange({ ...window, max: event.target.value || undefined })
            }
          />
        </>
      )}
    </>
  );
}

/** The main frame's window and the insets drawn inside each repeat. */
function FrameSection({
  unit,
  onChange,
}: {
  unit: UnitElement;
  onChange: (patch: Partial<UnitElement>) => void;
}) {
  const insets = unit.insets ?? [];
  const update = (id: string, patch: Partial<InsetFrame>) =>
    onChange({
      insets: insets.map((inset) =>
        inset.id === id ? { ...inset, ...patch } : inset
      ),
    });
  return (
    <section className="eda-setting-section" aria-label="Frames">
      <div className="eda-composition-section-head">
        <h5>Frames</h5>
        <Button
          variant="ghost"
          size="sm"
          className="h-6 px-2"
          tooltip="Add a smaller frame inside each repeat, such as a full-history overview beside a recent-window detail. Assign marks to it below."
          onClick={() => onChange({ insets: [...insets, createInset(unit)] })}
        >
          <Plus className="h-3.5 w-3.5" aria-hidden="true" />
          Inset
        </Button>
      </div>
      <div className="eda-setting-grid">
        <WindowFields
          label="Window"
          window={unit.window}
          onChange={(window) => onChange({ window })}
        />
      </div>
      {insets.map((inset) => (
        <div key={inset.id} className="eda-composition-mark">
          <div className="eda-composition-section-head">
            <span className="eda-composition-mark-name">{inset.name}</span>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              aria-label={`Remove ${inset.name}`}
              tooltip="Remove this inset; its marks move back to the main frame"
              onClick={() =>
                onChange({
                  insets: insets.filter((item) => item.id !== inset.id),
                  marks: unit.marks.map((mark) =>
                    isXyMark(mark) && mark.frameId === inset.id
                      ? { ...mark, frameId: undefined }
                      : mark
                  ),
                })
              }
            >
              <Trash2 className="h-3.5 w-3.5" />
            </Button>
          </div>
          <div className="eda-setting-grid">
            <Label htmlFor={`${inset.id}-name`}>Name</Label>
            <Input
              id={`${inset.id}-name`}
              value={inset.name}
              onChange={(event) =>
                update(inset.id, { name: event.target.value })
              }
            />
            <PairSetting
              label="Offset"
              names={["X", "Y"]}
              values={[inset.x, inset.y]}
              onChange={([x, y]) => update(inset.id, { x, y })}
            />
            <PairSetting
              label="Size"
              names={["W", "H"]}
              min={8}
              values={[inset.width, inset.height]}
              onChange={([width, height]) =>
                update(inset.id, { width, height })
              }
            />
            <WindowFields
              label="Window"
              window={inset.window}
              onChange={(window) => update(inset.id, { window })}
            />
            <span className="eda-setting-label">Ticks</span>
            <Segmented
              label={`${inset.name} ticks`}
              value={inset.axis}
              options={SHOWN}
              onChange={(axis) => update(inset.id, { axis })}
            />
          </div>
        </div>
      ))}
    </section>
  );
}

function MarksSection({
  unit,
  definition,
  fields,
  onChange,
  onChangeDefinition,
  onEditScale,
  revealedMark,
}: {
  unit: UnitElement;
  definition: CompositionDefinition;
  fields: FieldChoice[];
  onChange: (marks: MarkDefinition[]) => void;
  onChangeDefinition: (definition: CompositionDefinition) => void;
  revealedMark?: { id: string; token: number };
  onEditScale: (scaleId: string) => void;
}) {
  const update = (id: string, patch: Partial<MarkDefinition>) =>
    onChange(
      unit.marks.map((mark) =>
        mark.id === id ? ({ ...mark, ...patch } as MarkDefinition) : mark
      )
    );
  // A new mark layers over the first one's frame and scales.
  const addMark = () => {
    const first = unit.marks[0];
    if (!first) return;
    const id = newMarkId(unit);
    const added: MarkDefinition =
      first.type === "strip"
        ? {
            ...first,
            id,
            name: "Dots",
            shape: "circle",
            encoding: "size",
            fill: "#1f2328",
          }
        : first.type === "summary"
          ? { ...first, id, name: "Summary 2" }
          : first.type === "stack"
            ? { ...first, id, name: "Stack 2" }
            : first.type === "waffle"
              ? { ...first, id, name: "Waffle 2" }
              : first.type === "bar"
                ? { ...first, id, name: "Bars 2" }
                : first.type === "waterfall"
                  ? { ...first, id, name: "Waterfall 2" }
                  : first.type === "donut"
                    ? { ...first, id, name: "Donut 2" }
                    : first.type === "horizon"
                      ? { ...first, id, name: "Horizon 2" }
                      : first.type === "density"
                        ? { ...first, id, name: "Density 2" }
                        : {
                            type: "point",
                            id,
                            name: "Points",
                            xScaleId: first.xScaleId,
                            yScaleId: first.yScaleId,
                            orderField:
                              "orderField" in first
                                ? first.orderField
                                : undefined,
                            radius: 3.5,
                            fill:
                              first.type === "path" ? first.stroke : first.fill,
                            labelEvery: 0,
                          };
    onChange([...unit.marks, added]);
  };
  return (
    <section className="eda-setting-section" aria-label="Marks">
      <div className="eda-composition-section-head">
        <h5>Marks</h5>
        <Button
          variant="ghost"
          size="sm"
          className="h-6 px-2"
          tooltip="Layer another mark over this unit's frame, drawn from the same rows. Change its type below."
          onClick={addMark}
        >
          <Plus className="h-3.5 w-3.5" aria-hidden="true" />
          Mark
        </Button>
      </div>
      {unit.marks.map((mark) => (
        <MarkProperties
          key={mark.id}
          mark={mark}
          summary={describeMark(mark, definition)}
          revealToken={
            revealedMark?.id === mark.id ? revealedMark.token : undefined
          }
          scales={definition.scales}
          insets={unit.insets ?? []}
          canRemove={unit.marks.length > 1}
          onChange={(patch) => update(mark.id, patch)}
          onChangeType={(type) =>
            onChangeDefinition(
              convertMark(definition, unit, mark.id, type, fields)
            )
          }
          onRemove={() =>
            onChangeDefinition(
              updateElement<UnitElement>(definition, unit.id, {
                marks: unit.marks.filter((item) => item.id !== mark.id),
              })
            )
          }
          onEditScale={onEditScale}
        />
      ))}
    </section>
  );
}

function MarkProperties({
  mark,
  summary,
  revealToken,
  scales,
  insets,
  canRemove,
  onChange,
  onChangeType,
  onRemove,
  onEditScale,
}: {
  mark: MarkDefinition;
  /** One line on what the mark draws, for scanning the list. */
  summary: string;
  /** Set when a quick action asked for this mark; scrolls to it and flashes. */
  revealToken?: number;
  scales: CompositionScale[];
  insets: InsetFrame[];
  canRemove: boolean;
  onChange: (patch: Partial<MarkDefinition>) => void;
  onChangeType: (type: MarkType) => void;
  onRemove: () => void;
  onEditScale: (scaleId: string) => void;
}) {
  const profiles = useDataLayer((state) => state.fieldProfiles);
  const numericFields = profiles
    .filter((profile) => profile.dataType === "numeric")
    .map((profile) => profile.name);
  const hasNumeric = numericFields.length >= 1;
  const cardRef = useRef<HTMLDivElement>(null);
  const [flash, setFlash] = useState(false);
  useEffect(() => {
    if (revealToken === undefined) return;
    cardRef.current?.scrollIntoView({ block: "start", behavior: "smooth" });
    setFlash(true);
    const timer = window.setTimeout(() => setFlash(false), 1600);
    return () => window.clearTimeout(timer);
  }, [revealToken]);
  return (
    <div
      ref={cardRef}
      className="eda-composition-mark"
      data-mark-id={mark.id}
      data-mark-type={mark.type}
      data-revealed={flash || undefined}
    >
      <div className="eda-composition-section-head">
        <span className="eda-composition-mark-name">{mark.name}</span>
        {canRemove && (
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6"
            aria-label={`Remove ${mark.name}`}
            tooltip="Remove this mark from every repeat"
            onClick={onRemove}
          >
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        )}
      </div>
      <p className="eda-composition-mark-summary">{summary}</p>
      <div className="eda-setting-grid">
        <span className="eda-setting-label">Type</span>
        <Segmented
          label={`${mark.name} type`}
          value={mark.type}
          options={
            hasNumeric
              ? MARK_TYPES
              : MARK_TYPES.map((option) =>
                  option.value === "strip"
                    ? option
                    : {
                        ...option,
                        tooltip: `${option.tooltip}. Needs a numeric field.`,
                      }
                )
          }
          onChange={(type) => {
            if (type === "strip" || hasNumeric) onChangeType(type);
          }}
        />
        {mark.type === "strip" ? (
          <StripFields
            mark={mark}
            scales={scales}
            numericFields={numericFields}
            onChange={onChange}
            onEditScale={onEditScale}
          />
        ) : mark.type === "horizon" ? (
          <HorizonFields
            mark={mark}
            scales={scales}
            numericFields={numericFields}
            onChange={onChange}
            onEditScale={onEditScale}
          />
        ) : mark.type === "density" ? (
          <DensityFields
            mark={mark}
            scales={scales}
            onChange={onChange}
            onEditScale={onEditScale}
          />
        ) : mark.type === "waffle" ? (
          <WaffleFields
            mark={mark}
            scales={scales}
            onChange={onChange}
            onEditScale={onEditScale}
          />
        ) : mark.type === "bar" ? (
          <BarFields
            mark={mark}
            numericFields={numericFields}
            onChange={onChange}
          />
        ) : mark.type === "waterfall" ? (
          <WaterfallFields
            mark={mark}
            numericFields={numericFields}
            onChange={onChange}
          />
        ) : mark.type === "donut" ? (
          <DonutFields
            mark={mark}
            numericFields={numericFields}
            onChange={onChange}
          />
        ) : mark.type === "stack" ? (
          <StackFields
            mark={mark}
            scales={scales}
            numericFields={numericFields}
            onChange={onChange}
            onEditScale={onEditScale}
          />
        ) : mark.type === "summary" ? (
          <SummaryFields
            mark={mark}
            scales={scales}
            numericFields={numericFields}
            onChange={onChange}
            onEditScale={onEditScale}
          />
        ) : (
          <XyFields
            mark={mark}
            scales={scales}
            insets={insets}
            onChange={onChange}
            onEditScale={onEditScale}
          />
        )}
      </div>
    </div>
  );
}

function StripFields({
  mark,
  scales,
  numericFields,
  onChange,
  onEditScale,
}: {
  mark: StripMark;
  scales: CompositionScale[];
  numericFields: string[];
  onChange: (patch: Partial<StripMark>) => void;
  onEditScale: (scaleId: string) => void;
}) {
  const id = useId();
  const positions = scales.filter((scale) => scale.kind === "position");
  const values = scales.filter((scale) => scale.kind === "value");
  return (
    <>
      <span className="eda-setting-label">Shape</span>
      <Segmented
        label={`${mark.name} shape`}
        value={mark.shape}
        options={SHAPES}
        onChange={(shape) => onChange({ shape })}
      />
      <Label htmlFor={`${id}-position`}>Position</Label>
      <ScaleSelect
        id={`${id}-position`}
        value={mark.positionScaleId}
        scales={positions}
        onChange={(positionScaleId) => onChange({ positionScaleId })}
        onEdit={onEditScale}
      />
      <Label htmlFor={`${id}-aggregation`}>Value</Label>
      <select
        id={`${id}-aggregation`}
        className="eda-composition-select"
        value={mark.aggregation}
        onChange={(event) => {
          const aggregation = event.target.value as StripMark["aggregation"];
          onChange({
            aggregation,
            measureField:
              aggregation === "count"
                ? undefined
                : (mark.measureField ?? numericFields[0]),
          });
        }}
      >
        <option value="count">Count rows</option>
        <option value="sum" disabled={!numericFields.length}>
          Sum
        </option>
        <option value="average" disabled={!numericFields.length}>
          Average
        </option>
      </select>
      {mark.aggregation !== "count" && (
        <>
          <Label>Of</Label>
          <FieldSelector
            label=""
            placeholder="Measure"
            value={mark.measureField ?? ""}
            fields={numericFields}
            onChange={(measureField) => onChange({ measureField })}
          />
        </>
      )}
      <span className="eda-setting-label">Encode as</span>
      <Segmented
        label={`${mark.name} encoding`}
        value={mark.encoding}
        options={ENCODINGS}
        onChange={(encoding) => onChange({ encoding })}
      />
      <Label htmlFor={`${id}-value`}>Value scale</Label>
      <ScaleSelect
        id={`${id}-value`}
        value={mark.valueScaleId}
        scales={values}
        onChange={(valueScaleId) => onChange({ valueScaleId })}
        onEdit={onEditScale}
      />
      {mark.encoding !== "color" && (
        <ColorSetting
          label="Fill"
          value={mark.fill}
          onChange={(fill) => onChange({ fill })}
        />
      )}
      <NumberSetting
        label="Spacing"
        min={0}
        max={20}
        value={mark.inset}
        onChange={(inset) => onChange({ inset })}
      />
      <span className="eda-setting-label">No value</span>
      <div className="eda-composition-color">
        <input
          type="color"
          aria-label={`${mark.name} missing cell color`}
          value={mark.missing ?? "#e6e8eb"}
          onChange={(event) => onChange({ missing: event.target.value })}
        />
        {mark.missing ? (
          <Button
            variant="ghost"
            size="sm"
            className="h-6 px-2"
            tooltip="Leave bins whose rows have no value blank again"
            onClick={() => onChange({ missing: undefined })}
          >
            Blank
          </Button>
        ) : (
          <span className="text-muted-foreground">Blank</span>
        )}
      </div>
    </>
  );
}

const FOCUS_OPTIONS = [
  {
    value: "none" as const,
    label: "All",
    tooltip: "Every series draws in the mark's color",
  },
  {
    value: "repeat" as const,
    label: "This repeat",
    tooltip:
      "The series that matches the repeat's own value draws in color; the others fade behind it, so every panel shows the field for comparison",
  },
  {
    value: "values" as const,
    label: "Listed",
    tooltip: "Only the series you list draw in color; the rest fade",
  },
];

function HorizonFields({
  mark,
  scales,
  numericFields,
  onChange,
  onEditScale,
}: {
  mark: HorizonMark;
  scales: CompositionScale[];
  numericFields: string[];
  onChange: (patch: Partial<HorizonMark>) => void;
  onEditScale: (scaleId: string) => void;
}) {
  const id = useId();
  const profiles = useDataLayer((state) => state.fieldProfiles);
  const orderFields = profiles
    .filter(
      (profile) =>
        profile.dataType === "numeric" || profile.dataType === "datetime"
    )
    .map((profile) => profile.name);
  const numeric = scales.filter((scale) => scale.kind === "numeric");
  return (
    <>
      <Label htmlFor={`${id}-x`}>X scale</Label>
      <ScaleSelect
        id={`${id}-x`}
        value={mark.xScaleId}
        scales={numeric}
        onChange={(xScaleId) => onChange({ xScaleId })}
        onEdit={onEditScale}
      />
      <Label>Measure</Label>
      <FieldSelector
        label=""
        placeholder="Numeric field"
        value={mark.field}
        fields={numericFields}
        onChange={(field) => onChange({ field })}
      />
      <Label>Order by</Label>
      <FieldSelector
        label=""
        placeholder="Order field"
        value={mark.orderField}
        fields={orderFields}
        onChange={(orderField) => onChange({ orderField })}
      />
      <span className="eda-setting-label">Read from</span>
      <Segmented
        label={`${mark.name} baseline`}
        value={mark.baseline}
        options={[
          {
            value: "zero" as const,
            label: "Zero",
            tooltip: "The measure as it is",
          },
          {
            value: "first" as const,
            label: "First value",
            tooltip:
              "The change from each repeat's first value in order, such as growth since the start",
          },
          {
            value: "mean" as const,
            label: "Mean",
            tooltip: "The difference from each repeat's mean",
          },
        ]}
        onChange={(baseline) => onChange({ baseline })}
      />
      <span className="eda-setting-label">As</span>
      <Segmented
        label={`${mark.name} units`}
        value={mark.relative}
        options={[
          {
            value: false,
            label: "Difference",
            tooltip: "In the measure's own units",
          },
          {
            value: true,
            label: "Share",
            tooltip:
              "As a share of the baseline, so repeats of different size compare; needs a nonzero baseline",
          },
        ]}
        onChange={(relative) => onChange({ relative })}
      />
      <NumberSetting
        label="Bands"
        min={1}
        max={10}
        value={mark.bands}
        onChange={(bands) => onChange({ bands })}
      />
      <span className="eda-setting-label">Range</span>
      <Segmented
        label={`${mark.name} range`}
        value={mark.domain}
        options={[
          {
            value: "shared" as const,
            label: "Shared",
            tooltip:
              "Every repeat's bands span the same amount, the largest swing in the graphic, so tints compare",
          },
          {
            value: "instance" as const,
            label: "Per unit",
            tooltip:
              "Each repeat's bands span its own largest swing, so every row uses its full height",
          },
        ]}
        onChange={(domain) => onChange({ domain })}
      />
      <ColorSetting
        label="Above"
        value={mark.positive}
        onChange={(positive) => onChange({ positive })}
      />
      <ColorSetting
        label="Below"
        value={mark.negative}
        onChange={(negative) => onChange({ negative })}
      />
    </>
  );
}

function DensityFields({
  mark,
  scales,
  onChange,
  onEditScale,
}: {
  mark: DensityMark;
  scales: CompositionScale[];
  onChange: (patch: Partial<DensityMark>) => void;
  onEditScale: (scaleId: string) => void;
}) {
  const id = useId();
  const numeric = scales.filter((scale) => scale.kind === "numeric");
  return (
    <>
      <Label htmlFor={`${id}-x`}>Field scale</Label>
      <ScaleSelect
        id={`${id}-x`}
        value={mark.xScaleId}
        scales={numeric}
        onChange={(xScaleId) => onChange({ xScaleId })}
        onEdit={onEditScale}
      />
      <span className="eda-setting-label">Height</span>
      <Segmented
        label={`${mark.name} height`}
        value={mark.height}
        options={[
          {
            value: "shared" as const,
            label: "Shared",
            tooltip:
              "The tallest density across the repeats fills the frame, so heights compare",
          },
          {
            value: "instance" as const,
            label: "Per unit",
            tooltip: "Each repeat's own peak fills its frame",
          },
        ]}
        onChange={(height) => onChange({ height })}
      />
      <span className="eda-setting-label">Smoothing</span>
      <div className="eda-composition-color">
        <NumericInputEnter
          aria-label={`${mark.name} bandwidth`}
          value={mark.bandwidth ?? 0}
          min={0}
          onChange={(bandwidth) =>
            Number.isFinite(bandwidth) &&
            onChange({ bandwidth: bandwidth > 0 ? bandwidth : undefined })
          }
        />
        <span className="text-muted-foreground">
          {mark.bandwidth ? "in field units" : "0 = span over 12"}
        </span>
      </div>
      <Label htmlFor={`${id}-shade`}>Shade by</Label>
      <div className="eda-composition-scale-select">
        <select
          id={`${id}-shade`}
          className="eda-composition-select"
          value={mark.colorScaleId ?? ""}
          onChange={(event) =>
            onChange({ colorScaleId: event.target.value || undefined })
          }
        >
          <option value="">One fill</option>
          {scales
            .filter((scale) => scale.kind === "value")
            .map((scale) => (
              <option key={scale.id} value={scale.id}>
                {scale.name} along x
              </option>
            ))}
        </select>
        {mark.colorScaleId && (
          <Button
            variant="ghost"
            size="sm"
            className="h-7 px-2"
            tooltip="Open this scale's settings below. Its colors run low to high across the x axis, or around zero when it has a middle color."
            onClick={() => onEditScale(mark.colorScaleId!)}
          >
            Edit
          </Button>
        )}
      </div>
      <ColorSetting
        label="Fill"
        value={mark.fill}
        onChange={(fill) => onChange({ fill })}
      />
      <NumberSetting
        label="Opacity %"
        min={5}
        max={100}
        value={Math.round(mark.opacity * 100)}
        onChange={(value) => onChange({ opacity: value / 100 })}
      />
      <span className="eda-setting-label">Outline</span>
      <div className="eda-composition-color">
        <input
          type="color"
          aria-label={`${mark.name} outline color`}
          value={mark.stroke ?? "#1f2328"}
          onChange={(event) => onChange({ stroke: event.target.value })}
        />
        {mark.stroke ? (
          <Button
            variant="ghost"
            size="sm"
            className="h-6 px-2"
            tooltip="Draw the curve without an outline"
            onClick={() => onChange({ stroke: undefined })}
          >
            None
          </Button>
        ) : (
          <span className="text-muted-foreground">None</span>
        )}
      </div>
    </>
  );
}

const BASELINE_OPTIONS = [
  {
    value: "zero" as const,
    label: "Zero",
    tooltip:
      "Layers stack up from the frame's bottom, so the top edge is the total",
  },
  {
    value: "center" as const,
    label: "Center",
    tooltip:
      "Each column centers on the frame's middle, so the stream's thickness is the total",
  },
  {
    value: "wiggle" as const,
    label: "Wiggle",
    tooltip:
      "The baseline moves so the layers' slopes stay smallest, as a streamgraph; the thickness is still the total",
  },
];
const CURVE_OPTIONS = [
  {
    value: "linear" as const,
    label: "Straight",
    tooltip: "Straight runs between the values",
  },
  {
    value: "smooth" as const,
    label: "Smooth",
    tooltip: "Smooth curves through the values that never overshoot them",
  },
];
const STACK_ORDERS = [
  {
    value: "total" as const,
    label: "Largest first",
    tooltip:
      "The category with the largest total across the whole graphic sits at the bottom. Reads every row, so filters never reorder or recolor.",
  },
  {
    value: "label" as const,
    label: "A–Z",
    tooltip: "Categories stack in name order from the bottom",
  },
];

function StackFields({
  mark,
  scales,
  numericFields,
  onChange,
  onEditScale,
}: {
  mark: StackMark;
  scales: CompositionScale[];
  numericFields: string[];
  onChange: (patch: Partial<StackMark>) => void;
  onEditScale: (scaleId: string) => void;
}) {
  const id = useId();
  const profiles = useDataLayer((state) => state.fieldProfiles);
  const categoryFields = profiles
    .filter((profile) => profile.uniqueCount <= 60)
    .map((profile) => profile.name);
  const numeric = scales.filter((scale) => scale.kind === "numeric");
  return (
    <>
      <span className="eda-setting-label">Layout</span>
      <Segmented
        label={`${mark.name} layout`}
        value={Boolean(mark.xScaleId)}
        options={[
          {
            value: false,
            label: "Column",
            tooltip: "One stacked column per repeat",
          },
          {
            value: true,
            label: "Across x",
            tooltip:
              "Spread the stack along a numeric x scale: categories stack at each x value and draw as areas, such as shares by age. Needs a numeric scale.",
          },
        ]}
        onChange={(across) =>
          onChange({ xScaleId: across ? numeric[0]?.id : undefined })
        }
      />
      {mark.xScaleId && (
        <>
          <Label htmlFor={`${id}-x`}>X scale</Label>
          <ScaleSelect
            id={`${id}-x`}
            value={mark.xScaleId}
            scales={numeric}
            onChange={(xScaleId) => onChange({ xScaleId })}
            onEdit={onEditScale}
          />
          {!mark.normalize && (
            <>
              <span className="eda-setting-label">Rests on</span>
              <Segmented
                label={`${mark.name} baseline`}
                value={mark.baseline ?? "zero"}
                options={BASELINE_OPTIONS}
                onChange={(baseline) =>
                  onChange({
                    baseline: baseline === "zero" ? undefined : baseline,
                  })
                }
              />
            </>
          )}
          <span className="eda-setting-label">Edges</span>
          <Segmented
            label={`${mark.name} curve`}
            value={mark.curve ?? "linear"}
            options={CURVE_OPTIONS}
            onChange={(curve) =>
              onChange({ curve: curve === "linear" ? undefined : curve })
            }
          />
        </>
      )}
      <Label>Categories</Label>
      <FieldSelector
        label=""
        placeholder="Category field"
        value={mark.categoryField}
        fields={categoryFields}
        onChange={(categoryField) => onChange({ categoryField })}
      />
      <Label htmlFor={`${id}-aggregation`}>Value</Label>
      <select
        id={`${id}-aggregation`}
        className="eda-composition-select"
        value={mark.aggregation}
        onChange={(event) => {
          const aggregation = event.target.value as StackMark["aggregation"];
          onChange({
            aggregation,
            measureField:
              aggregation === "count"
                ? undefined
                : (mark.measureField ?? numericFields[0]),
          });
        }}
      >
        <option value="count">Count rows</option>
        <option value="sum" disabled={!numericFields.length}>
          Sum
        </option>
      </select>
      {mark.aggregation === "sum" && (
        <>
          <Label>Of</Label>
          <FieldSelector
            label=""
            placeholder="Measure"
            value={mark.measureField ?? ""}
            fields={numericFields}
            onChange={(measureField) => onChange({ measureField })}
          />
        </>
      )}
      <span className="eda-setting-label">Height</span>
      <Segmented
        label={`${mark.name} height`}
        value={mark.normalize}
        options={[
          {
            value: true,
            label: "100%",
            tooltip:
              "Every column fills the frame; segments show shares of each repeat's total",
          },
          {
            value: false,
            label: "Totals",
            tooltip:
              "Column height follows each repeat's total against the largest repeat; segments still show shares",
          },
        ]}
        onChange={(normalize) => onChange({ normalize })}
      />
      <span className="eda-setting-label">Order</span>
      <Segmented
        label={`${mark.name} category order`}
        value={mark.order}
        options={[
          ...STACK_ORDERS,
          {
            value: "first" as const,
            label: "As listed",
            tooltip:
              "Categories stack in the order they first appear in the rows, such as rent, food, then clothes",
          },
        ]}
        onChange={(order) => onChange({ order })}
      />
      {!mark.xScaleId && (
        <>
          <span className="eda-setting-label">Direction</span>
          <Segmented
            label={`${mark.name} direction`}
            value={mark.direction ?? "up"}
            options={[
              {
                value: "up" as const,
                label: "Up",
                tooltip: "Stack from the bottom of a column",
              },
              {
                value: "across" as const,
                label: "Across",
                tooltip:
                  "Stack from left to right along a bar, such as one bar per income class",
              },
            ]}
            onChange={(direction) =>
              onChange({
                direction: direction === "up" ? undefined : direction,
              })
            }
          />
          <span className="eda-setting-label">Connect</span>
          <Segmented
            label={`${mark.name} connectors`}
            value={Boolean(mark.connect)}
            options={[
              {
                value: false,
                label: "Off",
                tooltip: "Draw each repeat's stack on its own",
              },
              {
                value: true,
                label: "Join edges",
                tooltip:
                  "Draw a thin line from each category's edge in one repeat to the same edge in the next, so shares can be followed",
              },
            ]}
            onChange={(connect) => onChange({ connect: connect || undefined })}
          />
          <span className="eda-setting-label">Texture</span>
          <Segmented
            label={`${mark.name} texture`}
            value={mark.texture ?? "flat"}
            options={[
              {
                value: "flat" as const,
                label: "Flat",
                tooltip: "Solid fills with clean edges",
              },
              {
                value: "hand" as const,
                label: "Hand-colored",
                tooltip: "Uneven edges and grain, like a chart colored by hand",
              },
            ]}
            onChange={(texture) =>
              onChange({ texture: texture === "hand" ? "hand" : undefined })
            }
          />
        </>
      )}
      <span className="eda-setting-label">Labels</span>
      <Segmented
        label={`${mark.name} label content`}
        value={mark.labelContent ?? "both"}
        options={[
          {
            value: "both" as const,
            label: "Name and share",
            tooltip: "Label a segment with its category and share",
          },
          {
            value: "share" as const,
            label: "Share",
            tooltip: "Label a segment with its share alone",
          },
        ]}
        onChange={(labelContent) =>
          onChange({
            labelContent: labelContent === "both" ? undefined : labelContent,
          })
        }
      />
      <NumberSetting
        label="Label from"
        min={0}
        max={200}
        value={mark.labelMinHeight}
        onChange={(labelMinHeight) => onChange({ labelMinHeight })}
      />
      <NumberSetting
        label="Spacing"
        min={0}
        max={20}
        value={mark.inset}
        onChange={(inset) => onChange({ inset })}
      />
    </>
  );
}

function BarFields({
  mark,
  numericFields,
  onChange,
}: {
  mark: BarMark;
  numericFields: string[];
  onChange: (patch: Partial<BarMark>) => void;
}) {
  const id = useId();
  const profiles = useDataLayer((state) => state.fieldProfiles);
  const categoryFields = profiles
    .filter((profile) => profile.uniqueCount <= 24)
    .map((profile) => profile.name);
  return (
    <>
      <Label htmlFor={`${id}-aggregation`}>Length</Label>
      <select
        id={`${id}-aggregation`}
        className="eda-composition-select"
        value={mark.aggregation}
        onChange={(event) => {
          const aggregation = event.target.value as BarMark["aggregation"];
          onChange({
            aggregation,
            measureField:
              aggregation === "count"
                ? undefined
                : (mark.measureField ?? numericFields[0]),
          });
        }}
      >
        <option value="count">Count rows</option>
        <option value="sum" disabled={!numericFields.length}>
          Sum
        </option>
        <option value="average" disabled={!numericFields.length}>
          Average
        </option>
      </select>
      {mark.aggregation !== "count" && (
        <>
          <Label>Of</Label>
          <FieldSelector
            label=""
            placeholder="Measure"
            value={mark.measureField ?? ""}
            fields={numericFields}
            onChange={(measureField) => onChange({ measureField })}
          />
        </>
      )}
      <Label>Split by</Label>
      <FieldSelector
        label=""
        placeholder="One bar per repeat"
        value={mark.categoryField ?? ""}
        allowClear
        fields={categoryFields}
        onChange={(categoryField) =>
          onChange({
            categoryField: categoryField || undefined,
            mirror: categoryField ? mark.mirror : undefined,
          })
        }
      />
      {mark.categoryField && (
        <>
          <Label htmlFor={`${id}-mirror`}>Leftward</Label>
          <Input
            id={`${id}-mirror`}
            placeholder="A category to mirror, or blank"
            value={mark.mirror ?? ""}
            onChange={(event) =>
              onChange({ mirror: event.target.value || undefined })
            }
          />
          <span className="eda-setting-label">Order</span>
          <Segmented
            label={`${mark.name} category order`}
            value={mark.order}
            options={STACK_ORDERS}
            onChange={(order) => onChange({ order })}
          />
        </>
      )}
      <NumberSetting
        label="Axis to"
        min={0}
        max={1e12}
        value={mark.max ?? 0}
        onChange={(max) => onChange({ max: max > 0 ? max : undefined })}
      />
      <NumberSetting
        label="Spacing"
        min={0}
        max={20}
        value={mark.inset}
        onChange={(inset) => onChange({ inset })}
      />
      <NumberSetting
        label="Label from"
        min={0}
        max={400}
        value={mark.labelMinWidth}
        onChange={(labelMinWidth) => onChange({ labelMinWidth })}
      />
    </>
  );
}

function WaffleFields({
  mark,
  scales,
  onChange,
  onEditScale,
}: {
  mark: WaffleMark;
  scales: CompositionScale[];
  onChange: (patch: Partial<WaffleMark>) => void;
  onEditScale: (scaleId: string) => void;
}) {
  const id = useId();
  const profiles = useDataLayer((state) => state.fieldProfiles);
  const categoryFields = profiles
    .filter((profile) => profile.uniqueCount <= 60)
    .map((profile) => profile.name);
  const numeric = scales.filter((scale) => scale.kind === "numeric");
  return (
    <>
      <Label>Categories</Label>
      <FieldSelector
        label=""
        placeholder="Category field"
        value={mark.categoryField}
        fields={categoryFields}
        onChange={(categoryField) => onChange({ categoryField })}
      />
      <Label htmlFor={`${id}-x`}>Bin along</Label>
      <div className="eda-composition-scale-select">
        <select
          id={`${id}-x`}
          className="eda-composition-select"
          value={mark.xScaleId ?? ""}
          onChange={(event) =>
            onChange({ xScaleId: event.target.value || undefined })
          }
        >
          <option value="">One waffle per repeat</option>
          {numeric.map((scale) => (
            <option key={scale.id} value={scale.id}>
              {scale.name}, by whole value
            </option>
          ))}
        </select>
        {mark.xScaleId && (
          <Button
            variant="ghost"
            size="sm"
            className="h-7 px-2"
            tooltip="Open this scale's settings below. Its limits set the first and last bin."
            onClick={() => onEditScale(mark.xScaleId!)}
          >
            Edit
          </Button>
        )}
      </div>
      <span className="eda-setting-label">Cells</span>
      <Segmented
        label={`${mark.name} cells`}
        value={mark.normalize}
        options={[
          {
            value: false,
            label: "Counted",
            tooltip:
              "One cell per row, or per the number of rows set below, so bigger repeats draw more cells",
          },
          {
            value: true,
            label: "100 shares",
            tooltip:
              "A hundred cells per repeat, each one percent of its rows, so repeats compare as shares",
          },
        ]}
        onChange={(normalize) => onChange({ normalize })}
      />
      {!mark.normalize && (
        <NumberSetting
          label="Rows per cell"
          min={1}
          max={100000}
          value={mark.each}
          onChange={(each) => onChange({ each })}
        />
      )}
      <NumberSetting
        label="Columns"
        min={1}
        max={200}
        value={mark.columns}
        onChange={(columns) => onChange({ columns })}
      />
      <NumberSetting
        label="Gap"
        min={0}
        max={20}
        value={mark.gap}
        onChange={(gap) => onChange({ gap })}
      />
      <span className="eda-setting-label">Fill from</span>
      <Segmented
        label={`${mark.name} fill direction`}
        value={mark.from}
        options={[
          {
            value: "top" as const,
            label: "Top",
            tooltip: "Cells run left to right from the top row down",
          },
          {
            value: "bottom" as const,
            label: "Bottom",
            tooltip:
              "Cells run left to right from the bottom row up, so the grid grows like a bar",
          },
        ]}
        onChange={(from) => onChange({ from })}
      />
      <span className="eda-setting-label">Order</span>
      <Segmented
        label={`${mark.name} category order`}
        value={mark.order}
        options={STACK_ORDERS}
        onChange={(order) => onChange({ order })}
      />
    </>
  );
}

const ALL_SUMMARY_PARTS: SummaryParts = {
  band: true,
  line: true,
  points: true,
};
const SUMMARY_PARTS = [
  {
    key: "band" as const,
    label: "Band",
    tooltip:
      "Fill between each group's 25th and 75th percentiles: the middle half of its rows",
  },
  {
    key: "line" as const,
    label: "Line",
    tooltip: "Join the groups' medians with a line",
  },
  {
    key: "points" as const,
    label: "Dots",
    tooltip: "Mark each group's median with a dot",
  },
];

function SummaryFields({
  mark,
  scales,
  numericFields,
  onChange,
  onEditScale,
}: {
  mark: SummaryMark;
  scales: CompositionScale[];
  numericFields: string[];
  onChange: (patch: Partial<SummaryMark>) => void;
  onEditScale: (scaleId: string) => void;
}) {
  const id = useId();
  const profiles = useDataLayer((state) => state.fieldProfiles);
  const groupFields = profiles
    .filter((profile) => profile.uniqueCount <= 24)
    .map((profile) => profile.name);
  const numeric = scales.filter((scale) => scale.kind === "numeric");
  const values = scales.filter((scale) => scale.kind === "value");
  return (
    <>
      <Label>Groups</Label>
      <FieldSelector
        label=""
        placeholder="Cohort field"
        value={mark.groupField}
        fields={groupFields}
        onChange={(groupField) => onChange({ groupField })}
      />
      <Label>Measure</Label>
      <FieldSelector
        label=""
        placeholder="Numeric field"
        value={mark.measureField}
        fields={numericFields}
        onChange={(measureField) => onChange({ measureField })}
      />
      <Label htmlFor={`${id}-y`}>Y scale</Label>
      <ScaleSelect
        id={`${id}-y`}
        value={mark.yScaleId}
        scales={numeric}
        onChange={(yScaleId) => onChange({ yScaleId })}
        onEdit={onEditScale}
      />
      <Label htmlFor={`${id}-value`}>Change color</Label>
      <div className="eda-composition-scale-select">
        <select
          id={`${id}-value`}
          className="eda-composition-select"
          value={mark.valueScaleId ?? ""}
          onChange={(event) =>
            onChange({ valueScaleId: event.target.value || undefined })
          }
        >
          <option value="">Band fill</option>
          {values.map((scale) => (
            <option key={scale.id} value={scale.id}>
              {scale.name}
            </option>
          ))}
        </select>
        {mark.valueScaleId && (
          <Button
            variant="ghost"
            size="sm"
            className="h-7 px-2"
            tooltip="Open this scale's settings below. A middle color makes it diverge around no change."
            onClick={() => onEditScale(mark.valueScaleId!)}
          >
            Edit
          </Button>
        )}
      </div>
      <span className="eda-setting-label">Draw</span>
      <div className="eda-segmented" role="group" aria-label="Summary parts">
        {SUMMARY_PARTS.map((part) => {
          const parts = mark.parts ?? ALL_SUMMARY_PARTS;
          return (
            <ActionTooltip key={part.key} content={part.tooltip}>
              <button
                type="button"
                aria-pressed={parts[part.key]}
                className="eda-segmented-item"
                onClick={() => {
                  const next = { ...parts, [part.key]: !parts[part.key] };
                  onChange({
                    parts:
                      next.band && next.line && next.points ? undefined : next,
                  });
                }}
              >
                {part.label}
              </button>
            </ActionTooltip>
          );
        })}
      </div>
      <ColorSetting
        label="Band fill"
        value={mark.fill}
        onChange={(fill) => onChange({ fill })}
      />
      <NumberSetting
        label="Opacity %"
        min={5}
        max={100}
        value={Math.round(mark.opacity * 100)}
        onChange={(value) => onChange({ opacity: value / 100 })}
      />
    </>
  );
}

/** Fields shared by point and path marks: the scales and the order. */
/** A numeric field and the value scale that colors a path or point by it. */
function ValueShadeSelect({
  id,
  field,
  scaleId,
  fields,
  scales,
  onChange,
  onEditScale,
}: {
  id: string;
  field?: string;
  scaleId?: string;
  fields: string[];
  scales: CompositionScale[];
  onChange: (patch: { valueField?: string; valueScaleId?: string }) => void;
  onEditScale: (scaleId: string) => void;
}) {
  const values = scales.filter((scale) => scale.kind === "value");
  return (
    <div className="flex min-w-0 flex-col gap-1">
      <FieldSelector
        label=""
        placeholder="No value shading"
        value={field ?? ""}
        allowClear
        fields={fields}
        onChange={(next) =>
          onChange({
            valueField: next || undefined,
            valueScaleId: next ? (scaleId ?? values[0]?.id) : undefined,
          })
        }
      />
      {field && (
        <div className="eda-composition-scale-select">
          <select
            id={id}
            aria-label="Shading scale"
            className="eda-composition-select"
            value={scaleId ?? ""}
            onChange={(event) =>
              onChange({ valueScaleId: event.target.value || undefined })
            }
          >
            {!values.length && (
              <option value="">Add a value scale first</option>
            )}
            {values.map((scale) => (
              <option key={scale.id} value={scale.id}>
                {scale.name}
              </option>
            ))}
          </select>
          {scaleId && (
            <Button
              variant="ghost"
              size="sm"
              className="h-7 px-2"
              tooltip="Open this scale's settings below. A middle color makes it diverge around zero."
              onClick={() => onEditScale(scaleId)}
            >
              Edit
            </Button>
          )}
        </div>
      )}
    </div>
  );
}

function XyFields({
  mark,
  scales,
  insets,
  onChange,
  onEditScale,
}: {
  mark: PointMark | PathMark | BandMark | SpanMark;
  scales: CompositionScale[];
  insets: InsetFrame[];
  onChange: (
    patch: Partial<PointMark> | Partial<PathMark> | Partial<BandMark>
  ) => void;
  onEditScale: (scaleId: string) => void;
}) {
  const id = useId();
  const profiles = useDataLayer((state) => state.fieldProfiles);
  const spanFields = profiles
    .filter(
      (profile) =>
        profile.dataType === "numeric" || profile.dataType === "datetime"
    )
    .map((profile) => profile.name);
  const orderFields = profiles
    .filter(
      (profile) =>
        profile.dataType === "numeric" || profile.dataType === "datetime"
    )
    .map((profile) => profile.name);
  const seriesFields = profiles
    .filter((profile) => profile.uniqueCount <= 200)
    .map((profile) => profile.name);
  const numeric = scales.filter((scale) => scale.kind === "numeric");
  const change = onChange as (
    patch: Partial<
      Omit<PointMark, "type"> &
        Omit<PathMark, "type"> &
        Omit<BandMark, "type"> &
        Omit<SpanMark, "type">
    >
  ) => void;
  const numericFields = profiles
    .filter((profile) => profile.dataType === "numeric")
    .map((profile) => profile.name);
  return (
    <>
      {insets.length > 0 && (
        <>
          <Label htmlFor={`${id}-frame`}>Frame</Label>
          <select
            id={`${id}-frame`}
            className="eda-composition-select"
            value={mark.frameId ?? ""}
            onChange={(event) =>
              change({ frameId: event.target.value || undefined })
            }
          >
            <option value="">Main frame</option>
            {insets.map((inset) => (
              <option key={inset.id} value={inset.id}>
                {inset.name}
              </option>
            ))}
          </select>
        </>
      )}
      <Label htmlFor={`${id}-x`}>X scale</Label>
      <ScaleSelect
        id={`${id}-x`}
        value={mark.xScaleId}
        scales={numeric}
        onChange={(xScaleId) => change({ xScaleId })}
        onEdit={onEditScale}
      />
      <Label htmlFor={`${id}-y`}>Y scale</Label>
      {mark.type === "band" ? (
        <ScaleSelect
          id={`${id}-y`}
          value={mark.yScaleId}
          scales={numeric}
          onChange={(yScaleId) => change({ yScaleId })}
          onEdit={onEditScale}
        />
      ) : (
        <div className="eda-composition-scale-select">
          <select
            id={`${id}-y`}
            className="eda-composition-select"
            value={mark.yScaleId ?? ""}
            onChange={(event) =>
              change({ yScaleId: event.target.value || undefined })
            }
          >
            <option value="">Middle line (dot row)</option>
            {numeric.map((scale) => (
              <option key={scale.id} value={scale.id}>
                {scale.name}
              </option>
            ))}
          </select>
          {mark.yScaleId && (
            <Button
              variant="ghost"
              size="sm"
              className="h-7 px-2"
              tooltip="Open this scale's settings below. Every mark that uses it changes."
              onClick={() => onEditScale(mark.yScaleId!)}
            >
              Edit
            </Button>
          )}
        </div>
      )}
      {mark.type !== "band" && mark.type !== "span" && mark.yScaleId && (
        <>
          <span className="eda-setting-label">Plot</span>
          <Segmented
            label={`${mark.name} y plots`}
            value={mark.rank ?? "value"}
            options={RANK_OPTIONS}
            onChange={(rank) =>
              change({ rank: rank === "value" ? undefined : rank })
            }
          />
        </>
      )}
      {mark.type !== "span" && (
        <>
          <Label>Order by</Label>
          <FieldSelector
            label=""
            placeholder={mark.type === "point" ? "Row order" : "Order field"}
            value={mark.orderField ?? ""}
            allowClear={mark.type === "point"}
            fields={orderFields}
            onChange={(orderField) =>
              change(
                mark.type === "point"
                  ? { orderField: orderField || undefined }
                  : { orderField }
              )
            }
          />
        </>
      )}
      {mark.type !== "band" && mark.type !== "span" && (
        <>
          <Label>Series</Label>
          <FieldSelector
            label=""
            placeholder={
              mark.type === "path"
                ? "One path per repeat"
                : "Pick across all rows"
            }
            value={mark.seriesField ?? ""}
            allowClear
            fields={seriesFields}
            onChange={(seriesField) =>
              change({ seriesField: seriesField || undefined })
            }
          />
          <span className="eda-setting-label">Rows</span>
          <Segmented
            label={`${mark.name} rows`}
            value={mark.population ?? "repeat"}
            options={[
              {
                value: "repeat" as const,
                label: "This repeat",
                tooltip: "Draw from the repeat's own rows",
              },
              {
                value: "composition" as const,
                label: "Whole graphic",
                tooltip:
                  "Draw from every row in the graphic in each repeat, such as every country's path behind a panel's own",
              },
            ]}
            onChange={(population) =>
              change({
                population: population === "repeat" ? undefined : population,
              })
            }
          />
          {mark.seriesField && (
            <>
              <span className="eda-setting-label">Focus</span>
              <Segmented
                label={`${mark.name} focus`}
                value={mark.focus?.kind ?? "none"}
                options={FOCUS_OPTIONS}
                onChange={(kind) =>
                  change({
                    focus:
                      kind === "none"
                        ? undefined
                        : kind === "repeat"
                          ? { kind: "repeat" }
                          : {
                              kind: "values",
                              values:
                                mark.focus?.kind === "values"
                                  ? mark.focus.values
                                  : "",
                            },
                  })
                }
              />
              {mark.focus?.kind === "values" && (
                <>
                  <Label htmlFor={`${id}-focus-values`}>Values</Label>
                  <Input
                    id={`${id}-focus-values`}
                    placeholder="Comma-separated series values"
                    value={mark.focus.values}
                    onChange={(event) =>
                      change({
                        focus: { kind: "values", values: event.target.value },
                      })
                    }
                  />
                </>
              )}
              {mark.focus && (
                <ColorSetting
                  label="Muted"
                  value={
                    (mark.type === "path"
                      ? mark.mutedStroke
                      : mark.mutedFill) ?? MUTED_MARK
                  }
                  onChange={(muted) =>
                    change(
                      mark.type === "path"
                        ? { mutedStroke: muted }
                        : { mutedFill: muted }
                    )
                  }
                />
              )}
            </>
          )}
        </>
      )}
      {mark.type === "span" ? (
        <>
          <Label>From</Label>
          <FieldSelector
            label=""
            placeholder="Start field"
            value={mark.startField}
            fields={spanFields}
            onChange={(startField) => change({ startField })}
          />
          <Label>To</Label>
          <FieldSelector
            label=""
            placeholder="End field"
            value={mark.endField}
            fields={spanFields}
            onChange={(endField) => change({ endField })}
          />
          <span className="eda-setting-label">No end</span>
          <Segmented
            label={`${mark.name} open ends`}
            value={mark.openEnd}
            options={[
              {
                value: true,
                label: "Runs on",
                tooltip:
                  "A row without an end draws to the frame's right edge, as an incumbent's term",
              },
              {
                value: false,
                label: "Left out",
                tooltip: "A row without an end draws nothing",
              },
            ]}
            onChange={(openEnd) => change({ openEnd })}
          />
          <ColorSetting
            label="Fill"
            value={mark.fill}
            onChange={(fill) => change({ fill })}
          />
          <Label>Color by</Label>
          <FieldSelector
            label=""
            placeholder="One fill"
            value={mark.colorField ?? ""}
            allowClear
            fields={seriesFields}
            onChange={(colorField) =>
              change({ colorField: colorField || undefined })
            }
          />
          <Label>Label with</Label>
          <FieldSelector
            label=""
            placeholder="No labels"
            value={mark.labelField ?? ""}
            allowClear
            onChange={(labelField) =>
              change({ labelField: labelField || undefined })
            }
          />
          {mark.labelField && (
            <NumberSetting
              label="Label from"
              min={0}
              max={400}
              value={mark.labelMinWidth}
              onChange={(labelMinWidth) => change({ labelMinWidth })}
            />
          )}
          <NumberSetting
            label="Spacing"
            min={0}
            max={40}
            value={mark.inset}
            onChange={(inset) => change({ inset })}
          />
        </>
      ) : mark.type === "band" ? (
        <>
          <Label>Lower</Label>
          <FieldSelector
            label=""
            placeholder="Lower bound"
            value={mark.lowerField}
            fields={numericFields}
            onChange={(lowerField) => change({ lowerField })}
          />
          <Label>Upper</Label>
          <FieldSelector
            label=""
            placeholder="Upper bound"
            value={mark.upperField}
            fields={numericFields}
            onChange={(upperField) => change({ upperField })}
          />
          <ColorSetting
            label="Fill"
            value={mark.fill}
            onChange={(fill) => change({ fill })}
          />
          <NumberSetting
            label="Opacity %"
            min={5}
            max={100}
            value={Math.round(mark.opacity * 100)}
            onChange={(value) => change({ opacity: value / 100 })}
          />
        </>
      ) : mark.type === "path" ? (
        <>
          <ColorSetting
            label="Stroke"
            value={mark.stroke}
            onChange={(stroke) => change({ stroke })}
          />
          <NumberSetting
            label="Width"
            min={0.25}
            max={20}
            value={mark.strokeWidth}
            onChange={(strokeWidth) => change({ strokeWidth })}
          />
          <Label>Color by</Label>
          <FieldSelector
            label=""
            placeholder="One stroke"
            value={mark.colorField ?? ""}
            allowClear
            fields={seriesFields}
            onChange={(colorField) =>
              change({ colorField: colorField || undefined })
            }
          />
          <Label htmlFor={`${id}-shade`}>Shade by value</Label>
          <ValueShadeSelect
            id={`${id}-shade`}
            field={mark.valueField}
            scaleId={mark.valueScaleId}
            fields={numericFields}
            scales={scales}
            onChange={(patch) => change(patch)}
            onEditScale={onEditScale}
          />
          <span className="eda-setting-label">Line</span>
          <Segmented
            label={`${mark.name} curve`}
            value={mark.curve ?? "linear"}
            options={CURVE_OPTIONS}
            onChange={(curve) =>
              change({ curve: curve === "linear" ? undefined : curve })
            }
          />
          <span className="eda-setting-label">Name at</span>
          <Segmented
            label={`${mark.name} end labels`}
            value={mark.labels ?? "none"}
            options={PATH_LABEL_OPTIONS}
            onChange={(labels) =>
              change({ labels: labels === "none" ? undefined : labels })
            }
          />
          {mark.labels && mark.labels !== "none" && (
            <>
              <span className="eda-setting-label">Label value</span>
              <Segmented
                label={`${mark.name} label value`}
                value={Boolean(mark.labelValue)}
                options={LABEL_VALUE_OPTIONS}
                onChange={(labelValue) =>
                  change({ labelValue: labelValue || undefined })
                }
              />
            </>
          )}
        </>
      ) : (
        <>
          <ColorSetting
            label="Fill"
            value={mark.fill}
            onChange={(fill) => change({ fill })}
          />
          <NumberSetting
            label="Radius"
            min={0.5}
            max={40}
            value={mark.radius}
            onChange={(radius) => change({ radius })}
          />
          <span className="eda-setting-label">Show</span>
          <Segmented
            label={`${mark.name} rows shown`}
            value={mark.show ?? "all"}
            options={SHOW_OPTIONS}
            onChange={(show) =>
              change({ show: show === "all" ? undefined : show })
            }
          />
          <Label>Color by</Label>
          <FieldSelector
            label=""
            placeholder="One fill"
            value={mark.colorField ?? ""}
            allowClear
            fields={seriesFields}
            onChange={(colorField) =>
              change({ colorField: colorField || undefined })
            }
          />
          <Label htmlFor={`${id}-shade`}>Shade by value</Label>
          <ValueShadeSelect
            id={`${id}-shade`}
            field={mark.valueField}
            scaleId={mark.valueScaleId}
            fields={numericFields}
            scales={scales}
            onChange={(patch) => change(patch)}
            onEditScale={onEditScale}
          />
          <Label>Label with</Label>
          <FieldSelector
            label=""
            placeholder="No labels"
            value={mark.labelField ?? ""}
            allowClear
            onChange={(labelField) =>
              change({
                labelField: labelField || undefined,
                labelEvery:
                  labelField && !mark.labelEvery ? 1 : mark.labelEvery,
              })
            }
          />
          {mark.labelField && (
            <>
              <NumberSetting
                label="Label every"
                min={0}
                max={200}
                value={mark.labelEvery}
                onChange={(labelEvery) => change({ labelEvery })}
              />
              <Label htmlFor={`${id}-label-values`}>Only</Label>
              <Input
                id={`${id}-label-values`}
                placeholder="Comma-separated labels, or blank for all"
                value={mark.labelValues ?? ""}
                onChange={(event) =>
                  change({ labelValues: event.target.value || undefined })
                }
              />
            </>
          )}
          {!mark.yScaleId && (
            <>
              <span className="eda-setting-label">Spread</span>
              <Segmented
                label={`${mark.name} spread`}
                value={mark.spread ?? "line"}
                options={SPREAD_OPTIONS}
                onChange={(spread) =>
                  change({ spread: spread === "line" ? undefined : spread })
                }
              />
            </>
          )}
          <Label>Size by</Label>
          <FieldSelector
            label=""
            placeholder="One radius"
            value={mark.sizeField ?? ""}
            allowClear
            fields={numericFields}
            onChange={(sizeField) =>
              change({ sizeField: sizeField || undefined })
            }
          />
          {mark.sizeField && (
            <NumberSetting
              label="Smallest"
              min={0.5}
              max={40}
              value={mark.minRadius ?? 1}
              onChange={(minRadius) => change({ minRadius })}
            />
          )}
        </>
      )}
    </>
  );
}

function ScaleSelect({
  id,
  value,
  scales,
  onChange,
  onEdit,
}: {
  id: string;
  value: string;
  scales: CompositionScale[];
  onChange: (id: string) => void;
  onEdit: (id: string) => void;
}) {
  return (
    <div className="eda-composition-scale-select">
      <select
        id={id}
        className="eda-composition-select"
        value={value}
        onChange={(event) => onChange(event.target.value)}
      >
        {scales.map((scale) => (
          <option key={scale.id} value={scale.id}>
            {scale.name}
          </option>
        ))}
      </select>
      <Button
        variant="ghost"
        size="sm"
        className="h-7 px-2"
        tooltip="Open this scale's settings below. Every mark that uses it changes."
        onClick={() => onEdit(value)}
      >
        Edit
      </Button>
    </div>
  );
}

/** Edits one repeat apart from its template: placement and look only. */
export function OverrideProperties({
  label,
  override,
  onChange,
  onReset,
  onEditTemplate,
}: {
  label: string;
  override?: InstanceOverride;
  onChange: (patch: Partial<InstanceOverride>) => void;
  onReset: () => void;
  onEditTemplate: () => void;
}) {
  return (
    <section
      className="eda-setting-section eda-composition-override"
      aria-label={`${label} override`}
    >
      <div className="eda-composition-section-head">
        <h5>Repeat: {label}</h5>
        <Button
          variant="ghost"
          size="sm"
          className="h-6 px-2"
          tooltip="Select the template again. Its edits apply to every repeat."
          onClick={onEditTemplate}
        >
          Edit template
        </Button>
      </div>
      <p className="eda-composition-scope" role="note">
        Override · changes only this repeat. Its rows, calculations, and scales
        still come from the template.
      </p>
      <div className="eda-setting-grid">
        <PairSetting
          label="Nudge"
          names={["X", "Y"]}
          values={[override?.dx ?? 0, override?.dy ?? 0]}
          onChange={([dx, dy]) => onChange({ dx, dy })}
        />
        <span className="eda-setting-label">Accent</span>
        <div className="eda-composition-color">
          <input
            type="color"
            aria-label={`${label} accent color`}
            value={override?.accent ?? "#1f4e8c"}
            onChange={(event) => onChange({ accent: event.target.value })}
          />
          {override?.accent ? (
            <Button
              variant="ghost"
              size="sm"
              className="h-6 px-2"
              tooltip="Use the template's colors for this repeat again"
              onClick={() => onChange({ accent: undefined })}
            >
              Clear
            </Button>
          ) : (
            <span className="text-muted-foreground">Template colors</span>
          )}
        </div>
        <NumberSetting
          label="Opacity %"
          min={10}
          max={100}
          value={Math.round((override?.opacity ?? 1) * 100)}
          onChange={(value) =>
            onChange({ opacity: value >= 100 ? undefined : value / 100 })
          }
        />
        <span className="eda-setting-label">Label</span>
        <Segmented
          label={`${label} label weight`}
          value={Boolean(override?.emphasize)}
          options={[
            {
              value: false,
              label: "Template",
              tooltip: "Use the template's label weight",
            },
            {
              value: true,
              label: "Bold",
              tooltip: "Make this repeat's label bold, to call it out",
            },
          ]}
          onChange={(emphasize) => onChange({ emphasize })}
        />
      </div>
      <Button
        variant="outline"
        size="sm"
        className="mt-2 h-7"
        disabled={!override}
        tooltip="Remove every change made to this repeat, so it matches the template"
        onClick={onReset}
      >
        Reset to template
      </Button>
    </section>
  );
}

const WATERFALL_MODES = [
  {
    value: "bridge" as const,
    label: "Change",
    tooltip:
      "Bridge one state's total to another's, such as plan to actual, one signed step per category.",
  },
  {
    value: "accumulate" as const,
    label: "Running",
    tooltip:
      "Add each step's signed measure in order from a start value, such as energy in and out through a day.",
  },
];

function WaterfallFields({
  mark,
  numericFields,
  onChange,
}: {
  mark: WaterfallMark;
  numericFields: string[];
  onChange: (patch: Partial<WaterfallMark>) => void;
}) {
  const id = useId();
  const states = [0, 1].map(
    (index) =>
      mark.states[index] ?? { label: index ? "End" : "Start", filters: [] }
  );
  const changeState = (index: number, patch: Partial<(typeof states)[0]>) =>
    onChange({
      states: states.map((state, at) =>
        at === index ? { ...state, ...patch } : state
      ),
    });
  return (
    <>
      <span className="eda-setting-label">Shows</span>
      <Segmented
        label={`${mark.name} mode`}
        value={mark.mode}
        options={WATERFALL_MODES}
        onChange={(mode) => onChange({ mode })}
      />
      <Label htmlFor={`${id}-aggregation`}>Measure</Label>
      <select
        id={`${id}-aggregation`}
        className="eda-composition-select"
        value={mark.aggregation}
        onChange={(event) => {
          const aggregation = event.target
            .value as WaterfallMark["aggregation"];
          onChange({
            aggregation,
            measureField:
              aggregation === "count"
                ? undefined
                : (mark.measureField ?? numericFields[0]),
          });
        }}
      >
        <option value="sum" disabled={!numericFields.length}>
          Sum
        </option>
        <option value="count">Count rows</option>
      </select>
      {mark.aggregation === "sum" && (
        <>
          <Label>Of</Label>
          <FieldSelector
            label=""
            placeholder="Measure"
            value={mark.measureField ?? ""}
            fields={numericFields}
            onChange={(measureField) => onChange({ measureField })}
          />
        </>
      )}
      <Label>Steps</Label>
      <FieldSelector
        label=""
        placeholder="Step field"
        value={mark.stepField}
        onChange={(stepField) => onChange({ stepField })}
      />
      <Label>Group by</Label>
      <FieldSelector
        label=""
        placeholder="No subtotals"
        value={mark.parentField ?? ""}
        allowClear
        onChange={(parentField) =>
          onChange({ parentField: parentField || undefined })
        }
      />
      <Label htmlFor={`${id}-start`}>Start label</Label>
      <Input
        id={`${id}-start`}
        value={states[0]!.label}
        onChange={(event) => changeState(0, { label: event.target.value })}
      />
      <Label htmlFor={`${id}-end`}>End label</Label>
      <Input
        id={`${id}-end`}
        value={states[1]!.label}
        onChange={(event) => changeState(1, { label: event.target.value })}
      />
      {mark.mode === "accumulate" ? (
        <NumberSetting
          label="Start value"
          value={mark.startValue ?? 0}
          onChange={(startValue) => onChange({ startValue })}
        />
      ) : (
        states.map((state, index) => (
          <Fragment key={index}>
            <span className="eda-setting-label">
              {index ? "End rows" : "Start rows"}
            </span>
            <div className="space-y-1">
              {mark.aggregation === "sum" && (
                <FieldSelector
                  label=""
                  placeholder="Same measure"
                  value={state.measureField ?? ""}
                  allowClear
                  fields={numericFields}
                  onChange={(measureField) =>
                    changeState(index, {
                      measureField: measureField || undefined,
                    })
                  }
                />
              )}
              <FilterListEditor
                filters={state.filters}
                onChange={(filters) => changeState(index, { filters })}
                addPlaceholder="Count only rows where…"
              />
            </div>
          </Fragment>
        ))
      )}
      <NumberSetting
        label="Name width"
        min={0}
        max={400}
        value={mark.labelWidth}
        onChange={(labelWidth) => onChange({ labelWidth })}
      />
      <ColorSetting
        label="Rising"
        value={mark.up}
        onChange={(up) => onChange({ up })}
      />
      <ColorSetting
        label="Falling"
        value={mark.down}
        onChange={(down) => onChange({ down })}
      />
      <ColorSetting
        label="Totals"
        value={mark.total}
        onChange={(total) => onChange({ total })}
      />
    </>
  );
}

function DonutFields({
  mark,
  numericFields,
  onChange,
}: {
  mark: DonutMark;
  numericFields: string[];
  onChange: (patch: Partial<DonutMark>) => void;
}) {
  const id = useId();
  const profiles = useDataLayer((state) => state.fieldProfiles);
  const categoryFields = profiles
    .filter((profile) => profile.uniqueCount <= 50)
    .map((profile) => profile.name);
  return (
    <>
      <Label>Categories</Label>
      <FieldSelector
        label=""
        placeholder="Category field"
        value={mark.categoryField}
        fields={categoryFields}
        onChange={(categoryField) => onChange({ categoryField })}
      />
      <Label htmlFor={`${id}-aggregation`}>Measure</Label>
      <select
        id={`${id}-aggregation`}
        className="eda-composition-select"
        value={mark.aggregation}
        onChange={(event) => {
          const aggregation = event.target.value as DonutMark["aggregation"];
          onChange({
            aggregation,
            measureField:
              aggregation === "count"
                ? undefined
                : (mark.measureField ?? numericFields[0]),
          });
        }}
      >
        <option value="count">Count rows</option>
        <option value="sum" disabled={!numericFields.length}>
          Sum
        </option>
      </select>
      {mark.aggregation === "sum" && (
        <>
          <Label>Of</Label>
          <FieldSelector
            label=""
            placeholder="Measure"
            value={mark.measureField ?? ""}
            fields={numericFields}
            onChange={(measureField) => onChange({ measureField })}
          />
        </>
      )}
      <NumberSetting
        label="Top N"
        min={1}
        max={24}
        value={mark.topN ?? 6}
        onChange={(topN) => onChange({ topN })}
      />
      <span className="eda-setting-label">Colors</span>
      <Segmented
        label={`${mark.name} color order`}
        value={mark.order}
        options={STACK_ORDERS}
        onChange={(order) => onChange({ order })}
      />
      <NumberSetting
        label="Hole"
        min={0}
        max={0.9}
        value={mark.hole}
        onChange={(hole) => onChange({ hole })}
      />
      <span className="eda-setting-label">Total</span>
      <Segmented
        label={`${mark.name} total in the hole`}
        value={mark.showTotal}
        options={[
          {
            value: true,
            label: "Show",
            tooltip: "Write the repeat's total in the hole.",
          },
          { value: false, label: "Hide", tooltip: "Leave the hole empty." },
        ]}
        onChange={(showTotal) => onChange({ showTotal })}
      />
    </>
  );
}
