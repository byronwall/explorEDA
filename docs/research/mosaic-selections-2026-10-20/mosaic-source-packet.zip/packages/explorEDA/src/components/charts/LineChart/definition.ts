import {
  type BaseChartSettings,
  type ChartDefinition,
  type ChartLayout,
  type datum,
} from "@/types/ChartTypes";
import { applyFilter } from "@/hooks/applyFilter";
import { DEFAULT_MARGIN_SETTINGS } from "@/utils/defaultSettings";
import { IdType } from "@/providers/DataLayerProvider";
import { Filter } from "@/types/FilterTypes";
import { LineChart as LineChartIcon } from "lucide-react";
import { LineChart } from "./LineChart";
import { LineChartSettingsPanel } from "./LineChartSettingsPanel";
import type { AggregateAggregation } from "@/lib/aggregates";
import type { TimeInterval, WeekStart } from "@/lib/dailyRollup";

export interface TimeSeriesSettings {
  display?: "line" | "area" | "stacked-area";
  interval: TimeInterval;
  weekStart: WeekStart;
  aggregation: AggregateAggregation;
  measureField?: string;
  splitField?: string;
  missingPeriods: "gap" | "zero";
}

export const DEFAULT_TIME_SERIES: TimeSeriesSettings = {
  interval: "month",
  weekStart: "monday",
  aggregation: "count",
  missingPeriods: "gap",
};

export interface SeriesSettings {
  showPoints: boolean;
  pointSize: number;
  pointOpacity: number;
  lineWidth: number;
  lineOpacity: number;
  lineColor?: string;
  lineStyle: "solid" | "dashed" | "dotted";
  useRightAxis: boolean;
}

export interface LineChartSettings extends BaseChartSettings {
  type: "line";
  time?: TimeSeriesSettings;

  // Data fields
  xField: string;
  seriesField: string[];

  // Series settings
  seriesSettings: Record<string, SeriesSettings>;

  // Global line styling
  styles: {
    curveType: "linear" | "monotoneX" | "step";
  };

  // Grid options
  showXGrid: boolean;
  showYGrid: boolean;

  // Legend options
  showLegend: boolean;
  legendPosition: "top" | "right" | "bottom" | "left";
}

export const DEFAULT_SERIES_SETTINGS: SeriesSettings = {
  showPoints: false,
  pointSize: 3,
  pointOpacity: 0.8,
  lineWidth: 2,
  lineOpacity: 1,
  lineStyle: "solid",
  useRightAxis: false,
};

export const lineChartDefinition: ChartDefinition<LineChartSettings> = {
  type: "line",
  name: "Line Chart",
  description: "Display data as connected points over time or sequence",
  icon: LineChartIcon,
  component: LineChart,
  settingsPanel: LineChartSettingsPanel,
  createDefaultSettings: (layout: ChartLayout): LineChartSettings => ({
    id: "",
    type: "line",
    title: "",
    field: "",
    layout,
    colorScaleId: undefined,
    colorField: undefined,
    facet: {
      enabled: false,
      type: "grid",
      rowVariable: "",
      columnVariable: "",
    },
    xAxis: { grid: false },
    yAxis: { grid: true },
    margin: { ...DEFAULT_MARGIN_SETTINGS },
    filters: [],
    xAxisLabel: "",
    yAxisLabel: "",
    xGridLines: 5,
    yGridLines: 4,
    xField: "",
    seriesField: [],
    seriesSettings: {},
    styles: {
      curveType: "linear",
    },
    showXGrid: true,
    showYGrid: true,
    showLegend: true,
    legendPosition: "top",
  }),
  validateSettings: (settings: LineChartSettings): boolean => {
    return (
      settings.xField !== "" &&
      (settings.time
        ? settings.time.aggregation === "count" ||
          Boolean(settings.time.measureField)
        : settings.seriesField.length > 0)
    );
  },
  getFilterFunction: (
    settings: LineChartSettings,
    fieldGetter: (name: string) => Record<IdType, datum>
  ) => {
    // Look each column up once; the returned test runs once per row.
    const filters = settings.filters.map((filter: Filter) => ({
      filter,
      values: fieldGetter(filter.field),
    }));
    return (d: IdType) =>
      filters.every(({ filter, values }) => applyFilter(values[d], filter));
  },
};
