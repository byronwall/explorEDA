import { serviceDistricts } from "./regionMapGeometry";
import type { SavedDataStructure } from "exploreda";

type Chart = SavedDataStructure["charts"][number];
const palette = ["#3479a8", "#c77a45", "#4b9688", "#9c6eac", "#bd596a"];
const base = {
  field: "",
  colorField: undefined,
  colorScaleId: undefined,
  xAxis: { grid: false },
  yAxis: { grid: true },
  margin: { top: 16, right: 24, bottom: 44, left: 62 },
  facet: {
    enabled: false,
    type: "wrap" as const,
    rowVariable: "",
    columnCount: 2,
  },
  xAxisLabel: "",
  yAxisLabel: "",
  xGridLines: 5,
  yGridLines: 4,
  filters: [],
};
const layout = (x: number, y: number, w: number, h = 4) => ({ x, y, w, h });
const row = (
  id: string,
  title: string,
  field: string,
  position: ReturnType<typeof layout>,
  colorScaleId?: string
): Extract<Chart, { type: "row" }> => ({
  ...base,
  id,
  type: "row",
  title,
  field,
  layout: position,
  minRowHeight: 22,
  maxRowHeight: 36,
  xAxisLabel: "Records",
  xAxis: { grid: true },
  yAxis: { grid: false },
  colorField: colorScaleId ? field : undefined,
  colorScaleId,
});
export const histogram = (
  id: string,
  title: string,
  field: string,
  position: ReturnType<typeof layout>,
  label = field
): Extract<Chart, { type: "bar" }> => ({
  ...base,
  id,
  type: "bar",
  title,
  field,
  layout: position,
  binCount: 20,
  xAxisLabel: label,
  yAxisLabel: "Records",
});
const scatter = (
  id: string,
  title: string,
  xField: string,
  yField: string,
  position: ReturnType<typeof layout>,
  labels: [string, string],
  colorField?: string,
  colorScaleId?: string
): Extract<Chart, { type: "scatter" }> => ({
  ...base,
  id,
  type: "scatter",
  title,
  xField,
  yField,
  layout: position,
  xAxisLabel: labels[0],
  yAxisLabel: labels[1],
  colorField,
  colorScaleId,
});
const box = (
  id: string,
  title: string,
  field: string,
  group: string,
  position: ReturnType<typeof layout>,
  colorScaleId?: string,
  label = field
): Extract<Chart, { type: "boxplot" }> => ({
  ...base,
  id,
  type: "boxplot",
  title,
  field,
  colorField: group,
  colorScaleId,
  layout: position,
  yAxisLabel: label,
  whiskerType: "tukey",
  showOutliers: true,
  violinOverlay: false,
  sortBy: "label",
  violinBandwidth: 0.3,
  autoBandwidth: true,
  styles: {
    boxFill: palette[0]!,
    boxStroke: palette[0]!,
    boxStrokeWidth: 0,
    medianStroke: "white",
    medianStrokeWidth: 2,
    whiskerStroke: palette[0]!,
    whiskerStrokeWidth: 1.5,
    outlierSize: 2,
    outlierStroke: palette[0]!,
    outlierFill: "none",
  },
});
const table = (
  id: string,
  title: string,
  fields: string[],
  position: ReturnType<typeof layout>
): Chart => ({
  ...base,
  id,
  type: "data-table",
  title,
  layout: position,
  columns: fields.map((field) => ({ id: field, field })),
  sortDirection: "asc",
  globalSearch: "",
});
const line = (
  id: string,
  title: string,
  fields: string[],
  position: ReturnType<typeof layout>,
  label: string
): Extract<Chart, { type: "line" }> => ({
  ...base,
  id,
  type: "line",
  title,
  layout: position,
  xField: "Day",
  seriesField: fields,
  xAxisLabel: "Day of study",
  yAxisLabel: label,
  seriesSettings: Object.fromEntries(
    fields.map((field, i) => [
      field,
      {
        showPoints: false,
        pointSize: 3,
        pointOpacity: 0.8,
        lineWidth: 2,
        lineOpacity: 1,
        lineColor: palette[i],
        lineStyle: "solid",
        useRightAxis: false,
      },
    ])
  ),
  styles: { curveType: "linear" },
  showXGrid: true,
  showYGrid: false,
  showLegend: fields.length > 1,
  legendPosition: "top",
});
const dashboard = (
  name: string,
  charts: Chart[],
  colorScales: SavedDataStructure["colorScales"] = []
): SavedDataStructure => ({
  charts,
  calculations: [],
  colorScales,
  gridSettings: {
    columnCount: 12,
    rowHeight: 76,
    containerPadding: 0,
    showBackgroundMarkers: false,
  },
  metadata: {
    name,
    version: 1,
    createdAt: "2026-09-16T00:00:00Z",
    modifiedAt: "2026-09-16T00:00:00Z",
  },
});
const categoricalScale = (
  id: string,
  name: string,
  labels: string[]
): SavedDataStructure["colorScales"][number] => ({
  id,
  name,
  sourceField: name,
  type: "categorical",
  palette,
  mapping: labels.map((label, i) => [label, palette[i % palette.length]!]),
});

export const penguinDashboard = dashboard(
  "Penguin field notes",
  [
    scatter(
      "penguin-size",
      "Body size & flipper length",
      "flipper_length_mm",
      "body_mass_g",
      layout(0, 0, 6, 5),
      ["Flipper length (mm)", "Body mass (g)"],
      "species",
      "species-colors"
    ),
    row(
      "penguin-species",
      "Species · shared color key",
      "species",
      layout(6, 0, 3, 5),
      "species-colors"
    ),
    row("penguin-island", "Sampling islands", "island", layout(9, 0, 3, 5)),
    scatter(
      "penguin-bill",
      "Bill shape separates species",
      "bill_length_mm",
      "bill_depth_mm",
      layout(0, 5, 4, 4),
      ["Bill length (mm)", "Bill depth (mm)"],
      "species",
      "species-colors"
    ),
    box(
      "penguin-mass",
      "Body mass by species",
      "body_mass_g",
      "species",
      layout(4, 5, 4, 4),
      "species-colors",
      "Body mass (g)"
    ),
    histogram(
      "penguin-flipper",
      "Flipper length distribution",
      "flipper_length_mm",
      layout(8, 5, 4, 4),
      "Flipper length (mm)"
    ),
    table(
      "penguin-records",
      "Selected observations",
      [
        "species",
        "island",
        "sex",
        "bill_length_mm",
        "bill_depth_mm",
        "flipper_length_mm",
        "body_mass_g",
        "year",
      ],
      layout(0, 9, 12, 5)
    ),
    {
      ...base,
      id: "penguin-profile",
      type: "parallel-coordinates",
      title: "Four measurements, one line per penguin",
      colorField: "species",
      colorScaleId: "species-colors",
      axes: [
        { field: "bill_length_mm", inverted: false },
        { field: "bill_depth_mm", inverted: false },
        { field: "flipper_length_mm", inverted: false },
        { field: "body_mass_g", inverted: false },
        { field: "island", inverted: false },
      ],
      lineOpacity: 0.45,
      lineWidth: 1.25,
      layout: layout(0, 14, 12, 6),
      margin: { top: 8, right: 8, bottom: 8, left: 8 },
    },
  ],
  [
    categoricalScale("species-colors", "species", [
      "Adelie",
      "Chinstrap",
      "Gentoo",
    ]),
  ]
);

export const shopDashboard = dashboard(
  "Inside the order book",
  [
    scatter(
      "shop-margin",
      "Revenue & margin per order",
      "Revenue",
      "Margin",
      layout(0, 0, 6, 5),
      ["Revenue ($)", "Margin ($)"],
      "Category",
      "category-colors"
    ),
    row(
      "shop-category",
      "Orders by category",
      "Category",
      layout(6, 0, 3, 5),
      "category-colors"
    ),
    row("shop-channel", "Sales channels", "Channel", layout(9, 0, 3, 5)),
    histogram(
      "shop-delivery",
      "How long does delivery take?",
      "Delivery Days",
      layout(0, 5, 4),
      "Delivery time (days)"
    ),
    box(
      "shop-order",
      "Order value by category",
      "Revenue",
      "Category",
      layout(4, 5, 4),
      "category-colors"
    ),
    {
      ...base,
      id: "shop-region",
      type: "bar",
      title: "Revenue by region",
      field: "Revenue",
      aggregateId: "revenue-by-region",
      layout: layout(8, 5, 4),
      xAxisLabel: "Region",
      yAxisLabel: "Revenue ($)",
    },
    table(
      "shop-orders",
      "Orders in this selection",
      [
        "Order Date",
        "Region",
        "Channel",
        "Category",
        "Product",
        "Revenue",
        "Margin",
        "Delivery Days",
        "Returned",
      ],
      layout(0, 9, 12, 5)
    ),
  ],
  [
    categoricalScale("category-colors", "Category", [
      "Home",
      "Outdoors",
      "Electronics",
      "Kitchen",
    ]),
  ]
);

export const activityDashboard = dashboard(
  "90 days of product activity",
  [
    line(
      "activity-traffic",
      "Daily active & returning visitors",
      ["Visitors", "Returning visitors"],
      layout(0, 0, 8, 5),
      "Visitors / day"
    ),
    row(
      "activity-weekday",
      "Days by release phase",
      "Phase",
      layout(8, 0, 4, 5),
      "phase-colors"
    ),
    {
      ...line(
        "activity-conversion",
        "Trial conversion over time",
        ["Conversion (%)"],
        layout(0, 5, 4),
        "Conversion (%)"
      ),
      annotations: [
        {
          id: "activity-release",
          type: "band",
          axis: "x",
          from: 31,
          to: 60,
          label: "Release",
        },
        {
          id: "activity-target",
          type: "reference-line",
          axis: "y",
          value: 4,
          label: "Target 4%",
        },
      ],
    },
    scatter(
      "activity-speed",
      "Does speed relate to conversion?",
      "Response time (ms)",
      "Conversion (%)",
      layout(4, 5, 4),
      ["Response time (ms)", "Conversion (%)"],
      "Phase",
      "phase-colors"
    ),
    histogram(
      "activity-latency",
      "Response time distribution",
      "Response time (ms)",
      layout(8, 5, 4),
      "Response time (ms)"
    ),
    box(
      "activity-distribution",
      "Conversion by release phase",
      "Conversion (%)",
      "Phase",
      layout(0, 9, 4, 5),
      "phase-colors"
    ),
    table(
      "activity-records",
      "Daily observations",
      [
        "Day",
        "Phase",
        "Visitors",
        "Returning visitors",
        "Trials",
        "Conversion (%)",
        "Response time (ms)",
      ],
      layout(4, 9, 8, 5)
    ),
    {
      ...base,
      id: "activity-speed-share",
      type: "ecdf",
      title: "How many days stay under a response time?",
      field: "Response time (ms)",
      colorField: "Phase",
      colorScaleId: "phase-colors",
      direction: "below",
      logX: false,
      showQuantiles: true,
      showOverall: false,
      layout: layout(0, 14, 12, 5),
      margin: { top: 8, right: 16, bottom: 8, left: 8 },
    },
  ],
  [
    categoricalScale("phase-colors", "Phase", [
      "Baseline",
      "Release",
      "Follow-up",
    ]),
  ]
);

export const bubbleDashboard: SavedDataStructure = {
  ...activityDashboard,
  metadata: {
    ...activityDashboard.metadata,
    name: "Trial volume, speed, and conversion",
  },
  charts: [
    {
      ...scatter(
        "bubble-trials",
        "Speed, conversion, and trial volume",
        "Response time (ms)",
        "Conversion (%)",
        layout(0, 0, 8, 6),
        ["Response time (ms)", "Conversion (%)"],
        "Phase",
        "phase-colors"
      ),
      sizeField: "Trials",
      maxBubbleRadius: 20,
      pointOpacity: 0.5,
      annotations: [
        {
          id: "bubble-slow-day",
          type: "callout",
          text: "Day 31: slowest response",
          attach: { kind: "record", keyFields: ["Day"], key: [31] },
          offset: { dx: -24, dy: -28 },
        },
        {
          id: "bubble-target",
          type: "reference-line",
          axis: "y",
          value: 4,
          label: "Conversion target 4%",
        },
        {
          id: "bubble-mean-speed",
          type: "reference-line",
          axis: "x",
          value: 0,
          calculated: { statistic: "mean", population: "filtered" },
          label: "Mean response",
        },
        {
          id: "bubble-fast-days",
          type: "region",
          shape: "ellipse",
          x0: 275,
          x1: 345,
          y0: 4.1,
          y1: 5.15,
          label: "Fast, high-converting days",
        },
      ],
    },
    {
      ...base,
      id: "bubble-total",
      type: "metric-card",
      title: "Trials in this selection",
      aggregation: "sum",
      measureField: "Trials",
      layout: layout(8, 0, 4, 2),
    },
    row(
      "bubble-phase",
      "Days by release phase",
      "Phase",
      layout(8, 2, 4, 4),
      "phase-colors"
    ),
    table(
      "bubble-records",
      "Daily observations",
      [
        "Day",
        "Phase",
        "Visitors",
        "Returning visitors",
        "Trials",
        "Conversion (%)",
        "Response time (ms)",
      ],
      layout(0, 6, 12, 5)
    ),
  ],
};

// Region bars sum revenue; clicking one selects that region everywhere.
const revenueByRegion: NonNullable<SavedDataStructure["aggregates"]> = [
  {
    id: "revenue-by-region",
    name: "Revenue by region",
    groupField: "Region",
    measureField: "Revenue",
    aggregation: "sum",
  },
];
shopDashboard.aggregates = revenueByRegion;

// Wide order values include genuine outliers; keep them visible without flattening the main population.
for (const chart of shopDashboard.charts) {
  if (chart.type === "scatter") {
    chart.xAxis = { ...chart.xAxis, scaleType: "symlog" };
    chart.yAxis = { ...chart.yAxis, scaleType: "symlog" };
  }
  if (chart.type === "boxplot") {
    chart.yAxis = { ...chart.yAxis, scaleType: "symlog" };
    chart.yAxisLabel = "Revenue ($)";
  }
}

export const largeShopDashboard = dashboard(
  "10,000 orders · 16 linked views",
  [
    ...shopDashboard.charts,
    histogram("large-units", "Units per order", "Units", layout(0, 14, 4)),
    histogram(
      "large-discount",
      "Discount distribution",
      "Discount",
      layout(4, 14, 4)
    ),
    row("large-returned", "Returned orders", "Returned", layout(8, 14, 4)),
    scatter(
      "large-volume",
      "Units & revenue",
      "Units",
      "Revenue",
      layout(0, 18, 6),
      ["Units", "Revenue ($)"]
    ),
    scatter(
      "large-cost",
      "Revenue & cost",
      "Revenue",
      "Cost",
      layout(6, 18, 6),
      ["Revenue ($)", "Cost ($)"]
    ),
    box(
      "large-margin",
      "Margin by category",
      "Margin",
      "Category",
      layout(0, 22, 6),
      "category-colors",
      "Margin ($)"
    ),
    row(
      "large-segment",
      "Customer segments",
      "Customer Segment",
      layout(6, 22, 6)
    ),
    {
      ...line(
        "large-trend",
        "Order values by region",
        ["Revenue"],
        layout(0, 26, 12, 5),
        "Revenue ($)"
      ),
      xField: "Order",
      xAxisLabel: "Order sequence",
      facet: {
        enabled: true,
        type: "wrap",
        rowVariable: "Region",
        columnCount: 2,
      },
    } as Chart,
    {
      ...base,
      id: "large-daily-revenue",
      type: "calendar",
      title: "Daily revenue through 2024",
      field: "Order Date",
      aggregation: "sum",
      measureField: "Revenue",
      weekStart: "monday",
      layout: layout(0, 31, 12, 4),
      margin: { top: 8, right: 16, bottom: 8, left: 8 },
    },
  ],
  shopDashboard.colorScales
);
largeShopDashboard.aggregates = revenueByRegion;

// Only the 500-order book gets the heatmap; the large book fills this row.
shopDashboard.charts.push({
  ...base,
  id: "shop-category-region",
  type: "heatmap",
  title: "Where does revenue come from?",
  field: "Category",
  columnField: "Region",
  aggregation: "sum",
  measureField: "Revenue",
  maxCategories: 20,
  sortBy: "count",
  showValues: true,
  layout: layout(0, 14, 6, 6),
  margin: { top: 8, right: 16, bottom: 8, left: 8 },
});

export const scatterTraceDashboard: SavedDataStructure = {
  ...dashboard(
    "Trace a scatter point",
    [
      {
        ...base,
        id: "trace-guide",
        type: "markdown",
        title: "Source to scatter glyph",
        layout: layout(0, 0, 12, 2),
        content:
          "<p>Use the chart-header trace icon, or Alt-click a point, chart title, axis object, color label, or facet label. Normal clicks keep brushing and filtering. Find a source row in the trace panel. Each point links raw values, calculations, filters, scales, and pixels. Rows T-006 and T-013 have missing numeric inputs.</p>",
      },
      {
        ...scatter(
          "trace-scatter",
          "Net sales to contribution",
          "Net sales",
          "Contribution",
          layout(0, 2, 9, 7),
          ["Net sales ($)", "Contribution ($)"],
          "Channel",
          "trace-channel-colors"
        ),
        xAxis: { grid: true },
        yAxis: { grid: true },
      },
      row("trace-channel", "Filter by channel", "Channel", layout(9, 2, 3, 7)),
      table(
        "trace-rows",
        "Source rows and calculated values",
        [
          "Order",
          "Units",
          "Unit Price",
          "Discount",
          "Cost",
          "Channel",
          "Gross sales",
          "Net sales",
          "Contribution",
        ],
        layout(0, 9, 12, 5)
      ),
    ],
    [
      categoricalScale("trace-channel-colors", "Channel", [
        "Online",
        "Store",
        "Partner",
      ]),
    ]
  ),
  calculations: [
    { resultColumnName: "Gross sales", expression: 'Units * ["Unit Price"]' },
    { resultColumnName: "Net sales", expression: '["Gross sales"] - Discount' },
    { resultColumnName: "Contribution", expression: '["Net sales"] - Cost' },
  ],
  fieldSettings: {
    Units: { type: "numeric" },
    "Unit Price": { type: "numeric" },
    Discount: { type: "numeric" },
    Cost: { type: "numeric" },
    "Net sales": { format: "currency", precision: 0 },
    Contribution: { format: "currency", precision: 0 },
  },
};

export const chartControlsDashboard: SavedDataStructure = {
  ...dashboard(
    "Change a chart where it sits",
    [
      {
        ...base,
        id: "controls-guide",
        type: "markdown",
        title: "Change color in place",
        layout: layout(0, 0, 12, 2),
        content:
          "<p>Click <b>Color: None</b> above the left chart, type part of a field name, and press Enter. The chart recolors at once and its filter stays put. Press Ctrl-Z or ⌘Z to undo. Choose Channel to share the right chart's colors.</p>",
      },
      {
        ...scatter(
          "controls-scatter",
          "Units against net sales",
          "Net sales",
          "Units",
          layout(0, 2, 6, 7),
          ["Net sales ($)", "Units"]
        ),
        filters: [{ type: "range", field: "Net sales", min: 80 }],
        xAxis: { grid: true },
        yAxis: { grid: true },
      },
      {
        ...scatter(
          "controls-peer",
          "Net sales to contribution",
          "Net sales",
          "Contribution",
          layout(6, 2, 6, 7),
          ["Net sales ($)", "Contribution ($)"],
          "Channel",
          "controls-channel-colors"
        ),
        xAxis: { grid: true },
        yAxis: { grid: true },
      },
    ],
    [
      categoricalScale("controls-channel-colors", "Channel", [
        "Online",
        "Store",
        "Partner",
      ]),
    ]
  ),
  calculations: scatterTraceDashboard.calculations,
  fieldSettings: scatterTraceDashboard.fieldSettings,
};

const orderCalculations = [
  [
    "Discount rate",
    "min(0.25, max(0, if Discount == null then 0 else Discount))",
  ],
  ["Gross sales", 'Units * ["Unit Price"]'],
  ["Discount amount", '["Gross sales"] * ["Discount rate"]'],
  ["Net sales", '["Gross sales"] - ["Discount amount"]'],
  ["Contribution", '["Net sales"] - Cost'],
  [
    "Contribution rate",
    'if ["Net sales"] > 0 then ["Contribution"] / ["Net sales"] * 100 else 0',
  ],
  ["Sales per unit", '["Net sales"] / max(1, Units)'],
  [
    "Order band",
    'if ["Net sales"] >= 500 then "Large" else if ["Net sales"] >= 100 then "Standard" else "Small"',
  ],
  [
    "Service score",
    '100 * avg(if Fulfilled then 1 else 0, if Returned then 0 else 1, if ["Delivery Days"] == null then 0 else if ["Delivery Days"] <= 5 then 1 else 0)',
  ],
  [
    "Risk points",
    'sum(if Returned then 10 else 0, if !Fulfilled then 5 else 0, if ["Delivery Days"] != null && ["Delivery Days"] > 7 then 2 else 0)',
  ],
  ["Needs review", '["Risk points"] >= 5 || ["Contribution"] < 0'],
  ["Order month", 'formatDate(["Order Date"], "%Y-%m")'],
  ["Order quarter", 'extractDateComponent(["Order Date"], "quarter")'],
  ["Target gap", 'max(0, 45 - ["Contribution rate"])'],
].map(([resultColumnName, expression]) => ({
  resultColumnName: resultColumnName!,
  expression: expression!,
}));

export const calculationDashboard: SavedDataStructure = {
  ...dashboard("From orders to contribution", [
    {
      ...base,
      id: "calc-guide",
      type: "markdown",
      title: "Follow a value from source to result",
      layout: layout(0, 0, 12, 2),
      content:
        "<p><strong>Gross sales → Discount amount → Net sales → Contribution.</strong> Hover an <strong>ƒx</strong> field to inspect its chain. In Discount rate, try a 10% cap, preview, then Apply.</p>",
    },
    {
      ...scatter(
        "calc-sales-contribution",
        "How much of each order remains?",
        "Net sales",
        "Contribution",
        layout(0, 2, 6, 5),
        ["Net sales ($)", "Contribution ($)"]
      ),
      xAxis: { scaleType: "symlog", grid: false },
      yAxis: { scaleType: "symlog", grid: true },
    },
    row("calc-order-band", "Orders by size", "Order band", layout(6, 2, 3, 5)),
    row(
      "calc-review",
      "Which orders need review?",
      "Needs review",
      layout(9, 2, 3, 5)
    ),
    histogram(
      "calc-rate",
      "Contribution as a share of sales",
      "Contribution rate",
      layout(0, 7, 4),
      "Contribution (%)"
    ),
    histogram(
      "calc-unit-sales",
      "Sales per unit",
      "Sales per unit",
      layout(4, 7, 4)
    ),
    histogram(
      "calc-discounts",
      "Discount amount per order",
      "Discount amount",
      layout(8, 7, 4)
    ),
    table(
      "calc-chain-table",
      "Trace the order calculation",
      [
        "Order",
        "Units",
        "Unit Price",
        "Gross sales",
        "Discount rate",
        "Discount amount",
        "Net sales",
        "Cost",
        "Contribution",
        "Contribution rate",
      ],
      layout(0, 11, 12, 5)
    ),
    row(
      "calc-service",
      "Service score: three checks",
      "Service score",
      layout(0, 16, 4)
    ),
    row("calc-risk", "Risk points by order", "Risk points", layout(4, 16, 4)),
    row(
      "calc-quarter",
      "Orders by UTC quarter",
      "Order quarter",
      layout(8, 16, 4)
    ),
    {
      ...line(
        "calc-quarter-sales",
        "Net sales across quarters",
        ["Net sales"],
        layout(0, 20, 8, 6),
        "Net sales"
      ),
      xField: "Order",
      xAxisLabel: "Order sequence",
      facet: {
        enabled: true,
        type: "wrap",
        rowVariable: "Order quarter",
        columnCount: 2,
      },
    },
    {
      ...base,
      id: "calc-monthly",
      type: "pivot",
      title: "Monthly sales and contribution",
      layout: layout(8, 20, 4, 6),
      rowFields: ["Order month"],
      columnField: "",
      valueFields: [
        { field: "Net sales", aggregation: "sum", label: "Net sales" },
        { field: "Contribution", aggregation: "sum", label: "Contribution" },
      ],
    },
    histogram(
      "calc-target",
      "Gap to 45% contribution target",
      "Target gap",
      layout(0, 26, 12),
      "Percentage points below target"
    ),
  ]),
  calculations: orderCalculations,
};

// Placed beside the revenue heatmap, which shares its row and height.
shopDashboard.charts.push({
  ...base,
  id: "shop-flow",
  type: "sankey",
  title: "Which channels and categories lead to returns?",
  stages: ["Channel", "Category", "Returned"],
  aggregation: "count",
  missingStages: "omit",
  maxNodesPerStage: 8,
  nodeOrder: "value",
  flowColor: "first",
  layout: layout(6, 14, 6, 6),
  margin: { top: 8, right: 12, bottom: 8, left: 12 },
});

// Add the metric row only to this example; the large order book keeps its layout.
shopDashboard.charts = [
  ...(
    [
      ["shop-count", "Matching orders", "count"],
      ["shop-revenue", "Revenue in this selection", "sum"],
      ["shop-average", "Average order value", "average"],
    ] as const
  ).map(
    ([id, title, aggregation], index): Chart => ({
      ...base,
      id,
      type: "metric-card",
      title,
      aggregation,
      measureField: aggregation === "count" ? undefined : "Revenue",
      layout: layout(index * 4, 0, 4, 2),
    })
  ),
  ...shopDashboard.charts.map((chart) => ({
    ...chart,
    layout: { ...chart.layout, y: chart.layout.y + 2 },
  })),
];
shopDashboard.fieldSettings = {
  ...shopDashboard.fieldSettings,
  Revenue: { format: "currency", currency: "USD", precision: 2 },
};

export const timeSeriesDashboard = dashboard(
  "Orders through the calendar",
  [
    {
      ...line(
        "time-revenue",
        "Monthly revenue by channel",
        [],
        layout(0, 0, 8, 6),
        "Revenue ($)"
      ),
      xField: "Order Date",
      xAxisLabel: "Order date · UTC",
      colorField: "Channel",
      colorScaleId: "time-channel",
      time: {
        interval: "month",
        weekStart: "monday",
        aggregation: "sum",
        measureField: "Revenue",
        splitField: "Channel",
        missingPeriods: "gap",
      },
      annotations: [
        {
          id: "time-summer-sale",
          type: "band",
          axis: "x",
          // 2024-06-01 to 2024-08-31, UTC.
          from: 1717200000000,
          to: 1725062400000,
          label: "Summer sale",
          display: "bracket",
        },
      ],
    },
    {
      ...base,
      id: "time-count",
      type: "metric-card",
      title: "Matching orders",
      aggregation: "count",
      layout: layout(8, 0, 4, 2),
    },
    row(
      "time-channels",
      "Sales channels",
      "Channel",
      layout(8, 2, 4, 4),
      "time-channel"
    ),
    {
      ...line(
        "time-weekly",
        "Weekly order count",
        [],
        layout(0, 6, 6, 5),
        "Orders"
      ),
      xField: "Order Date",
      xAxisLabel: "Order date · UTC",
      time: {
        interval: "week",
        weekStart: "monday",
        aggregation: "count",
        missingPeriods: "zero",
      },
    },
    {
      ...base,
      id: "time-calendar",
      type: "calendar",
      title: "Daily orders",
      field: "Order Date",
      aggregation: "count",
      weekStart: "monday",
      layout: layout(6, 6, 6, 5),
    },
    table(
      "time-records",
      "Matching source records",
      ["Order Date", "Channel", "Revenue", "Region"],
      layout(0, 11, 12, 5)
    ),
  ],
  [categoricalScale("time-channel", "Channel", ["Web", "Store", "Wholesale"])]
);
timeSeriesDashboard.fieldSettings = {
  Revenue: {
    type: "numeric",
    format: "currency",
    currency: "USD",
    precision: 2,
  },
};

export const groupedBarsDashboard = dashboard(
  "Sales by region and channel",
  [
    {
      ...base,
      id: "grouped-revenue",
      type: "bar",
      title: "Revenue by region and channel",
      field: "Revenue",
      aggregateId: "grouped-sales",
      seriesField: "Channel",
      colorField: "Channel",
      colorScaleId: "grouped-channel",
      layout: layout(0, 0, 8, 6),
      yAxisLabel: "Revenue ($)",
    },
    {
      ...base,
      id: "grouped-total",
      type: "metric-card",
      title: "Matching revenue",
      aggregation: "sum",
      measureField: "Revenue",
      layout: layout(8, 0, 4, 2),
    },
    row(
      "grouped-categories",
      "Product categories",
      "Category",
      layout(8, 2, 4, 4)
    ),
    {
      ...base,
      id: "grouped-count",
      type: "bar",
      title: "Orders by category and channel",
      field: "Category",
      seriesField: "Channel",
      colorField: "Channel",
      colorScaleId: "grouped-channel",
      layout: layout(0, 6, 12, 5),
      yAxisLabel: "Orders",
    },
    table(
      "grouped-records",
      "Matching source records",
      ["Region", "Channel", "Category", "Revenue"],
      layout(0, 11, 12, 5)
    ),
  ],
  [
    categoricalScale("grouped-channel", "Channel", [
      "Web",
      "Store",
      "Wholesale",
    ]),
  ]
);
groupedBarsDashboard.aggregates = [
  {
    id: "grouped-sales",
    name: "Revenue by region",
    groupField: "Region",
    measureField: "Revenue",
    aggregation: "sum",
  },
];
groupedBarsDashboard.fieldSettings = {
  Revenue: {
    type: "numeric",
    format: "currency",
    currency: "USD",
    precision: 2,
  },
};

export const stackedBarsDashboard: SavedDataStructure = {
  ...groupedBarsDashboard,
  metadata: {
    ...groupedBarsDashboard.metadata,
    name: "Regional totals and channel shares",
  },
  charts: groupedBarsDashboard.charts.map((chart) =>
    chart.type === "bar"
      ? {
          ...chart,
          seriesLayout: chart.aggregateId ? "stacked" : "percent",
          title: chart.aggregateId
            ? "Regional revenue by channel"
            : "Channel share of regional orders",
          field: chart.aggregateId ? chart.field : "Region",
          yAxisLabel: chart.aggregateId
            ? "Revenue ($)"
            : "Share of regional orders (%)",
        }
      : chart
  ),
};

export const areaDashboard: SavedDataStructure = {
  ...timeSeriesDashboard,
  metadata: {
    ...timeSeriesDashboard.metadata,
    name: "Revenue layers through the year",
  },
  charts: timeSeriesDashboard.charts.map((chart) =>
    chart.type === "line" && chart.time
      ? {
          ...chart,
          title:
            chart.id === "time-revenue"
              ? "Monthly revenue layers"
              : "Weekly orders as an area",
          time: {
            ...chart.time,
            display: chart.id === "time-revenue" ? "stacked-area" : "area",
          },
        }
      : chart
  ),
};

export const densityDashboard = dashboard("Where daily observations cluster", [
  {
    ...scatter(
      "density-days",
      "Temperature and ice cream sales",
      "Temperature (°C)",
      "Ice Cream Sales",
      layout(0, 0, 8, 6),
      ["Temperature (°C)", "Ice cream sales"]
    ),
    display: "density",
    density: { xBins: 24, yBins: 20 },
  },
  {
    ...base,
    id: "density-count",
    type: "metric-card",
    title: "Days in this selection",
    aggregation: "count",
    layout: layout(8, 0, 4, 2),
  },
  histogram(
    "density-humidity",
    "Humidity of matching days",
    "Humidity (%)",
    layout(8, 2, 4, 4),
    "Humidity (%)"
  ),
  table(
    "density-records",
    "Daily source records",
    [
      "Temperature (°C)",
      "Ice Cream Sales",
      "Humidity (%)",
      "Beach Visitors",
      "Mood Index",
    ],
    layout(0, 6, 12, 5)
  ),
]);

export const pointMapDashboard = dashboard(
  "Where service requests originate",
  [
    {
      ...base,
      id: "map-sites",
      type: "map",
      mode: "point",
      title: "Service sites around the world",
      latitudeField: "Latitude",
      longitudeField: "Longitude",
      labelField: "Site",
      colorField: "Region",
      colorScaleId: "map-regions",
      sizeField: "Requests",
      pointRadius: 18,
      pointOpacity: 0.75,
      projection: "equal-earth",
      layout: layout(0, 0, 8, 7),
    },
    {
      ...base,
      id: "map-count",
      type: "metric-card",
      title: "Sites in this selection",
      aggregation: "count",
      layout: layout(8, 0, 4, 2),
    },
    {
      ...base,
      id: "map-regions",
      type: "bar",
      title: "Sites by region",
      field: "Region",
      layout: layout(8, 2, 4, 5),
      binCount: 20,
      yAxisLabel: "Sites",
    },
    table(
      "map-records",
      "Site source records",
      ["Site", "Latitude", "Longitude", "Region", "Requests"],
      layout(0, 7, 12, 5)
    ),
  ],
  [
    categoricalScale("map-regions", "Region", [
      "Americas",
      "Europe",
      "Africa",
      "Asia-Pacific",
    ]),
  ]
);

export const regionMapDashboard: SavedDataStructure = {
  ...dashboard("Requests across service districts", [
    {
      ...base,
      id: "district-map",
      type: "map",
      mode: "region",
      title: "Requests by service district",
      latitudeField: "",
      longitudeField: "",
      pointRadius: 6,
      pointOpacity: 0.8,
      projection: "equal-earth",
      view: { center: [-74.5, 41.5], zoom: 20 },
      geometryAssetId: "service-districts",
      regionField: "District",
      featureKey: "district",
      aggregation: "sum",
      measureField: "Requests",
      showRegionLabels: true,
      outlineWidth: 1,
      layout: layout(0, 0, 8, 7),
    },
    {
      ...base,
      id: "district-total",
      type: "metric-card",
      title: "Requests in this selection",
      aggregation: "sum",
      measureField: "Requests",
      layout: layout(8, 0, 4, 2),
    },
    {
      ...base,
      id: "district-pivot",
      type: "pivot",
      title: "Check the region totals",
      rowFields: ["District"],
      columnField: "",
      valueFields: [
        { field: "Requests", aggregation: "sum", label: "Requests" },
      ],
      layout: layout(8, 2, 4, 5),
    },
    table(
      "district-rows",
      "Request source records",
      ["District", "Team", "Requests"],
      layout(0, 7, 12, 4)
    ),
  ]),
  geometryAssets: [serviceDistricts],
  fieldSettings: { Requests: { type: "numeric" } },
};

export const distributionDashboard = dashboard(
  "Delivery times and smaller routes",
  [
    {
      ...histogram(
        "delivery-histogram",
        "Delivery time histogram",
        "Hours",
        layout(0, 0, 7, 5),
        "Delivery time (hours)"
      ),
      binCount: 12,
      forceString: false,
    },
    {
      ...row(
        "delivery-routes",
        "Shipments by route",
        "Route",
        layout(7, 0, 5, 5)
      ),
      minRowHeight: 36,
      maxRowHeight: 42,
    },
    {
      ...box(
        "delivery-distribution",
        "Delivery time by service",
        "Hours",
        "Service",
        layout(0, 5, 8, 6)
      ),
      violinOverlay: true,
      showObservations: true,
    },
    {
      ...base,
      id: "delivery-count",
      type: "metric-card",
      title: "Matching shipments",
      aggregation: "count",
      layout: layout(8, 5, 4, 2),
    },
    table(
      "delivery-records",
      "Shipment source records",
      ["Route", "Service", "Hours"],
      layout(8, 7, 4, 4)
    ),
  ]
);
distributionDashboard.fieldSettings = { Hours: { type: "numeric" } };

export const scatterRegressionDashboard = dashboard(
  "Bill shape within each species",
  [
    {
      ...scatter(
        "fit-bill",
        "Bill depth against bill length",
        "bill_length_mm",
        "bill_depth_mm",
        layout(0, 0, 7, 6),
        ["Bill length (mm)", "Bill depth (mm)"],
        "species",
        "fit-species"
      ),
      regression: { method: "linear", overall: true },
      summary: true,
      marginals: { bins: 24 },
    },
    {
      ...scatter(
        "fit-bill-sex",
        "The same fits for each sex",
        "bill_length_mm",
        "bill_depth_mm",
        layout(7, 0, 5, 6),
        ["Bill length (mm)", "Bill depth (mm)"],
        "species",
        "fit-species"
      ),
      regression: { method: "linear" },
      facet: {
        enabled: true,
        type: "wrap",
        rowVariable: "sex",
        columnCount: 1,
      },
      annotations: [
        {
          // Each panel reads its own rows, so each draws its own median.
          id: "fit-sex-median",
          type: "reference-line",
          axis: "y",
          value: 0,
          calculated: { statistic: "median", population: "all" },
          label: "Median depth",
        },
        {
          id: "fit-sex-gentoo",
          type: "callout",
          text: "Gentoo males",
          attach: { kind: "coordinate", x: 50, y: 15.7 },
          offset: { dx: 18, dy: 22 },
          facet: JSON.stringify(['["string","male"]', null]),
        },
      ],
    },
    row("fit-island", "Filter by island", "island", layout(0, 6, 3, 5)),
    {
      ...scatter(
        "fit-mass",
        "Body mass along flipper length · LOESS over density",
        "flipper_length_mm",
        "body_mass_g",
        layout(3, 6, 5, 5),
        ["Flipper length (mm)", "Body mass (g)"],
        "species",
        "fit-species"
      ),
      regression: { method: "loess", span: 0.6 },
      display: "contour",
      contour: { bandwidth: 0.75, levels: 5 },
    },
    {
      ...scatter(
        "fit-curve",
        "Flipper length along bill length · quadratic",
        "bill_length_mm",
        "flipper_length_mm",
        layout(8, 6, 4, 5),
        ["Bill length (mm)", "Flipper length (mm)"]
      ),
      regression: { method: "polynomial", degree: 2 },
    },
    table(
      "fit-records",
      "Penguins in the fits",
      [
        "species",
        "island",
        "sex",
        "bill_length_mm",
        "bill_depth_mm",
        "flipper_length_mm",
        "body_mass_g",
      ],
      layout(0, 11, 12, 4)
    ),
  ],
  [
    categoricalScale("fit-species", "species", [
      "Adelie",
      "Chinstrap",
      "Gentoo",
    ]),
  ]
);

export const scatterMatrixDashboard = dashboard(
  "Every pair at once",
  [
    {
      ...base,
      id: "matrix-penguins",
      type: "scatter-matrix",
      title: "Measurements, species, and sex, pair by pair",
      colorField: "species",
      colorScaleId: "matrix-species",
      fields: [
        "bill_length_mm",
        "flipper_length_mm",
        "body_mass_g",
        "species",
        "sex",
      ],
      lower: { numeric: "points", mixed: "points", categorical: "shares" },
      upper: { numeric: "correlation", mixed: "box", categorical: "tiles" },
      diagonal: { continuous: "density", categorical: "bars" },
      layout: layout(0, 0, 8, 10),
      margin: { top: 4, right: 4, bottom: 4, left: 4 },
    },
    row("matrix-island", "Filter by island", "island", layout(8, 0, 4, 4)),
    table(
      "matrix-records",
      "Penguins in the matrix",
      [
        "species",
        "island",
        "sex",
        "bill_length_mm",
        "flipper_length_mm",
        "body_mass_g",
      ],
      layout(8, 4, 4, 6)
    ),
  ],
  [
    categoricalScale("matrix-species", "species", [
      "Adelie",
      "Chinstrap",
      "Gentoo",
    ]),
  ]
);

export const scatterSurfaceDashboard = dashboard(
  "Ten thousand days, two ways to see density",
  [
    {
      ...scatter(
        "surface-hex",
        "Hexagonal counts",
        "Temperature (°C)",
        "Ice Cream Sales",
        layout(0, 0, 6, 6),
        ["Temperature (°C)", "Ice cream sales"]
      ),
      display: "hexbin",
      hexbin: { columns: 24 },
    },
    {
      ...scatter(
        "surface-kde",
        "Smoothed density with a linear fit",
        "Temperature (°C)",
        "Ice Cream Sales",
        layout(6, 0, 6, 6),
        ["Temperature (°C)", "Ice cream sales"]
      ),
      display: "contour",
      contour: { bandwidth: 1, levels: 6, showPoints: false },
      regression: { method: "linear" },
      summary: true,
    },
    histogram(
      "surface-humidity",
      "Filter by humidity",
      "Humidity (%)",
      layout(0, 6, 5, 4),
      "Humidity (%)"
    ),
    table(
      "surface-records",
      "Daily source records",
      ["Temperature (°C)", "Ice Cream Sales", "Humidity (%)", "Beach Visitors"],
      layout(5, 6, 7, 4)
    ),
  ]
);

const wineBands = ["Ordinary (3–5)", "Good (6)", "Excellent (7–8)"];

export const wineChemistryDashboard: SavedDataStructure = {
  ...dashboard(
    "What separates a good red wine",
    [
      {
        ...scatter(
          "wine-density",
          "Density falls as alcohol rises",
          "alcohol",
          "density",
          layout(0, 0, 7, 7),
          ["Alcohol (% vol)", "Density (g/cm³)"],
          "Quality band",
          "wine-bands"
        ),
        display: "contour",
        contour: { bandwidth: 0.8, levels: 6 },
        regression: { method: "loess", span: 0.7 },
        summary: true,
        marginals: { bins: 24 },
      },
      {
        ...scatter(
          "wine-acid",
          "More fixed acid, lower pH",
          "fixed acidity",
          "pH",
          layout(7, 0, 5, 7),
          ["Fixed acidity (g/L)", "pH"]
        ),
        display: "hexbin",
        hexbin: { columns: 18 },
        regression: { method: "linear" },
        summary: true,
      },
      {
        ...scatter(
          "wine-volatile",
          "Volatile acidity and alcohol in each quality band",
          "volatile acidity",
          "alcohol",
          layout(0, 7, 8, 5),
          ["Volatile acidity (g/L)", "Alcohol (% vol)"],
          "Quality band",
          "wine-bands"
        ),
        regression: { method: "linear" },
        facet: {
          enabled: true,
          type: "wrap",
          rowVariable: "Quality band",
          columnCount: 3,
        },
      },
      {
        ...row(
          "wine-quality",
          "Filter by quality band",
          "Quality band",
          layout(8, 7, 4, 5),
          "wine-bands"
        ),
        minRowHeight: 28,
        maxRowHeight: 40,
      },
      table(
        "wine-records",
        "Wines in view",
        [
          "Quality band",
          "quality",
          "alcohol",
          "density",
          "volatile acidity",
          "fixed acidity",
          "pH",
        ],
        layout(0, 12, 12, 4)
      ),
    ],
    [categoricalScale("wine-bands", "Quality band", wineBands)]
  ),
  calculations: [
    {
      resultColumnName: "Quality band",
      expression: `if quality <= 5 then "${wineBands[0]}" else if quality == 6 then "${wineBands[1]}" else "${wineBands[2]}"`,
    },
  ],
};

/**
 * Six years of correspondence: one strip of monthly squares per
 * correspondent, colored by a log ramp of messages, beside linked views of
 * the same rows.
 */
export const messageDashboard = dashboard("Message log", [
  {
    ...base,
    id: "messages-composition",
    type: "composition",
    title: "Report graphic",
    layout: layout(0, 0, 12, 7),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 960, height: 520, background: "#ffffff" },
      scales: [
        {
          id: "x-1",
          kind: "position",
          name: "Date by month",
          field: "Date",
          interval: "month",
          domain: "shared",
        },
        {
          id: "value-1",
          kind: "value",
          name: "Messages a month",
          domain: "shared",
          transform: "log",
          colors: ["#f4e9df", "#a3241d"],
        },
      ],
      calculations: [
        {
          id: "calc-1",
          name: "Messages",
          aggregation: "count",
          population: "repeat",
          filters: "follow",
        },
      ],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "Six years of correspondence",
          x: 32,
          y: 28,
          width: 896,
          fontSize: 26,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "One square per month for each of twelve correspondents, darker for more messages sent or received. Rows run from the busiest correspondent down.",
          x: 32,
          y: 64,
          width: 896,
          fontSize: 15,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "legend-1",
          kind: "legend",
          name: "Messages key",
          x: 192,
          y: 132,
          unitId: "unit-1",
          markId: "mark-1",
          scaleId: "value-1",
          direction: "row",
          fontSize: 11,
          color: "#1f2328",
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "Correspondents",
          x: 32,
          y: 176,
          frame: { width: 736, height: 18 },
          label: {
            show: true,
            width: 160,
            fontSize: 12,
            valueCalcId: "calc-1",
          },
          axis: true,
          marks: [
            {
              type: "strip",
              id: "mark-1",
              name: "Months",
              shape: "rect",
              positionScaleId: "x-1",
              valueScaleId: "value-1",
              aggregation: "count",
              encoding: "color",
              fill: "#3b6ea8",
              inset: 1,
            },
          ],
          repeat: {
            field: "Correspondent",
            arrangement: "rows",
            columns: 3,
            gap: 6,
            order: "count",
            limit: 24,
          },
        },
        {
          id: "note-1",
          kind: "annotation",
          name: "Busiest month",
          text: "Busiest month: {label}, {value} messages",
          x: 14,
          y: -24,
          anchor: {
            kind: "data",
            unitId: "unit-1",
            instanceKey: "Avery Lin",
            markId: "mark-1",
            pick: "max",
          },
          fontSize: 12,
          color: "#a3241d",
          leader: true,
        },
        {
          id: "note-2",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Illustrative message log generated for this demo: 10,376 messages, January 2019 to December 2024. The count beside each name follows the active filters.",
          x: 32,
          y: 488,
          width: 896,
          fontSize: 11,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  {
    ...line(
      "messages-monthly",
      "Messages per month",
      [],
      layout(0, 7, 8, 4),
      "Messages"
    ),
    xField: "Date",
    xAxisLabel: "Month · UTC",
    time: {
      interval: "month",
      weekStart: "monday",
      aggregation: "count",
      missingPeriods: "zero",
    },
  },
  row(
    "messages-direction",
    "Sent or received",
    "Direction",
    layout(8, 7, 4, 4)
  ),
  row(
    "messages-correspondents",
    "Messages by correspondent",
    "Correspondent",
    layout(0, 11, 4, 6)
  ),
  histogram(
    "messages-words",
    "Words per message",
    "Words",
    layout(4, 11, 3, 6)
  ),
]);

/**
 * Driving shifts into reverse: a connected scatterplot. The composition's
 * path orders 55 shuffled rows by Year through numeric Miles and Gas scales,
 * with labeled points, a calculated guide, and callouts that follow years.
 */
export const drivingDashboard = dashboard("Driving", [
  {
    ...base,
    id: "driving-composition",
    type: "composition",
    title: "Driving shifts into reverse",
    layout: layout(0, 0, 12, 8),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 960, height: 600, background: "#ffffff" },
      scales: [
        {
          id: "n-1",
          kind: "numeric",
          name: "Miles driven per person",
          field: "Miles",
          domain: "shared",
          zero: false,
          nice: true,
        },
        {
          id: "n-2",
          kind: "numeric",
          name: "Gas price",
          field: "Gas",
          domain: "shared",
          zero: false,
          nice: true,
        },
      ],
      calculations: [
        {
          id: "calc-1",
          name: "Average miles",
          aggregation: "average",
          field: "Miles",
          population: "composition",
          filters: "ignore",
        },
      ],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "Driving shifts into reverse",
          x: 32,
          y: 28,
          width: 896,
          fontSize: 26,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "Miles driven per person each year against the inflation-adjusted price of a gallon of gas, 1956–2010. The line follows the years.",
          x: 32,
          y: 64,
          width: 896,
          fontSize: 15,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "Years",
          x: 96,
          y: 112,
          frame: { width: 824, height: 400 },
          label: { show: false, width: 0, fontSize: 12 },
          axis: true,
          axisTitles: {
            x: "Miles driven per person each year",
            y: "Gas price, dollars a gallon",
          },
          marks: [
            {
              type: "path",
              id: "mark-1",
              name: "Path",
              xScaleId: "n-1",
              yScaleId: "n-2",
              orderField: "Year",
              stroke: "#1f2328",
              strokeWidth: 1.5,
            },
            {
              type: "point",
              id: "mark-2",
              name: "Points",
              xScaleId: "n-1",
              yScaleId: "n-2",
              orderField: "Year",
              radius: 3.5,
              fill: "#1f2328",
              labelField: "Year",
              labelEvery: 4,
            },
          ],
          repeat: {
            arrangement: "rows",
            columns: 3,
            gap: 6,
            order: "count",
            limit: 24,
          },
        },
        {
          id: "guide-1",
          kind: "guide",
          name: "Average miles",
          x: 6,
          y: -40,
          unitId: "unit-1",
          value: { kind: "calc", calcId: "calc-1" },
          label: "Average {value} miles a year",
          color: "#8a6d3b",
        },
        {
          id: "note-1",
          kind: "annotation",
          name: "2008 peak",
          text: "{label}: gas peaks at ${y} a gallon\nand driving falls for the first time",
          x: -230,
          y: -34,
          anchor: {
            kind: "data",
            unitId: "unit-1",
            instanceKey: "all",
            markId: "mark-2",
            pick: "at",
            at: "2008",
          },
          fontSize: 12,
          color: "#a3241d",
          leader: true,
        },
        {
          id: "note-2",
          kind: "annotation",
          name: "1980 shock",
          text: "{label}: the oil shock sends gas to ${y}\nwhile miles stall",
          x: 22,
          y: 18,
          anchor: {
            kind: "data",
            unitId: "unit-1",
            instanceKey: "all",
            markId: "mark-2",
            pick: "at",
            at: "1980",
          },
          fontSize: 12,
          color: "#1f4e8c",
          leader: true,
        },
        {
          id: "note-3",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Source: vega-datasets driving.json, after Hannah Fairfield, The New York Times (2010). Miles per person from the FHWA; gas price per gallon from the EIA, adjusted for inflation.",
          x: 32,
          y: 566,
          width: 896,
          fontSize: 11,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  scatter(
    "driving-scatter",
    "Gas against miles",
    "Miles",
    "Gas",
    layout(0, 8, 6, 5),
    ["Miles per person", "Gas, $ per gallon"]
  ),
  histogram("driving-years", "Years", "Year", layout(6, 8, 6, 5)),
]);

/**
 * Big-tech sparklines: a table of 14 company rows, each a path through its
 * opening prices with the low, high, and latest prices marked. Rows order by
 * a first-to-last change calculation, which also prints beside each name.
 */
export const sparklinesDashboard = dashboard("Big tech", [
  {
    ...base,
    id: "sparklines-composition",
    type: "composition",
    title: "Big-tech opening prices",
    layout: layout(0, 0, 12, 9),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 760, height: 780, background: "#ffffff" },
      scales: [
        {
          id: "n-1",
          kind: "numeric",
          name: "Date",
          field: "Date",
          domain: "shared",
          zero: false,
          nice: false,
          ticks: "ends",
        },
        {
          id: "n-2",
          kind: "numeric",
          name: "Opening price",
          field: "Open",
          domain: "instance",
          zero: false,
          nice: true,
          ticks: "none",
        },
      ],
      calculations: [
        {
          id: "calc-1",
          name: "Change",
          aggregation: "change",
          field: "Open",
          orderField: "Date",
          population: "repeat",
          filters: "ignore",
        },
      ],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "Big-tech opening prices, 2010–2023",
          x: 32,
          y: 28,
          width: 696,
          fontSize: 24,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "Each panel follows one company's opening price on its own dollar scale, so every shape shows; the label gives the change from the first day to the last. Panels run from the smallest change to the largest; purple marks the low, green the high, black the latest.",
          x: 32,
          y: 62,
          width: 696,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "Companies",
          x: 52,
          y: 124,
          frame: { width: 190, height: 50 },
          label: {
            show: true,
            width: 0,
            fontSize: 11,
            valueCalcId: "calc-1",
          },
          axis: true,
          marks: [
            {
              type: "path",
              id: "mark-1",
              name: "Price line",
              xScaleId: "n-1",
              yScaleId: "n-2",
              orderField: "Date",
              stroke: "#1f2328",
              strokeWidth: 1.25,
            },
            {
              type: "point",
              id: "mark-2",
              name: "Low",
              xScaleId: "n-1",
              yScaleId: "n-2",
              orderField: "Date",
              radius: 3,
              fill: "#7b4ea3",
              labelField: "Open",
              labelEvery: 1,
              show: "min",
            },
            {
              type: "point",
              id: "mark-3",
              name: "High",
              xScaleId: "n-1",
              yScaleId: "n-2",
              orderField: "Date",
              radius: 3,
              fill: "#2f8f5b",
              labelField: "Open",
              labelEvery: 1,
              show: "max",
            },
            {
              type: "point",
              id: "mark-4",
              name: "Latest",
              xScaleId: "n-1",
              yScaleId: "n-2",
              orderField: "Date",
              radius: 2.5,
              fill: "#1f2328",
              labelEvery: 0,
              show: "last",
            },
          ],
          repeat: {
            field: "Company",
            arrangement: "grid",
            columns: 3,
            gap: 44,
            order: "value",
            orderCalcId: "calc-1",
            direction: "asc",
            limit: 24,
          },
        },
        {
          id: "note-2",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Source: TidyTuesday 2023-02-07, big tech stock prices (Yahoo Finance via Kaggle). Every fifth trading day plus each company's first and last day. After Albert Rapp's gt sparkline table.",
          x: 32,
          y: 744,
          width: 696,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  {
    ...line(
      "sparklines-prices",
      "Opening price by date",
      ["Open"],
      layout(0, 9, 8, 5),
      "Open, $"
    ),
    xField: "Date",
    xAxisLabel: "Date",
    time: {
      interval: "month",
      weekStart: "monday",
      aggregation: "average",
      measureField: "Open",
      missingPeriods: "gap",
    },
  },
  row("sparklines-companies", "Rows by company", "Company", layout(8, 9, 4, 5)),
]);

const fanBand = (
  id: string,
  name: string,
  lowerField: string,
  upperField: string,
  opacity: number
) => ({
  type: "band" as const,
  id,
  name,
  xScaleId: "n-1",
  yScaleId: "n-2",
  orderField: "Year",
  lowerField,
  upperField,
  fill: "#1f4e8c",
  opacity,
});

/**
 * Forecast fan: two measure panels, each with four nested percentile bands
 * from supplied interval columns, a central path, a shaded projection
 * period, and a horizontal reference guide. Illustrative data.
 */
export const fanDashboard = dashboard("Forecast fan", [
  {
    ...base,
    id: "fan-composition",
    type: "composition",
    title: "Forecast fan",
    layout: layout(0, 0, 12, 7),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 960, height: 540, background: "#ffffff" },
      scales: [
        {
          id: "n-1",
          kind: "numeric",
          name: "Year",
          field: "Year",
          domain: "shared",
          zero: false,
          nice: false,
        },
        {
          id: "n-2",
          kind: "numeric",
          name: "Percent",
          field: "Central",
          domain: "instance",
          zero: true,
          nice: true,
        },
      ],
      calculations: [
        {
          id: "calc-1",
          name: "Latest central",
          aggregation: "last",
          field: "Central",
          orderField: "Year",
          population: "repeat",
          filters: "follow",
        },
      ],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "Two measures, three years ahead",
          x: 32,
          y: 28,
          width: 896,
          fontSize: 24,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "Quarterly history, then projections from 2025 with 20%, 40%, 60%, and 80% intervals around the central path. Illustrative figures; each panel keeps its own scale.",
          x: 32,
          y: 62,
          width: 896,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "Measures",
          x: 72,
          y: 110,
          frame: { width: 380, height: 300 },
          label: { show: true, width: 0, fontSize: 13, valueCalcId: "calc-1" },
          axis: true,
          marks: [
            fanBand("mark-1", "80% interval", "P10", "P90", 0.12),
            fanBand("mark-2", "60% interval", "P20", "P80", 0.16),
            fanBand("mark-3", "40% interval", "P30", "P70", 0.2),
            fanBand("mark-4", "20% interval", "P40", "P60", 0.26),
            {
              type: "path",
              id: "mark-5",
              name: "Central",
              xScaleId: "n-1",
              yScaleId: "n-2",
              orderField: "Year",
              stroke: "#1f2328",
              strokeWidth: 1.5,
            },
          ],
          repeat: {
            field: "Measure",
            arrangement: "columns",
            columns: 2,
            gap: 72,
            order: "label",
            limit: 24,
          },
        },
        {
          id: "guide-1",
          kind: "guide",
          name: "Projection",
          x: 4,
          y: -318,
          unitId: "unit-1",
          value: { kind: "constant", value: "2025" },
          label: "Projection",
          color: "#8a6d3b",
          shade: "after",
        },
        {
          id: "guide-2",
          kind: "guide",
          name: "2% reference",
          x: 4,
          y: 0,
          unitId: "unit-1",
          value: { kind: "constant", value: "2" },
          label: "2%",
          color: "#a3241d",
          axis: "y",
          repeats: "GDP growth",
        },
        {
          id: "legend-1",
          kind: "legend",
          name: "Interval key",
          x: 72,
          y: 446,
          unitId: "unit-1",
          markId: "mark-1",
          direction: "row",
          fontSize: 11,
          color: "#1f2328",
          items: [
            { markId: "mark-5", label: "Central path" },
            { markId: "mark-4", label: "20% of outcomes (P40–P60)" },
            { markId: "mark-3", label: "40% (P30–P70)" },
            { markId: "mark-2", label: "60% (P20–P80)" },
            { markId: "mark-1", label: "80% (P10–P90)" },
          ],
        },
        {
          id: "note-2",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Illustrative data generated for this demo: supplied percentile columns, not a forecast model. The layout follows central-bank fan charts.",
          x: 32,
          y: 506,
          width: 896,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  {
    ...line(
      "fan-central",
      "Central path by quarter",
      ["Central"],
      layout(0, 7, 8, 5),
      "Percent"
    ),
    xField: "Year",
    xAxisLabel: "Year",
  },
  row("fan-kind", "History or projection", "Kind", layout(8, 7, 4, 5)),
]);

/**
 * Time use, 2019 against 2020: a grid of activities. In each, a summary
 * mark draws the quartiles of minutes per day for the two cohorts as a
 * joined band, marks the medians, and colors them by the change in median
 * through a diverging scale.
 */
export const timeUseDashboard = dashboard("Time use", [
  {
    ...base,
    id: "time-use-composition",
    type: "composition",
    title: "How the day changed",
    layout: layout(0, 0, 12, 8),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 960, height: 640, background: "#ffffff" },
      scales: [
        {
          id: "n-1",
          kind: "numeric",
          name: "Minutes a day",
          field: "Minutes",
          domain: "instance",
          zero: false,
          nice: true,
        },
        {
          id: "value-1",
          kind: "value",
          name: "Change in median",
          domain: "shared",
          transform: "sqrt",
          colors: ["#2b6cb0", "#c2410c"],
          center: "#b8bcc2",
        },
      ],
      calculations: [
        {
          id: "calc-1",
          name: "Diary entries",
          aggregation: "count",
          population: "repeat",
          filters: "follow",
        },
      ],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "How the day changed in 2020",
          x: 32,
          y: 26,
          width: 896,
          fontSize: 24,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "Minutes a day for people who did each activity: the band spans the middle half of respondents, the dot marks the median, 2019 then 2020. Orange rose, blue fell; each panel keeps its own minute scale.",
          x: 32,
          y: 58,
          width: 896,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "Activities",
          x: 56,
          y: 112,
          frame: { width: 124, height: 88 },
          label: { show: true, width: 0, fontSize: 12, valueCalcId: "calc-1" },
          axis: true,
          marks: [
            {
              type: "summary",
              id: "mark-1",
              name: "Minutes a day",
              groupField: "Year",
              measureField: "Minutes",
              yScaleId: "n-1",
              valueScaleId: "value-1",
              fill: "#d9dde3",
              opacity: 0.7,
            },
          ],
          repeat: {
            field: "Activity",
            arrangement: "grid",
            columns: 4,
            gap: 40,
            order: "label",
            limit: 24,
          },
        },
        {
          id: "legend-1",
          kind: "legend",
          name: "How to read",
          x: 736,
          y: 132,
          unitId: "unit-1",
          markId: "mark-1",
          direction: "column",
          fontSize: 11,
          color: "#1f2328",
          items: [
            {
              markId: "mark-1",
              part: "band",
              label: "Middle half: 25th to 75th percentile",
            },
            {
              markId: "mark-1",
              part: "median",
              label: "Median, 2019 then 2020",
            },
          ],
        },
        {
          id: "legend-2",
          kind: "legend",
          name: "Change key",
          x: 736,
          y: 214,
          unitId: "unit-1",
          markId: "mark-1",
          scaleId: "value-1",
          direction: "row",
          fontSize: 11,
          color: "#1f2328",
        },
        {
          id: "note-1",
          kind: "annotation",
          name: "Reading note",
          text: "Each label counts that activity's diary entries after the active filters. Respondents who skipped an activity have no entry.",
          x: 56,
          y: 586,
          anchor: { kind: "page" },
          fontSize: 11,
          color: "#5f6368",
          leader: false,
        },
        {
          id: "note-2",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Illustrative diary generated for this demo: 400 respondents a year, unweighted quartiles, not survey estimates. After Nathan Yau's time-use comparison.",
          x: 32,
          y: 612,
          width: 896,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  box(
    "time-use-box",
    "Minutes by year",
    "Minutes",
    "Year",
    layout(0, 8, 6, 5),
    undefined,
    "Minutes a day"
  ),
  row("time-use-age", "Age group", "Age group", layout(6, 8, 3, 5)),
  row("time-use-weekday", "Day", "Weekday", layout(9, 8, 3, 5)),
]);

/**
 * Deaths against media coverage: four normalized columns. Each stacks the
 * fifteen causes as shares of that source's total, in one order and color
 * across the columns, so the mortality column reads against the three
 * outlets. Real 2023 figures from Our World in Data.
 */
export const mediaDeathsDashboard = dashboard("Media and deaths", [
  {
    ...base,
    id: "media-deaths-composition",
    type: "composition",
    title: "What Americans die from, and what the news covers",
    layout: layout(0, 0, 12, 9),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 960, height: 720, background: "#ffffff" },
      scales: [],
      calculations: [
        {
          id: "calc-1",
          name: "Total",
          aggregation: "sum",
          field: "Count",
          population: "repeat",
          filters: "follow",
        },
      ],
      overrides: [
        {
          unitId: "unit-1",
          instanceKey: "Deaths",
          dx: -40,
          dy: 0,
          emphasize: true,
        },
      ],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "What Americans die from, and what the news covers",
          x: 32,
          y: 26,
          width: 896,
          fontSize: 24,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "Each column stacks fifteen causes of death as shares of its own total: deaths in 2023 on the left, then articles that discussed each cause in three outlets. Homicide and terrorism fill the news; heart disease and cancer fill the death certificates.",
          x: 32,
          y: 58,
          width: 896,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "Sources",
          x: 108,
          y: 128,
          frame: { width: 150, height: 500 },
          label: { show: true, width: 0, fontSize: 12, valueCalcId: "calc-1" },
          axis: true,
          marks: [
            {
              type: "stack",
              id: "mark-1",
              name: "Share of total",
              categoryField: "Cause",
              aggregation: "sum",
              measureField: "Count",
              normalize: true,
              order: "total",
              colors: [
                "#4e79a7",
                "#f28e2b",
                "#e15759",
                "#76b7b2",
                "#59a14f",
                "#edc948",
                "#b07aa1",
                "#ff9da7",
                "#9c755f",
                "#bab0ac",
                "#1f77b4",
                "#8c564b",
                "#17becf",
                "#bcbd22",
                "#7f7f7f",
              ],
              labelMinHeight: 13,
              inset: 1.5,
            },
          ],
          repeat: {
            field: "Source",
            arrangement: "columns",
            columns: 4,
            gap: 56,
            order: "label",
            limit: 24,
          },
        },
        {
          id: "note-1",
          kind: "annotation",
          name: "Denominators",
          text: "Deaths are deaths from these fifteen causes, not all deaths. Articles count pieces that mention a cause several times, not every story.",
          x: 120,
          y: 652,
          anchor: { kind: "page" },
          fontSize: 11,
          color: "#5f6368",
          leader: false,
        },
        {
          id: "note-2",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Source: Our World in Data, media deaths analysis (CC BY). Deaths from the CDC; articles from Media Cloud, 2023. Accidents exclude drug overdoses. After the Our World in Data graphic.",
          x: 32,
          y: 692,
          width: 896,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  row("media-deaths-causes", "Rows by cause", "Cause", layout(0, 9, 6, 6)),
  row("media-deaths-sources", "Rows by source", "Source", layout(6, 9, 6, 6)),
]);

/**
 * Measles before and after the vaccine: 51 state strips in the publisher's
 * order, one cell per year colored by a placed multistop ramp, with not
 * reported years drawn as neutral cells and a fixed 1963 guide.
 */
export const measlesDashboard = dashboard("Measles", [
  {
    ...base,
    id: "measles-composition",
    type: "composition",
    title: "Measles",
    layout: layout(0, 0, 12, 9),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 900, height: 806, background: "#ffffff" },
      scales: [
        {
          id: "x-1",
          kind: "position",
          name: "Year",
          field: "Year",
          domain: "shared",
        },
        {
          id: "value-1",
          kind: "value",
          name: "Cases per 100,000",
          domain: "shared",
          transform: "linear",
          colors: [
            "#e7f0fa",
            "#c9e2f6",
            "#95cbee",
            "#0099dc",
            "#4ab04a",
            "#ffd73e",
            "#eec73a",
            "#e29421",
            "#e29421",
            "#f05336",
            "#ce472e",
          ],
          stops: [0, 0.01, 0.02, 0.03, 0.09, 0.1, 0.15, 0.25, 0.4, 0.5, 1],
        },
      ],
      calculations: [
        {
          id: "calc-1",
          name: "Row order",
          aggregation: "max",
          field: "Order",
          population: "repeat",
          filters: "ignore",
        },
      ],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "Measles",
          x: 32,
          y: 24,
          width: 836,
          fontSize: 24,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "Reported cases per 100,000 people, by state and year. Grey cells are years a state did not report. The ramp climbs quickly: pale blue is under 30 cases, green about 270, and red 1,500 and above.",
          x: 32,
          y: 56,
          width: 836,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "States",
          x: 32,
          y: 150,
          frame: { width: 776, height: 10 },
          label: { show: true, width: 60, fontSize: 9 },
          axis: true,
          marks: [
            {
              type: "strip",
              id: "mark-1",
              name: "Cells",
              shape: "rect",
              positionScaleId: "x-1",
              valueScaleId: "value-1",
              aggregation: "average",
              measureField: "Rate",
              encoding: "color",
              fill: "#1f2328",
              inset: 1,
              missing: "#e6e8eb",
            },
          ],
          repeat: {
            field: "Label",
            arrangement: "rows",
            columns: 1,
            gap: 1,
            order: "value",
            orderCalcId: "calc-1",
            direction: "asc",
            limit: 60,
          },
        },
        {
          id: "legend-1",
          kind: "legend",
          name: "Rate key",
          x: 92,
          y: 112,
          unitId: "unit-1",
          markId: "mark-1",
          scaleId: "value-1",
          direction: "row",
          fontSize: 10,
          color: "#1f2328",
        },
        {
          id: "legend-2",
          kind: "legend",
          name: "Missing key",
          x: 300,
          y: 113,
          unitId: "unit-1",
          markId: "mark-1",
          direction: "row",
          fontSize: 10,
          color: "#1f2328",
          items: [{ markId: "mark-1", part: "missing", label: "Not reported" }],
        },
        {
          id: "guide-1",
          kind: "guide",
          name: "Vaccine",
          x: 4,
          y: -610,
          unitId: "unit-1",
          value: { kind: "constant", value: "1963" },
          label: "Vaccine introduced",
          color: "#1f2328",
        },
        {
          id: "note-1",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Source: The Wall Street Journal, Battling Infectious Diseases in the 20th Century (2015), from Project Tycho and CDC data. CDC data from 2003 to 2012 counts confirmed cases yearly rather than provisional cases weekly. Alaska's 2003 cell has no record and stays blank.",
          x: 32,
          y: 768,
          width: 836,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  {
    ...line(
      "measles-years",
      "Average rate by year",
      ["Rate"],
      layout(0, 9, 8, 5),
      "Cases per 100,000"
    ),
    xField: "Year",
    xAxisLabel: "Year",
  },
  row("measles-status", "Cell status", "Status", layout(8, 9, 4, 5)),
]);

/**
 * Causes of death by age: one stack spread across age. Each cause draws as
 * an area of its share of that age's total, labeled where it is thickest.
 * Illustrative counts.
 */
export const causesByAgeDashboard = dashboard("Causes by age", [
  {
    ...base,
    id: "causes-composition",
    type: "composition",
    title: "What people die from, by age",
    layout: layout(0, 0, 12, 8),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 960, height: 600, background: "#ffffff" },
      scales: [
        {
          id: "n-1",
          kind: "numeric",
          name: "Age",
          field: "Age",
          domain: "shared",
          zero: true,
          nice: false,
        },
      ],
      calculations: [
        {
          id: "calc-1",
          name: "Deaths",
          aggregation: "sum",
          field: "Count",
          population: "composition",
          filters: "follow",
        },
      ],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "What people die from, by age",
          x: 32,
          y: 26,
          width: 896,
          fontSize: 24,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "Each band is one cause's share of deaths at that age, from birth to 100. Shares at every age add to 100%; {Deaths} deaths in all after the active filters.",
          x: 32,
          y: 58,
          width: 896,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "Ages",
          x: 72,
          y: 110,
          frame: { width: 848, height: 400 },
          label: { show: false, width: 0, fontSize: 12 },
          axis: true,
          axisTitles: { x: "Age", y: "Share of deaths" },
          marks: [
            {
              type: "stack",
              id: "mark-1",
              name: "Share of deaths",
              categoryField: "Cause",
              aggregation: "sum",
              measureField: "Count",
              normalize: true,
              order: "total",
              colors: [
                "#4e79a7",
                "#f28e2b",
                "#76b7b2",
                "#e15759",
                "#59a14f",
                "#edc948",
                "#b07aa1",
                "#9c755f",
                "#bab0ac",
              ],
              labelMinHeight: 14,
              inset: 0,
              xScaleId: "n-1",
            },
          ],
          repeat: {
            arrangement: "rows",
            columns: 1,
            gap: 0,
            order: "label",
            limit: 1,
          },
        },
        {
          id: "guide-1",
          kind: "guide",
          name: "Retirement",
          x: -4,
          y: -436,
          unitId: "unit-1",
          value: { kind: "constant", value: "65" },
          label: "Retirement age, 65",
          color: "#1f2328",
        },
        {
          id: "note-1",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Illustrative counts generated for this demo; they describe no real population. After Nathan Yau's Causes of Death.",
          x: 32,
          y: 566,
          width: 896,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  row("causes-list", "Rows by cause", "Cause", layout(0, 8, 4, 6)),
  histogram("causes-ages", "Ages", "Age", layout(4, 8, 8, 6)),
]);

/**
 * Consumer confidence around the world: a 3 × 3 grid. Every panel draws all
 * nine countries' paths on one shared scale and lights up its own, with the
 * latest value marked and labeled and a 100 reference line.
 */
export const consumerConfidenceDashboard = dashboard("Consumer confidence", [
  {
    ...base,
    id: "confidence-composition",
    type: "composition",
    title: "Consumer confidence around the world",
    layout: layout(0, 0, 12, 11),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 960, height: 870, background: "#ffffff" },
      scales: [
        {
          id: "n-1",
          kind: "numeric",
          name: "Month",
          field: "Month",
          domain: "shared",
          zero: false,
          nice: false,
        },
        {
          id: "n-2",
          kind: "numeric",
          name: "Index",
          field: "Index",
          domain: "shared",
          zero: false,
          nice: true,
        },
      ],
      calculations: [
        {
          id: "calc-1",
          name: "Latest",
          aggregation: "last",
          field: "Index",
          orderField: "Month",
          population: "repeat",
          filters: "follow",
        },
      ],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "Consumer confidence around the world",
          x: 32,
          y: 26,
          width: 896,
          fontSize: 24,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "OECD consumer confidence index, monthly from July 2018 to October 2022. Each panel shows all nine countries in grey and its own in color; 100 is the long-run average.",
          x: 32,
          y: 58,
          width: 896,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "Countries",
          x: 72,
          y: 132,
          frame: { width: 236, height: 150 },
          label: { show: true, width: 0, fontSize: 13, valueCalcId: "calc-1" },
          axis: true,
          marks: [
            {
              type: "path",
              id: "mark-1",
              name: "Index",
              xScaleId: "n-1",
              yScaleId: "n-2",
              orderField: "Month",
              stroke: "#c2410c",
              strokeWidth: 1.75,
              seriesField: "Country",
              focus: { kind: "repeat" },
              mutedStroke: "#d4d7dc",
              population: "composition",
            },
            {
              type: "point",
              id: "mark-2",
              name: "Latest",
              xScaleId: "n-1",
              yScaleId: "n-2",
              orderField: "Month",
              radius: 3,
              fill: "#c2410c",
              labelEvery: 0,
              show: "last",
              seriesField: "Country",
              focus: { kind: "repeat" },
              mutedFill: "#d4d7dc",
              population: "composition",
            },
          ],
          repeat: {
            field: "Country",
            arrangement: "grid",
            columns: 3,
            gap: 56,
            order: "label",
            limit: 9,
          },
        },
        {
          id: "legend-1",
          kind: "legend",
          name: "Line key",
          x: 72,
          y: 96,
          unitId: "unit-1",
          markId: "mark-1",
          direction: "row",
          fontSize: 11,
          color: "#1f2328",
          items: [
            { markId: "mark-1", label: "The panel's country" },
            { markId: "mark-1", part: "muted", label: "The other eight" },
            { markId: "mark-2", label: "Latest reading" },
          ],
        },
        {
          id: "guide-1",
          kind: "guide",
          name: "Average",
          x: 4,
          y: 0,
          unitId: "unit-1",
          value: { kind: "constant", value: "100" },
          label: "",
          color: "#8a8f98",
          axis: "y",
        },
        {
          id: "note-1",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Source: OECD consumer confidence indicator, via the R Graph Gallery's data file. Each panel's label shows its latest index after the active filters. After the Economist's small-multiples grid.",
          x: 32,
          y: 832,
          width: 896,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  {
    ...line(
      "confidence-line",
      "Average index by month",
      ["Index"],
      layout(0, 11, 8, 5),
      "Index"
    ),
    xField: "Month",
    xAxisLabel: "Month",
    time: {
      interval: "month",
      weekStart: "monday",
      aggregation: "average",
      measureField: "Index",
      missingPeriods: "gap",
    },
  },
  row(
    "confidence-countries",
    "Rows by country",
    "Country",
    layout(8, 11, 4, 5)
  ),
]);

/**
 * Pew's dumbbell: one topic per row, the two parties' shares as colored dots
 * on a shared percentage scale with a connector, a legend above, and the
 * signed gap beside each row.
 */
export const pewMeaningDashboard = dashboard("Life's meaning by party", [
  {
    ...base,
    id: "pew-composition",
    type: "composition",
    title: "Republicans and Democrats differ over what makes life meaningful",
    layout: layout(0, 0, 12, 7),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 840, height: 560, background: "#ffffff" },
      scales: [
        {
          id: "n-1",
          kind: "numeric",
          name: "Share",
          field: "Share",
          domain: "shared",
          zero: true,
          nice: true,
        },
      ],
      calculations: [
        {
          id: "calc-1",
          name: "Rep minus Dem",
          aggregation: "difference",
          field: "Share",
          orderField: "Party",
          population: "repeat",
          filters: "follow",
        },
        {
          id: "calc-2",
          name: "Row order",
          aggregation: "max",
          field: "Order",
          population: "repeat",
          filters: "ignore",
        },
      ],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "Republicans and Democrats in the U.S. differ over some factors that make life meaningful",
          x: 32,
          y: 24,
          width: 776,
          fontSize: 20,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "% of U.S. adults who mention each topic when describing what gives them meaning in life, by party. The difference at the right names the party that mentions it more, by how many points.",
          x: 32,
          y: 82,
          width: 776,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "legend-1",
          kind: "legend",
          name: "Party key",
          x: 300,
          y: 134,
          unitId: "unit-1",
          markId: "mark-2",
          direction: "row",
          fontSize: 12,
          color: "#1f2328",
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "Topics",
          x: 32,
          y: 166,
          frame: { width: 420, height: 30 },
          label: {
            show: true,
            width: 268,
            fontSize: 13,
            valueCalcId: "calc-1",
            valueSigns: {
              positive: { prefix: "+", suffix: "R", color: "#bf2f24" },
              negative: { prefix: "+", suffix: "D", color: "#436685" },
            },
            valueColumn: { width: 64, header: "Diff", fill: "#efeadf" },
          },
          axis: true,
          marks: [
            {
              type: "path",
              id: "mark-1",
              name: "Gap",
              xScaleId: "n-1",
              orderField: "Party",
              stroke: "#d4d7dc",
              strokeWidth: 4,
            },
            {
              type: "point",
              id: "mark-2",
              name: "Parties",
              xScaleId: "n-1",
              orderField: "Party",
              radius: 7,
              fill: "#1f2328",
              labelField: "Share",
              labelEvery: 1,
              colorField: "Party",
              colors: ["#436685", "#bf2f24"],
            },
          ],
          repeat: {
            field: "Topic",
            arrangement: "rows",
            columns: 1,
            gap: 14,
            order: "value",
            orderCalcId: "calc-2",
            direction: "asc",
            limit: 10,
          },
        },
        {
          id: "note-1",
          kind: "text",
          role: "note",
          name: "Note",
          text: 'Source: Pew Research Center, "What makes life meaningful? Views from 17 advanced economies" (November 2021), U.S. survey. Figures as transcribed in the R Graph Gallery\'s recreation.',
          x: 32,
          y: 524,
          width: 776,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  row("pew-topics", "Rows by topic", "Topic", layout(0, 7, 6, 5)),
  row("pew-parties", "Rows by party", "Party", layout(6, 7, 6, 5)),
]);

/**
 * Income against life expectancy: one annotated scatter. Points sit on a log
 * income scale, size by population, color by region, and a few chosen
 * economies carry labels; a legend keys the regions.
 */
export const incomeLifeDashboard = dashboard("Income and life", [
  {
    ...base,
    id: "income-life-composition",
    type: "composition",
    title: "Richer countries live longer",
    layout: layout(0, 0, 12, 8),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 960, height: 620, background: "#ffffff" },
      scales: [
        {
          id: "n-1",
          kind: "numeric",
          name: "GDP per capita",
          field: "GDP per capita",
          domain: "shared",
          zero: false,
          nice: true,
          transform: "log",
        },
        {
          id: "n-2",
          kind: "numeric",
          name: "Life expectancy",
          field: "Life expectancy",
          domain: "shared",
          zero: false,
          nice: true,
        },
      ],
      calculations: [
        {
          id: "calc-1",
          name: "Economies",
          aggregation: "count",
          population: "composition",
          filters: "follow",
        },
      ],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "Richer countries live longer",
          x: 32,
          y: 26,
          width: 896,
          fontSize: 24,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "Life expectancy at birth against GDP per capita in 2023, for {Economies} economies. Each tenfold step in income takes the same room; circle area follows population.",
          x: 32,
          y: 58,
          width: 896,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "legend-1",
          kind: "legend",
          name: "Regions",
          x: 80,
          y: 96,
          unitId: "unit-1",
          markId: "mark-1",
          direction: "row",
          fontSize: 11,
          color: "#1f2328",
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "Economies",
          x: 80,
          y: 126,
          frame: { width: 840, height: 410 },
          label: { show: false, width: 0, fontSize: 12 },
          axis: true,
          marks: [
            {
              type: "point",
              id: "mark-1",
              name: "Economies",
              xScaleId: "n-1",
              yScaleId: "n-2",
              radius: 22,
              fill: "#4e79a7",
              labelField: "Country",
              labelEvery: 1,
              labelValues:
                "China, India, United States, Nigeria, Japan, Chad, Qatar, Brazil, Indonesia, Lesotho, Luxembourg, Afghanistan",
              sizeField: "Population",
              colorField: "Region",
              colors: [
                "#4e79a7",
                "#f28e2b",
                "#59a14f",
                "#e15759",
                "#76b7b2",
                "#b07aa1",
                "#edc948",
              ],
            },
          ],
          repeat: {
            arrangement: "rows",
            columns: 1,
            gap: 0,
            order: "label",
            limit: 1,
          },
        },
        {
          id: "note-1",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Source: World Bank World Development Indicators, 2023 vintage (CC BY 4.0): population and life expectancy from the UN Population Division, GDP per capita in PPP constant 2021 dollars. After Gapminder's income and health chart.",
          x: 32,
          y: 586,
          width: 896,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  row("income-life-regions", "Rows by region", "Region", layout(0, 8, 5, 5)),
  histogram(
    "income-life-expectancy",
    "Life expectancy",
    "Life expectancy",
    layout(5, 8, 7, 5)
  ),
]);

/**
 * Covid case rates on a tile-grid map: each state's seven-day average new
 * cases per 100,000 as a small path at its cell on the US tile grid, on one
 * shared scale, with the latest value in each label.
 */
export const covidTilesDashboard = dashboard("Covid tiles", [
  {
    ...base,
    id: "covid-tiles-composition",
    type: "composition",
    title: "Three years of Covid, state by state",
    layout: layout(0, 0, 12, 9),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 960, height: 700, background: "#ffffff" },
      scales: [
        {
          id: "n-1",
          kind: "numeric",
          name: "Week",
          field: "Date",
          domain: "shared",
          zero: false,
          nice: false,
        },
        {
          id: "n-2",
          kind: "numeric",
          name: "Cases per 100k",
          field: "Cases per 100k",
          domain: "shared",
          zero: true,
          nice: false,
        },
      ],
      calculations: [
        {
          id: "calc-1",
          name: "Peak",
          aggregation: "max",
          field: "Cases per 100k",
          population: "repeat",
          filters: "follow",
        },
      ],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "Three years of Covid, state by state",
          x: 32,
          y: 24,
          width: 896,
          fontSize: 24,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "Seven-day average of new cases per 100,000 people, weekly from March 2020 to March 2023, on one shared scale. Each state sits roughly where it is on the map; its label gives its worst week.",
          x: 32,
          y: 56,
          width: 896,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "States",
          x: 40,
          y: 110,
          frame: { width: 72, height: 40 },
          label: { show: true, width: 0, fontSize: 10, valueCalcId: "calc-1" },
          axis: false,
          marks: [
            {
              type: "path",
              id: "mark-1",
              name: "Cases",
              xScaleId: "n-1",
              yScaleId: "n-2",
              orderField: "Date",
              stroke: "#a3241d",
              strokeWidth: 1.25,
            },
            {
              type: "point",
              id: "mark-2",
              name: "Latest",
              xScaleId: "n-1",
              yScaleId: "n-2",
              orderField: "Date",
              radius: 2,
              fill: "#1f2328",
              labelEvery: 0,
              show: "last",
            },
          ],
          repeat: {
            field: "Code",
            arrangement: "tiles",
            tileField: "Tile",
            columns: 11,
            gap: 10,
            order: "label",
            limit: 60,
          },
        },
        {
          id: "note-1",
          kind: "annotation",
          name: "Omicron",
          text: "The January 2022 Omicron wave towers over every other peak in all 51 series.",
          x: 40,
          y: 650,
          anchor: { kind: "page" },
          fontSize: 11,
          color: "#5f6368",
          leader: false,
        },
        {
          id: "note-2",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Source: The New York Times, Covid-19 data in the United States (CC BY-NC 4.0), rolling averages, every seventh day. After the published tile-grid recreation.",
          x: 32,
          y: 672,
          width: 896,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  {
    ...line(
      "covid-tiles-line",
      "National average by week",
      ["Cases per 100k"],
      layout(0, 9, 8, 5),
      "Cases per 100k"
    ),
    xField: "Date",
    xAxisLabel: "Week",
    time: {
      interval: "week",
      weekStart: "monday",
      aggregation: "average",
      measureField: "Cases per 100k",
      missingPeriods: "gap",
    },
  },
  row("covid-tiles-states", "Rows by state", "State", layout(8, 9, 4, 5)),
]);

/**
 * State case rates against the nation: six panels. The main frame shows
 * the last nine months with the state in color and the national rate in
 * black; an inset shows the full three years for both. The US series sits
 * in the data as a comparison and is left out of the repeats.
 */
export const covidCompareDashboard = dashboard("Covid compare", [
  {
    ...base,
    id: "covid-compare-composition",
    type: "composition",
    title: "The last nine months, against three years",
    layout: layout(0, 0, 12, 9),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 960, height: 720, background: "#ffffff" },
      scales: [
        {
          id: "n-1",
          kind: "numeric",
          name: "Week",
          field: "Date",
          domain: "shared",
          zero: false,
          nice: false,
        },
        {
          id: "n-2",
          kind: "numeric",
          name: "Cases per 100k",
          field: "Cases per 100k",
          domain: "shared",
          zero: true,
          nice: true,
        },
        {
          id: "n-3",
          kind: "numeric",
          name: "Cases per 100k, all weeks",
          field: "Cases per 100k",
          domain: "shared",
          zero: true,
          nice: false,
        },
      ],
      calculations: [
        {
          id: "calc-1",
          name: "Latest",
          aggregation: "last",
          field: "Cases per 100k",
          orderField: "Date",
          population: "repeat",
          filters: "follow",
        },
      ],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "The last nine months, against three years",
          x: 32,
          y: 24,
          width: 896,
          fontSize: 24,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "Seven-day average new Covid cases per 100,000 people. Each panel's main frame shows July 2022 to March 2023, the state in color and the United States in black; the inset shows the whole series from March 2020 on its own scale.",
          x: 32,
          y: 56,
          width: 896,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "States",
          x: 72,
          y: 116,
          frame: { width: 250, height: 190 },
          label: { show: true, width: 0, fontSize: 13, valueCalcId: "calc-1" },
          axis: true,
          window: { field: "Date", min: "2022-07-04" },
          insets: [
            {
              id: "inset-1",
              name: "All weeks",
              x: 100,
              y: 8,
              width: 142,
              height: 70,
              axis: false,
              background: "#f6f7f9",
            },
          ],
          marks: [
            {
              type: "path",
              id: "mark-1",
              name: "State, recent",
              xScaleId: "n-1",
              yScaleId: "n-2",
              orderField: "Date",
              stroke: "#c2410c",
              strokeWidth: 2,
            },
            {
              type: "path",
              id: "mark-2",
              name: "Nation, recent",
              xScaleId: "n-1",
              yScaleId: "n-2",
              orderField: "Date",
              stroke: "#1f2328",
              strokeWidth: 1.25,
              seriesField: "Code",
              focus: { kind: "values", values: "US" },
              mutedStroke: "#ffffff00",
              population: "composition",
            },
            {
              type: "point",
              id: "mark-3",
              name: "Latest",
              xScaleId: "n-1",
              yScaleId: "n-2",
              orderField: "Date",
              radius: 3,
              fill: "#c2410c",
              labelEvery: 0,
              show: "last",
            },
            {
              type: "path",
              id: "mark-4",
              name: "State, all weeks",
              frameId: "inset-1",
              xScaleId: "n-1",
              yScaleId: "n-3",
              orderField: "Date",
              stroke: "#c2410c",
              strokeWidth: 1,
            },
            {
              type: "path",
              id: "mark-5",
              name: "Nation, all weeks",
              frameId: "inset-1",
              xScaleId: "n-1",
              yScaleId: "n-3",
              orderField: "Date",
              stroke: "#1f2328",
              strokeWidth: 0.75,
              seriesField: "Code",
              focus: { kind: "values", values: "US" },
              mutedStroke: "#ffffff00",
              population: "composition",
            },
          ],
          repeat: {
            field: "State",
            arrangement: "grid",
            columns: 3,
            gap: 52,
            order: "label",
            limit: 10,
            skip: "United States",
          },
        },
        {
          id: "note-1",
          kind: "annotation",
          name: "Reading note",
          text: "Main frames share one recent scale; insets share one full-history scale, where the January 2022 Omicron peak dwarfs the recent months.",
          x: 72,
          y: 662,
          anchor: { kind: "page" },
          fontSize: 11,
          color: "#5f6368",
          leader: false,
        },
        {
          id: "note-2",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Source: The New York Times, Covid-19 data in the United States (CC BY-NC 4.0), rolling averages for states and the nation, every seventh day. After The Washington Post's state comparison layout.",
          x: 32,
          y: 688,
          width: 896,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  {
    ...line(
      "covid-compare-line",
      "Average of the six states by week",
      ["Cases per 100k"],
      layout(0, 9, 8, 5),
      "Cases per 100k"
    ),
    xField: "Date",
    xAxisLabel: "Week",
    time: {
      interval: "week",
      weekStart: "monday",
      aggregation: "average",
      measureField: "Cases per 100k",
      missingPeriods: "gap",
    },
  },
  row("covid-compare-states", "Rows by state", "State", layout(8, 9, 4, 5)),
]);

/**
 * Presidential margins by state: 51 strips of 11 elections. Each cell's
 * color follows the signed Democratic margin through a diverging ramp;
 * rows order by the latest margin, and a legend keys the ramp.
 */
export const electionsDashboard = dashboard("Presidential margins", [
  {
    ...base,
    id: "elections-composition",
    type: "composition",
    title: "How each state voted, 1976 to 2016",
    layout: layout(0, 0, 12, 9),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 960, height: 660, background: "#ffffff" },
      scales: [
        {
          id: "x-1",
          kind: "position",
          name: "Election",
          field: "Year",
          domain: "shared",
        },
        {
          id: "value-1",
          kind: "value",
          name: "Democratic margin, points",
          domain: "shared",
          transform: "sqrt",
          colors: ["#c0392b", "#2b6cb0"],
          center: "#ece9e4",
          max: 40,
        },
      ],
      calculations: [],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "How each state voted, 1976 to 2016",
          x: 32,
          y: 24,
          width: 896,
          fontSize: 24,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "Each state's eleven presidential elections, from 1976 at the left to 2016 at the right, placed where the state sits on the map. Blue leans Democratic, red Republican; the deeper the color, the wider the margin.",
          x: 32,
          y: 56,
          width: 896,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "legend-1",
          kind: "legend",
          name: "Margin key",
          x: 44,
          y: 116,
          unitId: "unit-1",
          markId: "mark-1",
          scaleId: "value-1",
          direction: "row",
          fontSize: 10,
          color: "#1f2328",
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "States",
          x: 44,
          y: 156,
          frame: { width: 72, height: 30 },
          label: { show: true, width: 0, fontSize: 11 },
          axis: false,
          marks: [
            {
              type: "strip",
              id: "mark-1",
              name: "Cells",
              shape: "rect",
              positionScaleId: "x-1",
              valueScaleId: "value-1",
              aggregation: "average",
              measureField: "Margin",
              encoding: "color",
              fill: "#1f2328",
              inset: 0.5,
            },
          ],
          repeat: {
            field: "Code",
            arrangement: "tiles",
            tileField: "Tile",
            columns: 11,
            gap: 8,
            order: "label",
            limit: 60,
          },
        },
        {
          id: "note-1",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Source: MIT Election Data and Science Lab, U.S. President 1976–2020 state returns (CC0), 1976 to 2016. Margin is the Democratic share of all votes minus the Republican share. Tile positions follow the common US tile grid.",
          x: 32,
          y: 626,
          width: 896,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  row("elections-winner", "Rows by winner", "Winner", layout(0, 9, 4, 5)),
  histogram("elections-margin", "Margins", "Margin", layout(4, 9, 8, 5)),
]);

/**
 * Temperatures in Lincoln: a ridgeline. Each month's daily mean temperatures
 * become a density curve on one shared temperature scale; the rows overlap
 * through a negative gap, January at the top.
 */
/** A full year of daily readings, so the calendar shows seasons and runs. */
export const lincolnCalendarDashboard = dashboard("Lincoln calendar", [
  {
    ...base,
    id: "lincoln-calendar",
    type: "calendar",
    title: "Daily high temperature, °F",
    field: "Date",
    aggregation: "average",
    measureField: "Max temperature",
    weekStart: "monday",
    layout: layout(0, 0, 12, 4),
  },
]);

export const lincolnRidgelineDashboard = dashboard("Lincoln ridgeline", [
  {
    ...base,
    id: "lincoln-composition",
    type: "composition",
    title: "Temperatures in Lincoln, Nebraska, in 2016",
    layout: layout(0, 0, 12, 9),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 760, height: 746, background: "#ffffff" },
      scales: [
        {
          id: "n-1",
          kind: "numeric",
          name: "Mean temperature",
          field: "Mean temperature",
          domain: "shared",
          zero: false,
          nice: true,
        },
        {
          id: "value-1",
          kind: "value",
          name: "Temperature, °F",
          domain: "shared",
          transform: "linear",
          colors: [
            "#313695",
            "#4575b4",
            "#74add1",
            "#abd9e9",
            "#fee090",
            "#fdae61",
            "#f46d43",
            "#d73027",
          ],
        },
      ],
      calculations: [
        {
          id: "calc-1",
          name: "Month order",
          aggregation: "max",
          field: "Month number",
          population: "repeat",
          filters: "ignore",
        },
      ],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "Temperatures in Lincoln, Nebraska, in 2016",
          x: 32,
          y: 24,
          width: 696,
          fontSize: 24,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "Each ridge is the distribution of a month's daily mean temperatures, in degrees Fahrenheit, on one shared scale and one shared height, shaded from cold to warm.",
          x: 32,
          y: 56,
          width: 696,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "Months",
          x: 32,
          y: 136,
          frame: { width: 580, height: 96 },
          label: { show: true, width: 110, fontSize: 12 },
          axis: true,
          marks: [
            {
              type: "density",
              id: "mark-1",
              name: "Daily means",
              xScaleId: "n-1",
              bandwidth: 3.4,
              height: "shared",
              fill: "#d9dde3",
              opacity: 0.95,
              stroke: "#ffffff",
              colorScaleId: "value-1",
            },
          ],
          repeat: {
            field: "Month",
            arrangement: "rows",
            columns: 1,
            gap: -54,
            order: "value",
            orderCalcId: "calc-1",
            direction: "asc",
            limit: 12,
          },
        },
        {
          id: "legend-1",
          kind: "legend",
          name: "Temperature key",
          x: 142,
          y: 108,
          unitId: "unit-1",
          markId: "mark-1",
          scaleId: "value-1",
          direction: "row",
          fontSize: 10,
          color: "#1f2328",
        },
        {
          id: "note-1",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Source: Weather Underground observations collected for the ggridges package by Claus Wilke. Densities use a Gaussian kernel with a bandwidth of 3.4 °F on a shared grid. After the ggridges Lincoln weather example.",
          x: 32,
          y: 714,
          width: 696,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  box(
    "lincoln-box",
    "Mean temperature by month",
    "Mean temperature",
    "Month",
    layout(0, 9, 8, 5),
    undefined,
    "Mean temperature, °F"
  ),
  histogram(
    "lincoln-histogram",
    "Daily means",
    "Mean temperature",
    layout(8, 9, 4, 5)
  ),
]);

/**
 * Du Bois's income and expenditure plate: one bar per income class, its
 * spending stacked left to right as shares, joined from class to class by
 * thin lines at each category's edge, in a hand-colored texture on paper.
 */
export const duBoisIncomeDashboard = dashboard("Income and expenditure", [
  {
    ...base,
    id: "du-bois-composition",
    type: "composition",
    title: "Income and expenditure of 150 families in Atlanta",
    layout: layout(0, 0, 12, 9),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 960, height: 660, background: "#e9e0d1" },
      scales: [],
      calculations: [
        {
          id: "calc-1",
          name: "Class order",
          aggregation: "max",
          field: "Order",
          population: "repeat",
          filters: "ignore",
        },
        {
          id: "calc-2",
          name: "Actual average",
          aggregation: "max",
          field: "Average income",
          population: "repeat",
          filters: "ignore",
        },
      ],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "INCOME AND EXPENDITURE OF 150 NEGRO FAMILIES IN ATLANTA, GA., U.S.A.",
          x: 32,
          y: 28,
          width: 896,
          fontSize: 22,
          fontWeight: 700,
          color: "#1f1a17",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "Each bar is one class of annual income, split into the shares spent on rent, food, clothes, and direct taxes, with the rest on other expenses and savings. Lines follow each share from class to class.",
          x: 32,
          y: 64,
          width: 896,
          fontSize: 13,
          fontWeight: 400,
          color: "#5a4f45",
        },
        {
          id: "legend-1",
          kind: "legend",
          name: "Expenditure key",
          x: 252,
          y: 116,
          unitId: "unit-1",
          markId: "mark-1",
          direction: "row",
          fontSize: 12,
          color: "#1f1a17",
        },
        {
          id: "header-1",
          kind: "annotation",
          name: "Class header",
          text: "CLASS",
          x: 32,
          y: 152,
          anchor: { kind: "page" },
          fontSize: 11,
          color: "#1f1a17",
          leader: false,
        },
        {
          id: "header-2",
          kind: "annotation",
          name: "Average header",
          text: "ACTUAL AVERAGE",
          x: 132,
          y: 152,
          anchor: { kind: "page" },
          fontSize: 11,
          color: "#1f1a17",
          leader: false,
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "Income classes",
          x: 32,
          y: 180,
          frame: { width: 676, height: 34 },
          label: {
            show: true,
            width: 220,
            fontSize: 13,
            valueCalcId: "calc-2",
            valueSigns: {
              positive: { prefix: "$", suffix: "", color: "#1f1a17" },
              negative: { prefix: "−$", suffix: "", color: "#1f1a17" },
            },
          },
          axis: false,
          marks: [
            {
              type: "stack",
              id: "mark-1",
              name: "Expenditure",
              categoryField: "Category",
              aggregation: "sum",
              measureField: "Share",
              normalize: true,
              order: "first",
              colors: ["#161412", "#7e6583", "#d99a8e", "#9fb0c1", "#cfc3b1"],
              labelMinHeight: 30,
              labelContent: "share",
              inset: 0,
              direction: "across",
              connect: true,
              texture: "hand",
            },
          ],
          repeat: {
            field: "Class",
            arrangement: "rows",
            columns: 1,
            gap: 32,
            order: "value",
            orderCalcId: "calc-1",
            direction: "asc",
            limit: 12,
          },
        },
        {
          id: "note-1",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Source: W. E. B. Du Bois, plate for the 1900 Paris Exposition (Library of Congress), values as read for the #DuBoisChallenge. The two highest classes paid no rent.",
          x: 32,
          y: 624,
          width: 896,
          fontSize: 10,
          fontWeight: 400,
          color: "#5a4f45",
        },
      ],
    },
  },
  row(
    "du-bois-categories",
    "Share by category",
    "Category",
    layout(0, 9, 6, 5)
  ),
  row("du-bois-classes", "Rows by class", "Class", layout(6, 9, 6, 5)),
]);

/**
 * Banana yields as a table: one row per country in order of its long-term
 * average, a trend line from the yearly values in an inset, each decade's
 * average as a colored cell with its value written in, and the overall
 * average in a tinted column.
 */
export const bananaYieldsDashboard = dashboard("Banana yields", [
  {
    ...base,
    id: "banana-composition",
    type: "composition",
    title: "Long-term top yielding banana-producing countries",
    layout: layout(0, 0, 12, 10),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 960, height: 714, background: "#ffffff" },
      scales: [
        {
          id: "x-1",
          kind: "position",
          name: "Decade",
          field: "Decade",
          domain: "shared",
        },
        {
          id: "value-1",
          kind: "value",
          name: "Tonnes per hectare",
          domain: "shared",
          transform: "linear",
          colors: ["#ffffff", "#e9f5c9", "#a9dcb0", "#5fc0a7", "#24a8a2"],
          stops: [0, 0.35, 0.6, 0.8, 1],
        },
        {
          id: "n-1",
          kind: "numeric",
          name: "Year",
          field: "Year",
          domain: "shared",
          zero: false,
          nice: false,
        },
        {
          id: "n-2",
          kind: "numeric",
          name: "Yield",
          field: "Yield",
          domain: "instance",
          zero: false,
          nice: false,
        },
      ],
      calculations: [
        {
          id: "calc-1",
          name: "Average",
          aggregation: "average",
          field: "Yield",
          population: "repeat",
          filters: "follow",
        },
      ],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "Long-term top yielding banana-producing countries",
          x: 32,
          y: 26,
          width: 896,
          fontSize: 24,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "Tonnes of bananas per hectare. Rows run from the highest average over every period; each decade's cell is its average, deeper green for more.",
          x: 32,
          y: 60,
          width: 896,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        ...(
          [
            ["Country", 32],
            ["Trend", 236],
            ["Average by decade", 372],
          ] as const
        ).map(([text, x], index) => ({
          id: `header-${index + 1}`,
          kind: "annotation" as const,
          name: `${text} header`,
          text,
          x,
          y: 104,
          anchor: { kind: "page" as const },
          fontSize: 12,
          color: "#1f2328",
          leader: false,
        })),
        {
          id: "unit-1",
          kind: "unit",
          name: "Countries",
          x: 32,
          y: 140,
          frame: { width: 432, height: 30 },
          insets: [
            {
              id: "inset-1",
              name: "Trend",
              x: -140,
              y: 3,
              width: 120,
              height: 24,
              axis: false,
              background: "#ffffff",
              outline: false,
            },
          ],
          label: {
            show: true,
            width: 340,
            fontSize: 14,
            valueCalcId: "calc-1",
            valueColumn: { width: 70, header: "Avg", fill: "#eef0ec" },
          },
          axis: true,
          marks: [
            {
              type: "strip",
              id: "mark-1",
              name: "Decade averages",
              shape: "rect",
              positionScaleId: "x-1",
              valueScaleId: "value-1",
              aggregation: "average",
              measureField: "Yield",
              encoding: "color",
              fill: "#24a8a2",
              inset: 1,
              missing: "#ededed",
              valueLabels: true,
              missingLabel: "NA",
            },
            {
              type: "path",
              id: "mark-2",
              name: "Trend",
              frameId: "inset-1",
              xScaleId: "n-1",
              yScaleId: "n-2",
              orderField: "Year",
              stroke: "#2b5ea8",
              strokeWidth: 1,
            },
          ],
          repeat: {
            field: "Country",
            arrangement: "rows",
            columns: 1,
            gap: 3,
            order: "value",
            orderCalcId: "calc-1",
            direction: "desc",
            limit: 20,
          },
        },
        {
          id: "note-1",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Decade averages from Our World in Data, as tabulated by Joel Soroos; the 2010s run 2010 to 2018. Trend lines are illustrative yearly values drawn to match each decade's average. NA marks decades without a figure.",
          x: 32,
          y: 676,
          width: 896,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  row("banana-countries", "Rows by country", "Country", layout(0, 10, 6, 5)),
  histogram("banana-yields", "Yearly yields", "Yield", layout(6, 10, 6, 5)),
]);

/**
 * The yield gap as a waffle histogram: for wheat and maize, one square per
 * country stacked in a small waffle over its gap, in whole tonnes per
 * hectare, colored by continent.
 */
export const yieldGapDashboard = dashboard("Yield gap", [
  {
    ...base,
    id: "yield-gap-composition",
    type: "composition",
    title: "The yield gap",
    layout: layout(0, 0, 12, 8),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 960, height: 590, background: "#ffffff" },
      scales: [
        {
          id: "n-1",
          kind: "numeric",
          name: "Yield gap, tonnes per hectare",
          field: "Yield gap",
          domain: "shared",
          zero: true,
          nice: false,
          min: 0,
          max: 13,
        },
      ],
      calculations: [],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "The Yield Gap",
          x: 32,
          y: 26,
          width: 896,
          fontSize: 26,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "Each square is a country, colored by its continent and stacked over its yield gap: the tonnes per hectare between what its farms harvest and what they could.",
          x: 32,
          y: 62,
          width: 896,
          fontSize: 14,
          fontWeight: 400,
          color: "#3c4043",
        },
        {
          id: "legend-1",
          kind: "legend",
          name: "Continent key",
          x: 142,
          y: 108,
          unitId: "unit-1",
          markId: "mark-1",
          direction: "row",
          fontSize: 12,
          color: "#1f2328",
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "Crops",
          x: 32,
          y: 150,
          frame: { width: 800, height: 176 },
          label: { show: true, width: 110, fontSize: 14 },
          axis: true,
          axisTitles: { x: "Yield gap, tonnes per hectare" },
          marks: [
            {
              type: "waffle",
              id: "mark-1",
              name: "Countries",
              categoryField: "Continent",
              each: 1,
              normalize: false,
              columns: 3,
              gap: 1.5,
              from: "bottom",
              order: "label",
              colors: [
                "#f8b931",
                "#e9406a",
                "#07a07a",
                "#5a4fcf",
                "#f58fa3",
                "#18c9a0",
              ],
              xScaleId: "n-1",
            },
          ],
          repeat: {
            field: "Crop",
            arrangement: "rows",
            columns: 1,
            gap: 24,
            order: "count",
            limit: 4,
          },
        },
        {
          id: "note-1",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Illustrative countries and gaps generated for this demo, shaped after the published Yield Gap graphic; not a survey of real yields.",
          x: 32,
          y: 560,
          width: 896,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  row(
    "yield-gap-continents",
    "Countries by continent",
    "Continent",
    layout(0, 8, 6, 5)
  ),
  histogram("yield-gap-values", "Yield gaps", "Yield gap", layout(6, 8, 6, 5)),
]);

/**
 * The changing nature of middle-class jobs: ten occupation groups, each a
 * slope chart of its occupations' jobs per 1,000 middle-class jobs in 1980
 * and 2012, every line colored by the occupation's mix of men and women.
 */
export const middleClassJobsDashboard = dashboard("Middle-class jobs", [
  {
    ...base,
    id: "jobs-composition",
    type: "composition",
    title: "The changing nature of middle-class jobs",
    layout: layout(0, 0, 12, 10),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 960, height: 704, background: "#ffffff" },
      scales: [
        {
          id: "n-1",
          kind: "numeric",
          name: "Year",
          field: "Year",
          domain: "shared",
          zero: false,
          nice: false,
          ticks: "ends",
        },
        {
          id: "n-2",
          kind: "numeric",
          name: "Jobs per 1,000 middle-class jobs",
          field: "Jobs per 1000",
          domain: "shared",
          zero: true,
          nice: false,
          min: 0,
          max: 85,
        },
        {
          id: "value-1",
          kind: "value",
          name: "Share of women minus share of men, points",
          domain: "shared",
          transform: "linear",
          colors: ["#1a8fd0", "#e3173b"],
          center: "#b9b9b9",
          max: 100,
        },
      ],
      calculations: [
        {
          id: "calc-1",
          name: "Group order",
          aggregation: "max",
          field: "Group order",
          population: "repeat",
          filters: "ignore",
        },
        {
          id: "calc-2",
          name: "Change in jobs",
          aggregation: "max",
          field: "Group change",
          population: "repeat",
          filters: "ignore",
        },
      ],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "The Changing Nature of Middle-Class Jobs",
          x: 32,
          y: 26,
          width: 896,
          fontSize: 26,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "Jobs per 1,000 middle-class jobs in 1980 and 2012, by occupation. Fewer are now in production work held mostly by men; a greater share are in occupations more open to women. Each label gives the group's change.",
          x: 32,
          y: 62,
          width: 896,
          fontSize: 14,
          fontWeight: 400,
          color: "#3c4043",
        },
        {
          id: "legend-1",
          kind: "legend",
          name: "Gender key",
          x: 620,
          y: 130,
          unitId: "unit-1",
          markId: "mark-1",
          scaleId: "value-1",
          direction: "row",
          fontSize: 10,
          color: "#1f2328",
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "Occupation groups",
          x: 56,
          y: 176,
          frame: { width: 120, height: 180 },
          label: {
            show: true,
            width: 0,
            fontSize: 11,
            valueCalcId: "calc-2",
            valueSigns: {
              positive: { prefix: "+", suffix: " jobs", color: "#1f2328" },
              negative: { prefix: "−", suffix: " jobs", color: "#1f2328" },
            },
          },
          axis: true,
          marks: [
            {
              type: "path",
              id: "mark-1",
              name: "Occupations",
              xScaleId: "n-1",
              yScaleId: "n-2",
              orderField: "Year",
              stroke: "#1f2328",
              strokeWidth: 1.5,
              seriesField: "Occupation",
              valueField: "Women minus men",
              valueScaleId: "value-1",
            },
            {
              type: "point",
              id: "mark-2",
              name: "Ends",
              xScaleId: "n-1",
              yScaleId: "n-2",
              orderField: "Year",
              radius: 2.5,
              fill: "#1f2328",
              labelEvery: 0,
              valueField: "Women minus men",
              valueScaleId: "value-1",
            },
          ],
          repeat: {
            field: "Group",
            arrangement: "grid",
            columns: 5,
            gap: 46,
            order: "value",
            orderCalcId: "calc-1",
            direction: "asc",
            limit: 10,
          },
        },
        {
          id: "note-1",
          kind: "annotation",
          name: "Nurses",
          text: "Registered\nnurses",
          x: -62,
          y: -46,
          anchor: {
            kind: "frame",
            unitId: "unit-1",
            instanceKey: "Professionals",
            fx: 0.5,
            fy: 0.656,
          },
          fontSize: 11,
          color: "#1f2328",
          leader: true,
        },
        {
          id: "note-2",
          kind: "annotation",
          name: "Health technologists",
          text: "Health\ntechnologists",
          x: -30,
          y: -60,
          anchor: {
            kind: "frame",
            unitId: "unit-1",
            instanceKey: "Technicians",
            fx: 0.5,
            fy: 0.829,
          },
          fontSize: 11,
          color: "#1f2328",
          leader: true,
        },
        {
          id: "note-3",
          kind: "annotation",
          name: "Police",
          text: "Police and\ndetectives",
          x: -20,
          y: -52,
          anchor: {
            kind: "frame",
            unitId: "unit-1",
            instanceKey: "Police, fire, military",
            fx: 0.5,
            fy: 0.812,
          },
          fontSize: 11,
          color: "#1f2328",
          leader: true,
        },
        {
          id: "note-4",
          kind: "annotation",
          name: "Secretaries",
          text: "Secretaries",
          x: -30,
          y: -36,
          anchor: {
            kind: "frame",
            unitId: "unit-1",
            instanceKey: "Admin support",
            fx: 0.5,
            fy: 0.696,
          },
          fontSize: 11,
          color: "#1f2328",
          leader: true,
        },
        {
          id: "note-5",
          kind: "annotation",
          name: "Production supervisors",
          text: "Production\nsupervisors",
          x: 30,
          y: -50,
          anchor: {
            kind: "frame",
            unitId: "unit-1",
            instanceKey: "Skilled production",
            fx: 0.4,
            fy: 0.715,
          },
          fontSize: 11,
          color: "#1f2328",
          leader: true,
        },
        {
          id: "note-6",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Illustrative values read approximately from Gregor Aisch and Robert Gebeloff's graphic for The New York Times (2015); middle-class jobs paid $40,000 to $80,000 in 2014 dollars. Unnamed lines are other occupations in each group.",
          x: 32,
          y: 668,
          width: 896,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  row("jobs-groups", "Rows by group", "Group", layout(0, 10, 6, 5)),
  histogram("jobs-share", "Share of women", "Women share", layout(6, 10, 6, 5)),
]);
/**
 * Warmer days, year by year: a ridgeline of 84 years. Each ridge is the
 * density of one year's daily global temperatures against a 1991–2020
 * average, shaded through a diverging scale from colder to warmer, with
 * every fifth year named and three years called out.
 */
export const climateRidgelineDashboard = dashboard("Warmer days", [
  {
    ...base,
    id: "climate-composition",
    type: "composition",
    title: "More days at the highest temperatures",
    layout: layout(0, 0, 12, 12),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 760, height: 936, background: "#ffffff" },
      scales: [
        {
          id: "n-1",
          kind: "numeric",
          name: "Difference from average, °C",
          field: "Difference",
          domain: "shared",
          zero: false,
          nice: false,
          min: -1.4,
          max: 1.3,
        },
        {
          id: "value-1",
          kind: "value",
          name: "Colder or warmer than the 1991–2020 average, °C",
          domain: "shared",
          transform: "linear",
          colors: ["#2166ac", "#b2182b"],
          center: "#f7f7f7",
        },
      ],
      calculations: [],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "More days at the highest temperatures in 2023",
          x: 32,
          y: 24,
          width: 696,
          fontSize: 24,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "Each ridge shows every day of one year and how far that day's global air temperature sat from the 1991–2020 average. Taller means more days at that temperature.",
          x: 32,
          y: 56,
          width: 696,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "legend-1",
          kind: "legend",
          name: "Difference key",
          x: 92,
          y: 112,
          unitId: "unit-1",
          markId: "mark-1",
          scaleId: "value-1",
          direction: "row",
          fontSize: 10,
          color: "#1f2328",
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "Years",
          x: 32,
          y: 150,
          frame: { width: 620, height: 64 },
          label: { show: true, width: 56, fontSize: 11, every: 5 },
          axis: true,
          marks: [
            {
              type: "density",
              id: "mark-1",
              name: "Daily temperatures",
              xScaleId: "n-1",
              bandwidth: 0.05,
              height: "shared",
              fill: "#d9dde3",
              opacity: 1,
              stroke: "#1f2328",
              colorScaleId: "value-1",
            },
          ],
          repeat: {
            field: "Year",
            arrangement: "rows",
            columns: 1,
            gap: -56,
            order: "label",
            direction: "asc",
            limit: 100,
          },
        },
        {
          id: "note-1",
          kind: "annotation",
          name: "1998",
          text: "1998: El Niño year",
          x: 110,
          y: -20,
          anchor: {
            kind: "frame",
            unitId: "unit-1",
            instanceKey: "1998",
            fx: 0.55,
            fy: 0.55,
          },
          fontSize: 11,
          color: "#1f2328",
          leader: true,
        },
        {
          id: "note-2",
          kind: "annotation",
          name: "2016",
          text: "2016: El Niño and the\nprevious warmest year",
          x: 70,
          y: -26,
          anchor: {
            kind: "frame",
            unitId: "unit-1",
            instanceKey: "2016",
            fx: 0.7,
            fy: 0.7,
          },
          fontSize: 11,
          color: "#1f2328",
          leader: true,
        },
        {
          id: "note-3",
          kind: "annotation",
          name: "2023",
          text: "2023",
          x: 46,
          y: -14,
          anchor: {
            kind: "frame",
            unitId: "unit-1",
            instanceKey: "2023",
            fx: 0.86,
            fy: 0.85,
          },
          fontSize: 12,
          color: "#b2182b",
          leader: true,
        },
        {
          id: "note-4",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Illustrative daily values generated for this demo, shaped after the ERA5 record (C3S/ECMWF); not observations. Densities use a Gaussian kernel with a 0.05 °C bandwidth. After the BBC's ridgeline of global temperatures.",
          x: 32,
          y: 892,
          width: 696,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  scatter(
    "climate-scatter",
    "Every day by year",
    "Year",
    "Difference",
    layout(0, 12, 8, 5),
    ["Year", "Difference from average, °C"]
  ),
  histogram(
    "climate-days",
    "Daily differences",
    "Difference",
    layout(8, 12, 4, 5),
    "Difference from average, °C"
  ),
]);
export const taxSlopeDashboard = dashboard("Tax revenue slope", [
  {
    ...base,
    id: "tax-composition",
    type: "composition",
    title: "Central government tax revenue, 2000 and 2023",
    layout: layout(0, 0, 12, 9),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 760, height: 720, background: "#ffffff" },
      scales: [
        {
          id: "n-1",
          kind: "numeric",
          name: "Year",
          field: "Year",
          domain: "shared",
          zero: false,
          nice: false,
          ticks: "ends",
        },
        {
          id: "n-2",
          kind: "numeric",
          name: "Tax revenue",
          field: "Tax revenue",
          domain: "shared",
          zero: false,
          nice: false,
          ticks: "none",
        },
      ],
      calculations: [],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "Central government tax revenue, 2000 and 2023",
          x: 32,
          y: 24,
          width: 696,
          fontSize: 24,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "Tax revenue as a share of GDP in 34 OECD countries. Each line joins a country's two readings; the steeper it tilts, the larger the change.",
          x: 32,
          y: 56,
          width: 696,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "legend-1",
          kind: "legend",
          name: "Direction key",
          x: 250,
          y: 100,
          unitId: "unit-1",
          markId: "mark-1",
          direction: "row",
          fontSize: 11,
          color: "#1f2328",
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "Countries",
          x: 250,
          y: 130,
          frame: { width: 260, height: 520 },
          label: { show: false, width: 0, fontSize: 12 },
          axis: true,
          marks: [
            {
              type: "path",
              id: "mark-1",
              name: "Share of GDP",
              xScaleId: "n-1",
              yScaleId: "n-2",
              orderField: "Year",
              stroke: "#1f2328",
              strokeWidth: 1.25,
              seriesField: "Country",
              colorField: "Direction",
              colors: ["#b3443b", "#2f6db5"],
              labels: "both",
              labelValue: true,
            },
            {
              type: "point",
              id: "mark-2",
              name: "Readings",
              xScaleId: "n-1",
              yScaleId: "n-2",
              radius: 2.5,
              fill: "#1f2328",
              labelEvery: 0,
              colorField: "Direction",
              colors: ["#b3443b", "#2f6db5"],
            },
          ],
          repeat: {
            arrangement: "rows",
            columns: 1,
            gap: 0,
            order: "label",
            limit: 1,
          },
        },
        {
          id: "note-1",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Source: World Bank, World Development Indicators, tax revenue (% of GDP), indicator GC.TAX.TOTL.GD.ZS, central government only. OECD members with readings for both years; Japan, Australia, New Zealand, and Türkiye lack one. After Tufte's slope graph of government receipts.",
          x: 32,
          y: 680,
          width: 696,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  row(
    "tax-direction",
    "Countries by direction",
    "Direction",
    layout(0, 9, 4, 5)
  ),
  histogram(
    "tax-change",
    "Change in share, 2000 to 2023",
    "Change 2000–2023",
    layout(4, 9, 8, 5)
  ),
]);

export const titanicWaffleDashboard = dashboard("Titanic waffle", [
  {
    ...base,
    id: "titanic-composition",
    type: "composition",
    title: "Every passenger on the Titanic",
    layout: layout(0, 0, 12, 9),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 760, height: 620, background: "#ffffff" },
      scales: [],
      calculations: [],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "Every passenger on the Titanic",
          x: 32,
          y: 24,
          width: 696,
          fontSize: 24,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "One cell per person, by class. Cells fill from the bottom, those who died first, so each column's height is its class and the blue block is who survived.",
          x: 32,
          y: 56,
          width: 696,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "legend-1",
          kind: "legend",
          name: "Fate key",
          x: 32,
          y: 100,
          unitId: "unit-1",
          markId: "mark-1",
          direction: "row",
          fontSize: 11,
          color: "#1f2328",
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "Classes",
          x: 32,
          y: 128,
          frame: { width: 200, height: 420 },
          label: { show: true, width: 0, fontSize: 12 },
          axis: false,
          marks: [
            {
              type: "waffle",
              id: "mark-1",
              name: "Passengers",
              categoryField: "Fate",
              each: 1,
              normalize: false,
              columns: 20,
              gap: 2,
              from: "bottom",
              order: "label",
              colors: ["#b3443b", "#2f6db5"],
            },
          ],
          repeat: {
            field: "Class",
            arrangement: "columns",
            columns: 3,
            gap: 48,
            order: "label",
            limit: 3,
          },
        },
        {
          id: "note-1",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Source: the titanic3 passenger list compiled by Thomas Cason from the Encyclopedia Titanica, kept by Vanderbilt University's Department of Biostatistics. 1,309 passengers; crew are not included.",
          x: 32,
          y: 580,
          width: 696,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  row("titanic-sex", "Passengers by sex", "Sex", layout(0, 9, 3, 5)),
  row(
    "titanic-age",
    "Passengers by age group",
    "Age group",
    layout(3, 9, 3, 5)
  ),
  histogram("titanic-ages", "Ages", "Age", layout(6, 9, 6, 5)),
]);

export const unemploymentStreamDashboard = dashboard("Unemployment stream", [
  {
    ...base,
    id: "unemployment-composition",
    type: "composition",
    title: "Unemployed Americans by industry, 2000 to 2010",
    layout: layout(0, 0, 12, 9),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 760, height: 620, background: "#ffffff" },
      scales: [
        {
          id: "n-1",
          kind: "numeric",
          name: "Month",
          field: "Month",
          domain: "shared",
          zero: false,
          nice: false,
        },
      ],
      calculations: [
        {
          id: "calc-1",
          name: "Unemployed",
          aggregation: "sum",
          field: "Unemployed (thousands)",
          population: "composition",
          filters: "follow",
        },
      ],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "Unemployed Americans by industry, 2000 to 2010",
          x: 32,
          y: 24,
          width: 696,
          fontSize: 24,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "Each layer is one industry's unemployed, in thousands, month by month. The stream's thickness is the total; its baseline wanders to keep the layers' slopes small.",
          x: 32,
          y: 56,
          width: 696,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "legend-1",
          kind: "legend",
          name: "Industry key",
          x: 32,
          y: 100,
          unitId: "unit-1",
          markId: "mark-1",
          direction: "row",
          fontSize: 10,
          color: "#1f2328",
          width: 696,
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "Months",
          x: 32,
          y: 160,
          frame: { width: 680, height: 380 },
          label: { show: false, width: 0, fontSize: 12 },
          axis: true,
          marks: [
            {
              type: "stack",
              id: "mark-1",
              name: "Unemployed",
              categoryField: "Industry",
              aggregation: "sum",
              measureField: "Unemployed (thousands)",
              normalize: false,
              order: "total",
              colors: [
                "#4e79a7",
                "#a0cbe8",
                "#f28e2b",
                "#ffbe7d",
                "#59a14f",
                "#8cd17d",
                "#b6992d",
                "#f1ce63",
                "#499894",
                "#86bcb6",
                "#e15759",
                "#ff9d9a",
                "#79706e",
                "#bab0ac",
              ],
              labelMinHeight: 16,
              inset: 0,
              xScaleId: "n-1",
              baseline: "wiggle",
              curve: "smooth",
            },
          ],
          repeat: {
            arrangement: "rows",
            columns: 1,
            gap: 0,
            order: "label",
            limit: 1,
          },
        },
        {
          id: "note-1",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Source: Bureau of Labor Statistics, Current Population Survey, unemployed persons by industry, January 2000 to February 2010, as packaged in vega-datasets. After the streamgraph in the vega-datasets examples.",
          x: 32,
          y: 580,
          width: 696,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  row("unemployment-industry", "Industries", "Industry", layout(0, 9, 4, 5)),
  histogram(
    "unemployment-rate",
    "Monthly unemployment rates",
    "Unemployment rate",
    layout(4, 9, 8, 5)
  ),
]);

const pyramidUnit = (
  id: string,
  year: string,
  x: number
): Extract<
  Extract<Chart, { type: "composition" }>["composition"]["elements"][number],
  { kind: "unit" }
> => ({
  id,
  kind: "unit",
  name: `Ages in ${year}`,
  x,
  y: 150,
  frame: { width: 280, height: 14 },
  label: { show: true, width: 76, fontSize: 11 },
  axis: true,
  window: { field: "Year", min: year, max: year },
  marks: [
    {
      type: "bar",
      id: "mark-1",
      name: "People",
      aggregation: "sum",
      measureField: "People",
      categoryField: "Sex",
      mirror: "Male",
      order: "label",
      colors: ["#c2577a", "#4e79a7"],
      max: 12_000_000,
      inset: 0,
      labelMinWidth: 0,
    },
  ],
  repeat: {
    field: "Age group",
    arrangement: "rows",
    columns: 1,
    gap: 2,
    order: "value",
    orderCalcId: "calc-1",
    direction: "desc",
    limit: 19,
  },
});

export const populationPyramidDashboard = dashboard("Population pyramids", [
  {
    ...base,
    id: "population-composition",
    type: "composition",
    title: "The United States grew older",
    layout: layout(0, 0, 12, 9),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 800, height: 560, background: "#ffffff" },
      scales: [],
      calculations: [
        {
          id: "calc-1",
          name: "Age order",
          aggregation: "max",
          field: "Age",
          population: "repeat",
          filters: "ignore",
        },
      ],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "The United States grew older",
          x: 32,
          y: 24,
          width: 736,
          fontSize: 24,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "Population by five-year age group at the 1900 and 2000 censuses, men to the left of the baseline and women to the right, on one shared length axis.",
          x: 32,
          y: 56,
          width: 736,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "legend-1",
          kind: "legend",
          name: "Sex key",
          x: 108,
          y: 96,
          unitId: "unit-2",
          markId: "mark-1",
          direction: "row",
          fontSize: 11,
          color: "#1f2328",
        },
        {
          id: "heading-1",
          kind: "text",
          role: "note",
          name: "1900 heading",
          text: "1900 · 76 million people",
          x: 108,
          y: 126,
          width: 280,
          fontSize: 12,
          fontWeight: 600,
          color: "#1f2328",
        },
        {
          id: "heading-2",
          kind: "text",
          role: "note",
          name: "2000 heading",
          text: "2000 · 281 million people",
          x: 488,
          y: 126,
          width: 280,
          fontSize: 12,
          fontWeight: 600,
          color: "#1f2328",
        },
        pyramidUnit("unit-1", "1900", 32),
        pyramidUnit("unit-2", "2000", 412),
        {
          id: "note-1",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Source: U.S. Census Bureau decennial censuses, as packaged in vega-datasets (population.json). Lengths read in people; both pyramids share the 12 million axis.",
          x: 32,
          y: 520,
          width: 736,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  row("population-year", "Censuses", "Year", layout(0, 9, 4, 5)),
  row("population-sex", "People by sex", "Sex", layout(4, 9, 4, 5)),
  row("population-age", "People by age group", "Age group", layout(8, 9, 4, 5)),
]);

export const gdpBumpDashboard = dashboard("GDP ranks", [
  {
    ...base,
    id: "gdp-composition",
    type: "composition",
    title: "The world's largest economies, ranked each year since 1980",
    layout: layout(0, 0, 12, 9),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 800, height: 640, background: "#ffffff" },
      scales: [
        {
          id: "n-1",
          kind: "numeric",
          name: "Year",
          field: "Year",
          domain: "shared",
          zero: false,
          nice: false,
        },
        {
          id: "n-2",
          kind: "numeric",
          name: "GDP",
          field: "GDP (current US$)",
          domain: "shared",
          zero: false,
          nice: true,
        },
      ],
      calculations: [],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "The world's largest economies, ranked each year since 1980",
          x: 32,
          y: 24,
          width: 736,
          fontSize: 24,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "Rank by GDP in current US dollars among the 17 economies that stood in the top twelve in any year. China climbs from 11th to 2nd; India enters the top five.",
          x: 32,
          y: 56,
          width: 736,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "legend-1",
          kind: "legend",
          name: "Region key",
          x: 72,
          y: 100,
          unitId: "unit-1",
          markId: "mark-1",
          direction: "row",
          fontSize: 11,
          color: "#1f2328",
          width: 700,
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "Years",
          x: 72,
          y: 136,
          frame: { width: 560, height: 440 },
          label: { show: false, width: 0, fontSize: 12 },
          axis: true,
          marks: [
            {
              type: "path",
              id: "mark-1",
              name: "Rank",
              xScaleId: "n-1",
              yScaleId: "n-2",
              orderField: "Year",
              stroke: "#1f2328",
              strokeWidth: 2,
              seriesField: "Country",
              colorField: "Region",
              colors: [
                "#f28e2b",
                "#4e79a7",
                "#59a14f",
                "#b07aa1",
                "#e15759",
                "#76b7b2",
              ],
              rank: "desc",
              curve: "smooth",
              labels: "end",
              labelValue: true,
            },
          ],
          repeat: {
            arrangement: "rows",
            columns: 1,
            gap: 0,
            order: "label",
            limit: 1,
          },
        },
        {
          id: "note-1",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Source: World Bank, World Development Indicators, GDP (current US$), indicator NY.GDP.MKTP.CD. Ranks are computed among the economies shown, so a filter re-ranks the rest.",
          x: 32,
          y: 604,
          width: 736,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  row("gdp-region", "Economies by region", "Region", layout(0, 9, 4, 5)),
  row("gdp-country", "Economies", "Country", layout(4, 9, 8, 5)),
]);

export const scotusTimelineDashboard = dashboard("Supreme Court seats", [
  {
    ...base,
    id: "scotus-composition",
    type: "composition",
    title: "Every seat on the Supreme Court, 1789 to today",
    layout: layout(0, 0, 12, 9),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 800, height: 600, background: "#ffffff" },
      scales: [
        {
          id: "n-1",
          kind: "numeric",
          name: "Term",
          field: "Start",
          domain: "shared",
          zero: false,
          nice: false,
        },
      ],
      calculations: [
        {
          id: "calc-1",
          name: "Seat order",
          aggregation: "max",
          field: "Seat",
          population: "repeat",
          filters: "ignore",
        },
      ],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "Every seat on the Supreme Court, 1789 to today",
          x: 32,
          y: 24,
          width: 736,
          fontSize: 24,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "One lane per seat, one bar per justice from oath to departure, colored by the party of the president who appointed them. Open bars are sitting justices.",
          x: 32,
          y: 56,
          width: 736,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "legend-1",
          kind: "legend",
          name: "Party key",
          x: 128,
          y: 100,
          unitId: "unit-1",
          markId: "mark-1",
          direction: "row",
          fontSize: 11,
          color: "#1f2328",
          width: 640,
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "Seats",
          x: 32,
          y: 136,
          frame: { width: 640, height: 30 },
          label: { show: true, width: 96, fontSize: 11 },
          axis: true,
          marks: [
            {
              type: "span",
              id: "mark-1",
              name: "Terms",
              xScaleId: "n-1",
              startField: "Start",
              endField: "End",
              openEnd: true,
              fill: "#1f2328",
              colorField: "Party",
              colors: ["#2f6db5", "#8fb3dc", "#8a8f98", "#b3443b", "#c9a227"],
              labelField: "Surname",
              labelMinWidth: 44,
              inset: 2,
            },
          ],
          repeat: {
            field: "Seat name",
            arrangement: "rows",
            columns: 1,
            gap: 6,
            order: "value",
            orderCalcId: "calc-1",
            direction: "asc",
            limit: 11,
          },
        },
        {
          id: "note-1",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Source: Wikipedia, List of justices of the Supreme Court of the United States, parsed from the article's table; parties from the appointing president's election. Seats 5 and 7 ended when Congress shrank the Court after 1866; the two gold bars are Whig appointees.",
          x: 32,
          y: 556,
          width: 736,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  row(
    "scotus-party",
    "Justices by appointing party",
    "Party",
    layout(0, 9, 4, 5)
  ),
  row("scotus-left", "How justices left", "Left by", layout(4, 9, 4, 5)),
  histogram("scotus-years", "Years served", "Years served", layout(8, 9, 4, 5)),
]);

export const stocksHorizonDashboard = dashboard("Stock horizons", [
  {
    ...base,
    id: "stocks-composition",
    type: "composition",
    title: "Five tech stocks, 2000 to 2010, as horizon bands",
    layout: layout(0, 0, 12, 9),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 800, height: 460, background: "#ffffff" },
      scales: [
        {
          id: "n-1",
          kind: "numeric",
          name: "Month",
          field: "Month",
          domain: "shared",
          zero: false,
          nice: false,
        },
      ],
      calculations: [],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "Five tech stocks, 2000 to 2010, as horizon bands",
          x: 32,
          y: 24,
          width: 736,
          fontSize: 24,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "Each row is a stock's price as growth since January 2000, folded into three bands: the deeper the blue, the higher the gain; red bands are losses mirrored upward.",
          x: 32,
          y: 56,
          width: 736,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "Stocks",
          x: 32,
          y: 110,
          frame: { width: 640, height: 44 },
          label: { show: true, width: 96, fontSize: 12 },
          axis: true,
          marks: [
            {
              type: "horizon",
              id: "mark-1",
              name: "Growth",
              xScaleId: "n-1",
              field: "Price",
              orderField: "Month",
              baseline: "first",
              relative: true,
              bands: 3,
              domain: "instance",
              positive: "#08519c",
              negative: "#a50f15",
            },
          ],
          repeat: {
            field: "Company",
            arrangement: "rows",
            columns: 1,
            gap: 6,
            order: "label",
            limit: 5,
          },
        },
        {
          id: "note-1",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Source: monthly closing prices as packaged in vega-datasets (stocks.csv); Google starts in August 2004. Each row's bands span its own largest swing, so Apple's bands are hundreds of percent and IBM's are tens. After the horizon graphs of Heer, Kong, and Agrawala.",
          x: 32,
          y: 416,
          width: 736,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  row("stocks-company", "Companies", "Company", layout(0, 9, 4, 5)),
  histogram("stocks-prices", "Monthly prices", "Price", layout(4, 9, 8, 5)),
]);

export const co2SwarmDashboard = dashboard("Emissions swarm", [
  {
    ...base,
    id: "co2-composition",
    type: "composition",
    title: "Carbon dioxide per person, 2020",
    layout: layout(0, 0, 12, 9),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 800, height: 640, background: "#ffffff" },
      scales: [
        {
          id: "n-1",
          kind: "numeric",
          name: "Tonnes per person",
          field: "CO2 per person",
          domain: "shared",
          zero: false,
          nice: true,
          transform: "log",
        },
      ],
      calculations: [
        {
          id: "calc-1",
          name: "Economies",
          aggregation: "count",
          population: "repeat",
          filters: "follow",
        },
      ],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "Carbon dioxide per person, 2020",
          x: 32,
          y: 24,
          width: 736,
          fontSize: 24,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "Every economy as one dot, sized by population and colored by income group, swarmed along a log scale of tonnes per person within its region.",
          x: 32,
          y: 56,
          width: 736,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "legend-1",
          kind: "legend",
          name: "Income key",
          x: 248,
          y: 100,
          unitId: "unit-1",
          markId: "mark-1",
          direction: "row",
          fontSize: 11,
          color: "#1f2328",
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "Regions",
          x: 32,
          y: 128,
          frame: { width: 520, height: 56 },
          label: { show: true, width: 216, fontSize: 11 },
          axis: true,
          marks: [
            {
              type: "point",
              id: "mark-1",
              name: "Economies",
              xScaleId: "n-1",
              radius: 14,
              minRadius: 2.5,
              fill: "#4e79a7",
              labelField: "Economy",
              labelEvery: 1,
              labelValues:
                "China, United States, India, Qatar, Palau, Germany, Nigeria, Brazil",
              sizeField: "Population",
              colorField: "Income group",
              colors: ["#1f77b4", "#c7c7c7", "#9ecae1", "#6baed6"],
              spread: "swarm",
            },
          ],
          repeat: {
            field: "Region",
            arrangement: "rows",
            columns: 1,
            gap: 6,
            order: "label",
            limit: 7,
          },
        },
        {
          id: "note-1",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Source: World Bank, World Development Indicators, CO2 emissions excluding land use per capita (EN.GHG.CO2.PC.CE.AR5) and population (SP.POP.TOTL), 2020, with the World Bank's regions and income groups. Dot area follows population; Palau's 72 tonnes per person sits at the far right.",
          x: 32,
          y: 596,
          width: 736,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  row(
    "co2-income",
    "Economies by income group",
    "Income group",
    layout(0, 9, 4, 5)
  ),
  histogram(
    "co2-tonnes",
    "Tonnes per person",
    "CO2 per person",
    layout(4, 9, 8, 5)
  ),
]);

export const titanicMosaicDashboard = dashboard("Titanic mosaic", [
  {
    ...base,
    id: "mosaic-composition",
    type: "composition",
    title: "Who survived the Titanic, by class",
    layout: layout(0, 0, 12, 9),
    margin: { top: 0, right: 0, bottom: 0, left: 0 },
    composition: {
      artboard: { width: 760, height: 600, background: "#ffffff" },
      scales: [],
      calculations: [
        {
          id: "calc-1",
          name: "Passengers",
          aggregation: "count",
          population: "repeat",
          filters: "follow",
        },
      ],
      overrides: [],
      elements: [
        {
          id: "title-1",
          kind: "text",
          role: "title",
          name: "Title",
          text: "Who survived the Titanic, by class",
          x: 32,
          y: 24,
          width: 696,
          fontSize: 24,
          fontWeight: 700,
          color: "#1f2328",
        },
        {
          id: "subtitle-1",
          kind: "text",
          role: "subtitle",
          name: "Subtitle",
          text: "A mosaic: each column's width is its class's share of passengers, and each column stacks the share who survived over the share who died, so area is people.",
          x: 32,
          y: 56,
          width: 696,
          fontSize: 13,
          fontWeight: 400,
          color: "#5f6368",
        },
        {
          id: "legend-1",
          kind: "legend",
          name: "Fate key",
          x: 32,
          y: 100,
          unitId: "unit-1",
          markId: "mark-1",
          direction: "row",
          fontSize: 11,
          color: "#1f2328",
        },
        {
          id: "unit-1",
          kind: "unit",
          name: "Classes",
          x: 32,
          y: 128,
          frame: { width: 228, height: 400 },
          label: { show: true, width: 0, fontSize: 12, valueCalcId: "calc-1" },
          axis: false,
          marks: [
            {
              type: "stack",
              id: "mark-1",
              name: "Passengers",
              categoryField: "Fate",
              aggregation: "count",
              normalize: true,
              order: "label",
              colors: ["#b3443b", "#2f6db5"],
              labelMinHeight: 16,
              inset: 2,
            },
          ],
          repeat: {
            field: "Class",
            arrangement: "columns",
            columns: 3,
            gap: 6,
            order: "label",
            limit: 3,
            weightCalcId: "calc-1",
          },
        },
        {
          id: "note-1",
          kind: "text",
          role: "note",
          name: "Note",
          text: "Source: the titanic3 passenger list compiled by Thomas Cason from the Encyclopedia Titanica, kept by Vanderbilt University's Department of Biostatistics. Filter by sex or age group and the columns resize to the rows that remain.",
          x: 32,
          y: 560,
          width: 696,
          fontSize: 10,
          fontWeight: 400,
          color: "#5f6368",
        },
      ],
    },
  },
  row("mosaic-sex", "Passengers by sex", "Sex", layout(0, 9, 4, 5)),
  row("mosaic-age", "Passengers by age group", "Age group", layout(4, 9, 4, 5)),
  row("mosaic-port", "Passengers by port", "Embarked", layout(8, 9, 4, 5)),
]);

/*
 * Built-in counterparts. Each answers the same question as a composition
 * example above with an ordinary chart and its public settings, so the
 * analysis needs no artboard. The composed originals stay as authored
 * graphics.
 */

const regionColors = [
  "#4e79a7",
  "#f28e2b",
  "#59a14f",
  "#e15759",
  "#76b7b2",
  "#b07aa1",
  "#edc948",
];
const mappedScale = (
  id: string,
  name: string,
  labels: string[],
  colors: string[]
): SavedDataStructure["colorScales"][number] => ({
  id,
  name,
  sourceField: name,
  type: "categorical",
  palette: colors,
  mapping: labels.map((label, i) => [label, colors[i % colors.length]!]),
});
const labelled = (country: string, dx: number, dy: number) => ({
  id: `income-life-label-${country.toLowerCase().replace(/\W+/g, "-")}`,
  type: "callout" as const,
  text: country,
  attach: {
    kind: "record" as const,
    keyFields: ["Country"],
    key: [country],
  },
  offset: { dx, dy },
});

/** Income against life expectancy as an ordinary bubble scatter. */
export const incomeLifeScatterDashboard = dashboard(
  "Income and life, built in",
  [
    {
      ...scatter(
        "income-life-scatter",
        "Richer countries live longer",
        "GDP per capita",
        "Life expectancy",
        layout(0, 0, 12, 7),
        ["GDP per capita (PPP, 2021 $)", "Life expectancy (years)"],
        "Region",
        "income-life-region"
      ),
      xAxis: { grid: false, scaleType: "log" },
      sizeField: "Population",
      maxBubbleRadius: 22,
      pointOpacity: 0.7,
      annotations: [
        labelled("China", 18, -26),
        labelled("India", -18, -28),
        labelled("United States", -34, -30),
        labelled("Nigeria", -26, 24),
        labelled("Japan", 18, -24),
        labelled("Chad", -18, 24),
        labelled("Qatar", 18, 26),
        labelled("Brazil", -24, -22),
        labelled("Indonesia", -26, -20),
        labelled("Lesotho", 20, 20),
        labelled("Luxembourg", -20, -24),
        labelled("Afghanistan", -22, -22),
      ],
    },
    row(
      "income-life-scatter-regions",
      "Economies by region",
      "Region",
      layout(0, 7, 5, 5),
      "income-life-region"
    ),
    histogram(
      "income-life-scatter-expectancy",
      "Life expectancy",
      "Life expectancy",
      layout(5, 7, 7, 5)
    ),
  ],
  [
    mappedScale(
      "income-life-region",
      "Region",
      [
        "East Asia & Pacific",
        "Europe & Central Asia",
        "Latin America & Caribbean",
        "Middle East, North Africa, Afghanistan & Pakistan",
        "North America",
        "South Asia",
        "Sub-Saharan Africa",
      ],
      regionColors
    ),
  ]
);

/** Each source's causes as shares of that source's own total. */
export const mediaDeathsBarDashboard = dashboard(
  "Media and deaths, built in",
  [
    {
      ...base,
      id: "media-deaths-bar",
      type: "bar",
      title: "What Americans die from, and what the news covers",
      field: "Count",
      aggregateId: "media-deaths-by-source",
      seriesField: "Cause",
      seriesLayout: "percent",
      categoryOrder: "data",
      colorField: "Cause",
      colorScaleId: "media-deaths-cause",
      layout: layout(0, 0, 12, 8),
      xAxisLabel: "Source",
      yAxisLabel: "Share of the source's total (%)",
    },
    row(
      "media-deaths-bar-causes",
      "Rows by cause",
      "Cause",
      layout(0, 8, 6, 6),
      "media-deaths-cause"
    ),
    row(
      "media-deaths-bar-sources",
      "Rows by source",
      "Source",
      layout(6, 8, 6, 6)
    ),
  ],
  [
    mappedScale(
      "media-deaths-cause",
      "Cause",
      [
        "Accidents",
        "Alzheimer's",
        "Cancer",
        "COVID-19",
        "Diabetes",
        "Drug overdose",
        "Heart disease",
        "Homicide",
        "Influenza",
        "Kidney disease",
        "Liver disease",
        "Respiratory disease",
        "Stroke",
        "Suicide",
        "Terrorism",
      ],
      [
        "#4e79a7",
        "#f28e2b",
        "#e15759",
        "#76b7b2",
        "#59a14f",
        "#edc948",
        "#b07aa1",
        "#ff9da7",
        "#9c755f",
        "#bab0ac",
        "#1f77b4",
        "#8c564b",
        "#17becf",
        "#bcbd22",
        "#7f7f7f",
      ]
    ),
  ]
);
mediaDeathsBarDashboard.aggregates = [
  {
    id: "media-deaths-by-source",
    name: "Count by source",
    groupField: "Source",
    measureField: "Count",
    aggregation: "sum",
  },
];

/** Each income class's spending as shares of its own total. */
export const duBoisIncomeBarDashboard = dashboard(
  "Income and expenditure, built in",
  [
    {
      ...base,
      id: "du-bois-bar",
      type: "bar",
      title: "Income and expenditure of 150 families in Atlanta",
      field: "Share",
      aggregateId: "du-bois-by-class",
      seriesField: "Category",
      seriesLayout: "percent",
      categoryOrder: "data",
      colorField: "Category",
      colorScaleId: "du-bois-category",
      layout: layout(0, 0, 12, 8),
      xAxisLabel: "Annual income class",
      yAxisLabel: "Share of spending (%)",
    },
    row(
      "du-bois-bar-categories",
      "Rows by category",
      "Category",
      layout(0, 8, 6, 5),
      "du-bois-category"
    ),
    row("du-bois-bar-classes", "Rows by class", "Class", layout(6, 8, 6, 5)),
  ],
  [
    mappedScale(
      "du-bois-category",
      "Category",
      ["Rent", "Food", "Clothes", "Direct taxes", "Other expenses and savings"],
      ["#2b2b2b", "#7b5aa6", "#d2849a", "#9aa7b8", "#d8c7a2"]
    ),
  ]
);
duBoisIncomeBarDashboard.aggregates = [
  {
    id: "du-bois-by-class",
    name: "Share by class",
    groupField: "Class",
    measureField: "Share",
    aggregation: "sum",
  },
];

/** Monthly unemployed by industry as an ordinary stacked area. */
export const unemploymentAreaDashboard = dashboard(
  "Unemployment by industry, built in",
  [
    {
      ...line(
        "unemployment-area",
        "Unemployed Americans by industry, 2000 to 2010",
        [],
        layout(0, 0, 12, 8),
        "Unemployed (thousands)"
      ),
      xField: "Month",
      xAxisLabel: "Month · UTC",
      colorField: "Industry",
      time: {
        interval: "month",
        weekStart: "monday",
        aggregation: "sum",
        measureField: "Unemployed (thousands)",
        splitField: "Industry",
        missingPeriods: "gap",
        display: "stacked-area",
      },
    },
    row(
      "unemployment-area-industry",
      "Industries",
      "Industry",
      layout(0, 8, 4, 5)
    ),
    histogram(
      "unemployment-area-rate",
      "Unemployment rate",
      "Unemployment rate",
      layout(4, 8, 8, 5)
    ),
  ]
);

/** Miles driven against gas price, joined year by year. */
export const drivingScatterDashboard = dashboard("Driving, built in", [
  {
    ...scatter(
      "driving-scatter",
      "Driving shifts into reverse",
      "Miles",
      "Gas",
      layout(0, 0, 12, 7),
      ["Miles driven per capita", "Gas price per gallon (2010 $)"]
    ),
    pointSize: 4,
    pointOpacity: 0.9,
    connect: { orderField: "Year" },
    annotations: [
      ...[1956, 1974, 1980, 1990, 2000, 2010].map((year) => ({
        id: `driving-year-${year}`,
        type: "callout" as const,
        text: String(year),
        attach: {
          kind: "record" as const,
          keyFields: ["Year"],
          key: [year],
        },
        offset: { dx: 14, dy: -16 },
      })),
    ],
  },
  histogram("driving-scatter-years", "Years", "Year", layout(0, 7, 12, 4)),
]);

/** Each country's two tax readings joined as a slope. */
export const taxSlopeScatterDashboard = dashboard(
  "Tax revenue slope, built in",
  [
    {
      ...scatter(
        "tax-slope-scatter",
        "Central government tax revenue, 2000 and 2023",
        "Year",
        "Tax revenue",
        layout(0, 0, 8, 10),
        ["Year", "Tax revenue (% of GDP)"],
        "Direction",
        "tax-direction"
      ),
      pointSize: 3,
      pointOpacity: 0.9,
      connect: { orderField: "Year", groupField: "Country", labels: "both" },
    },
    row(
      "tax-slope-direction",
      "Countries by direction",
      "Direction",
      layout(8, 0, 4, 3),
      "tax-direction"
    ),
    row("tax-slope-countries", "Countries", "Country", layout(8, 3, 4, 7)),
  ],
  [
    mappedScale(
      "tax-direction",
      "Direction",
      ["Rose", "Fell"],
      ["#c4553a", "#3b6ea8"]
    ),
  ]
);

/** Each topic's two party shares as a dumbbell row. */
export const pewMeaningScatterDashboard = dashboard(
  "Life's meaning by party, built in",
  [
    {
      ...scatter(
        "pew-scatter",
        "What makes life meaningful, by party",
        "Share",
        "Topic",
        layout(0, 0, 12, 6),
        ["Share mentioning the topic (%)", ""],
        "Party",
        "pew-party"
      ),
      pointSize: 6,
      pointOpacity: 1,
      margin: { top: 16, right: 24, bottom: 44, left: 200 },
      connect: { orderField: "Party", groupField: "Topic" },
    },
    row(
      "pew-scatter-parties",
      "Rows by party",
      "Party",
      layout(0, 6, 6, 4),
      "pew-party"
    ),
    row("pew-scatter-topics", "Rows by topic", "Topic", layout(6, 6, 6, 4)),
  ],
  [
    mappedScale(
      "pew-party",
      "Party",
      ["Dem/Lean Dem", "Rep/Lean Rep"],
      ["#3b6ea8", "#c4553a"]
    ),
  ]
);

/** Every occupation's change as a slope, one panel per group. */
export const middleClassJobsScatterDashboard = dashboard(
  "Middle-class jobs, built in",
  [
    {
      ...scatter(
        "jobs-scatter",
        "The changing nature of middle-class jobs",
        "Year",
        "Jobs per 1000",
        layout(0, 0, 12, 10),
        ["Year", "Jobs per 1,000"],
        "Women minus men",
        "jobs-gender"
      ),
      pointSize: 3,
      pointOpacity: 0.9,
      connect: { orderField: "Year", groupField: "Occupation" },
      facet: {
        enabled: true,
        type: "wrap",
        rowVariable: "Group",
        columnCount: 5,
      },
    },
    row(
      "jobs-scatter-groups",
      "Occupations by group",
      "Group",
      layout(0, 10, 12, 5)
    ),
  ],
  [
    {
      id: "jobs-gender",
      name: "Women minus men",
      sourceField: "Women minus men",
      type: "numerical",
      palette: "RdBu",
      min: -80,
      max: 80,
      midpoint: 0,
    },
  ]
);
// Two readings per country: Year reads as two bands, not a number line.
taxSlopeScatterDashboard.fieldSettings = { Year: { type: "categorical" } };
middleClassJobsScatterDashboard.fieldSettings = {
  Year: { type: "categorical" },
};

/** One measure's central path with its four supplied percentile bands. */
const fanLine = (
  id: string,
  measure: string,
  position: ReturnType<typeof layout>,
  color: string
): Extract<Chart, { type: "line" }> => ({
  ...line(id, measure, ["Central"], position, `${measure} (%)`),
  xField: "Year",
  xAxisLabel: "Year",
  seriesSettings: {
    Central: {
      showPoints: false,
      pointSize: 3,
      pointOpacity: 0.8,
      lineWidth: 2,
      lineOpacity: 1,
      lineColor: color,
      lineStyle: "solid",
      useRightAxis: false,
    },
  },
  localFilters: [{ type: "value", field: "Measure", values: [measure] }],
  annotations: [
    ["P10", "P90", "10–90%"],
    ["P20", "P80", "20–80%"],
    ["P30", "P70", "30–70%"],
    ["P40", "P60", "40–60%"],
  ].map(([lowerField, upperField, range]) => ({
    id: `${id}-${lowerField}`,
    type: "interval" as const,
    lowerField: lowerField!,
    upperField: upperField!,
    meaning: range === "10–90%" ? "Supplied 10–90% range" : `${range}`,
    color,
  })),
});

/** The forecast fans as two ordinary line charts with supplied intervals. */
export const fanLineDashboard = dashboard("Forecast fan, built in", [
  fanLine("fan-inflation", "Inflation", layout(0, 0, 6, 7), "#b0413e"),
  fanLine("fan-gdp", "GDP growth", layout(6, 0, 6, 7), "#3b6ea8"),
  row("fan-line-kind", "Rows by kind", "Kind", layout(0, 7, 6, 4)),
  row("fan-line-measure", "Rows by measure", "Measure", layout(6, 7, 6, 4)),
]);

const heatmap = (
  id: string,
  title: string,
  field: string,
  columnField: string,
  position: ReturnType<typeof layout>,
  extra: Partial<Extract<Chart, { type: "heatmap" }>>
): Extract<Chart, { type: "heatmap" }> => ({
  ...base,
  id,
  type: "heatmap",
  title,
  field,
  columnField,
  aggregation: "count",
  maxCategories: 20,
  sortBy: "count",
  showValues: false,
  layout: position,
  margin: { top: 8, right: 16, bottom: 8, left: 8 },
  ...extra,
});

/** Six years of messages by correspondent and month, every month shown. */
export const messageHeatmapDashboard = dashboard("Message log, built in", [
  heatmap(
    "message-heatmap",
    "Messages by correspondent and month",
    "Correspondent",
    "Date",
    layout(0, 0, 12, 7),
    {
      maxColumns: 80,
      columnInterval: "month",
      colorDomain: { min: 0, transform: "sqrt" },
    }
  ),
  row("message-heatmap-roles", "Messages by role", "Role", layout(0, 7, 6, 4)),
  row(
    "message-heatmap-direction",
    "Sent and received",
    "Direction",
    layout(6, 7, 6, 4)
  ),
]);

/** Every state and year of measles reports, in the publisher's state order. */
export const measlesHeatmapDashboard = dashboard("Measles, built in", [
  heatmap(
    "measles-heatmap",
    "Measles cases per 100,000, 1928 to 2012",
    "State",
    "Year",
    layout(0, 0, 12, 10),
    {
      aggregation: "average",
      measureField: "Rate",
      maxCategories: 51,
      maxColumns: 85,
      sortBy: "data",
      columnSortBy: "label",
      colorDomain: { min: 0, max: 1000, transform: "sqrt" },
    }
  ),
  row("measles-heatmap-status", "Cell status", "Status", layout(0, 10, 6, 4)),
]);

/** Each state's Democratic margin per election on a fixed signed scale. */
export const electionsHeatmapDashboard = dashboard("Elections, built in", [
  heatmap(
    "elections-heatmap",
    "How each state voted, 1976 to 2016",
    "State",
    "Year",
    layout(0, 0, 12, 10),
    {
      aggregation: "average",
      measureField: "Margin",
      maxCategories: 51,
      sortBy: "label",
      colorDomain: { min: -40, max: 40 },
    }
  ),
  row(
    "elections-heatmap-winner",
    "Rows by winner",
    "Winner",
    layout(0, 10, 6, 4)
  ),
]);
