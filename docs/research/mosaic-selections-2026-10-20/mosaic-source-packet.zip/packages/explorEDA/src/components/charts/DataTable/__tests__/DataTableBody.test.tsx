import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen } from "@testing-library/react";
import { DataTableBody } from "../DataTableBody";
import { DataTableSettings } from "../definition";

const mockSettings: DataTableSettings = {
  id: "test-table",
  type: "data-table",
  title: "Test Table",
  field: "test",
  layout: { x: 0, y: 0, w: 12, h: 6 },
  colorScaleId: undefined,
  colorField: undefined,
  facet: {
    enabled: false,
    type: "grid",
    rowVariable: "",
    columnVariable: "",
  },
  xAxis: {},
  yAxis: {},
  margin: { top: 0, right: 0, bottom: 0, left: 0 },
  xAxisLabel: "",
  yAxisLabel: "",
  xGridLines: 0,
  yGridLines: 0,
  columns: [
    { id: "name", field: "name", width: 200 },
    { id: "age", field: "age", width: 100 },
  ],

  sortDirection: "asc",
  filters: [],
  globalSearch: "",
};

const mockData = [
  { __ID: 1, name: "John", age: 30 },
  { __ID: 2, name: "Jane", age: 25 },
  { __ID: 3, name: "Bob", age: 35 },
];

const mockLiveItems = {
  items: [
    { key: 1, value: 1 },
    { key: 2, value: 1 },
    { key: 3, value: 1 },
  ],
};

const mockUseDataLayer = vi.fn();

vi.mock("@/providers/DataLayerProvider", () => ({
  useDataLayer: (selector: (state: unknown) => unknown) =>
    mockUseDataLayer(selector),
}));

const renderBody = (settings: DataTableSettings) =>
  render(
    <table>
      <DataTableBody settings={settings} />
    </table>
  );

describe("DataTableBody", () => {
  beforeEach(() => {
    mockUseDataLayer.mockImplementation(
      (selector: (state: unknown) => unknown) => {
        if (selector.toString().includes("data")) {
          return mockData;
        }
        if (selector.toString().includes("getLiveItems")) {
          return mockLiveItems;
        }
        return null;
      }
    );
  });

  it("renders all rows when no filters are applied", () => {
    renderBody(mockSettings);

    expect(screen.getByText("John")).toBeInTheDocument();
    expect(screen.getByText("Jane")).toBeInTheDocument();
    expect(screen.getByText("Bob")).toBeInTheDocument();
  });

  it("applies global search correctly", () => {
    const settingsWithSearch = {
      ...mockSettings,
      globalSearch: "John",
    };

    renderBody(settingsWithSearch);

    expect(screen.getByText("John")).toBeInTheDocument();
    expect(screen.queryByText("Jane")).not.toBeInTheDocument();
    expect(screen.queryByText("Bob")).not.toBeInTheDocument();
  });

  it("applies column filters correctly", () => {
    const settingsWithFilter = {
      ...mockSettings,
      filters: [
        {
          type: "text" as const,
          field: "name",
          value: "John",
          operator: "equals" as const,
        },
      ],
    };

    renderBody(settingsWithFilter);

    expect(screen.getByText("John")).toBeInTheDocument();
    expect(screen.queryByText("Jane")).not.toBeInTheDocument();
    expect(screen.queryByText("Bob")).not.toBeInTheDocument();
  });

  it("applies range and value filters locally with AND semantics", () => {
    const settingsWithFilters = {
      ...mockSettings,
      filters: [
        { type: "range" as const, field: "age", min: 30 },
        { type: "value" as const, field: "name", values: ["Bob"] },
      ],
    };

    renderBody(settingsWithFilters);

    expect(screen.getByText("Bob")).toBeInTheDocument();
    expect(screen.queryByText("John")).not.toBeInTheDocument();
    expect(screen.queryByText("Jane")).not.toBeInTheDocument();
  });

  it("applies numeric sorting correctly", () => {
    const settingsWithSort = {
      ...mockSettings,
      sortBy: "age",
      sortDirection: "desc" as const,
    };

    renderBody(settingsWithSort);

    const rows = screen.getAllByRole("row");
    expect(rows[0]).toHaveTextContent("35"); // First row should be Bob (age 35)
    expect(rows[1]).toHaveTextContent("30"); // Second row should be John (age 30)
    expect(rows[2]).toHaveTextContent("25"); // Third row should be Jane (age 25)
  });

  it("virtualizes rows and reaches the last record without pages", () => {
    const rows = Array.from({ length: 10000 }, (_, index) => ({
      __ID: index,
      name: `Person ${index}`,
      age: index,
    }));
    const { rerender } = render(
      <table>
        <DataTableBody
          settings={mockSettings}
          rows={rows}
          viewportHeight={300}
        />
      </table>
    );
    expect(screen.getByText("Person 0")).toBeInTheDocument();
    expect(screen.queryByText("Person 9999")).not.toBeInTheDocument();
    expect(screen.getAllByRole("row").length).toBeLessThan(30);
    rerender(
      <table>
        <DataTableBody
          settings={mockSettings}
          rows={rows}
          viewportHeight={300}
          scrollTop={299736}
        />
      </table>
    );
    expect(screen.getByText("Person 9999")).toBeInTheDocument();
    expect(screen.queryByText("Person 0")).not.toBeInTheDocument();
    expect(screen.getAllByRole("row").length).toBeLessThan(30);
  });

  it("respects column widths", () => {
    renderBody(mockSettings);

    const cells = screen.getAllByRole("cell");
    expect(cells[0]).toHaveStyle({ width: "200px" });
    expect(cells[1]).toHaveStyle({ width: "100px" });
  });

  it("uses column fields for row lookup", () => {
    const settingsWithStableIds = {
      ...mockSettings,
      columns: [
        { id: "name-column", field: "name", width: 200 },
        { id: "age-column", field: "age", width: 100 },
      ],
    };

    renderBody(settingsWithStableIds);

    expect(screen.getByText("John")).toBeInTheDocument();
    expect(screen.getByText("30")).toBeInTheDocument();
  });

  it("shows an empty state when no rows match", () => {
    renderBody({ ...mockSettings, globalSearch: "missing" });

    expect(
      screen.getByText("No rows match the current filters.")
    ).toBeInTheDocument();
  });
  it("shows a centered null placeholder for missing values", () => {
    mockUseDataLayer.mockImplementation(
      (selector: (state: unknown) => unknown) => {
        if (selector.toString().includes("data")) {
          return [{ __ID: 1, name: "", age: null }];
        }
        if (selector.toString().includes("getLiveItems")) {
          return { items: [{ key: 1, value: 1 }] };
        }
        return null;
      }
    );
    renderBody(mockSettings);
    const cells = screen.getAllByRole("cell");
    expect(cells.map((cell) => cell.textContent)).toEqual([
      "nullMissing",
      "nullMissing",
    ]);
    expect(cells[1]).toHaveStyle({ textAlign: "center" });
    expect(screen.queryByText("—")).not.toBeInTheDocument();
  });
});
